"""PASTIS Dataset for CopernicusFM."""

import json
import os
from datetime import datetime, date
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import transforms


class PASTISDataset(Dataset):
    """PASTIS Dataset for semantic segmentation.

    Args:
        data_root (str): Root directory of PASTIS dataset.
        fold (int): Fold number (1-5).
        split (str): 'train', 'val', or 'test'.
        num_time_steps (int): Number of time steps to use. Default: 12.
        img_size (int): Image size. Default: 128.
        transform (callable, optional): Optional transform to be applied on a sample.
        normalize (bool): Whether to normalize images. Default: True.
    """

    # PASTIS 类别映射
    CLASSES = [
        'Background', 'Meadow', 'Soft winter wheat', 'Corn', 'Winter barley',
        'Winter rapeseed', 'Spring barley', 'Sunflower', 'Grapevine', 'Beet',
        'Winter triticale', 'Winter durum wheat', 'Fruits vegetables flowers',
        'Potatoes', 'Leguminous fodder', 'Soybeans', 'Orchard', 'Mixed cereal',
        'Sorghum'
    ]

    # 13 波段名称 (扩展后)
    BANDS = [
        'B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B8A', 'B09',
        'B10', 'B11', 'B12'
    ]

    # Sentinel-2 波长 (nm)
    WAVELENGTHS = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610,
                   2190]

    # Sentinel-2 带宽 (nm)
    BANDWIDTHS = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]

    def __init__(
        self,
        data_root: str,
        fold: int,
        split: str = 'train',
        num_time_steps: int = 12,
        img_size: int = 128,
        transform: Optional[callable] = None,
        normalize: bool = True,
    ):
        super().__init__()

        self.data_root = data_root
        self.fold = fold
        self.split = split
        self.num_time_steps = num_time_steps
        self.img_size = img_size
        self.transform = transform
        self.normalize = normalize

        # 加载元数据
        metadata_path = os.path.join(data_root, 'metadata_summary.json')
        with open(metadata_path, 'r') as f:
            self.metadata = json.load(f)

        # 加载归一化参数
        norm_path = os.path.join(data_root, 'NORM_S2_patch.json')
        with open(norm_path, 'r') as f:
            self.norm_params = json.load(f)

        # 根据 fold 和 split 筛选样本
        self.samples = self._filter_samples()

        # 获取归一化参数
        self.mean, self.std = self._get_norm_params()

        print(f'PASTIS Dataset: {split} set, fold {fold}, {len(self.samples)} samples')

    def _filter_samples(self) -> List[Dict]:
        """根据 fold 和 split 筛选样本。"""
        samples = []

        for info in self.metadata:
            fold_num = info.get('Fold')
            patch_id = info.get('ID_PATCH')

            # 根据 fold 和 split 筛选
            if self.split == 'train' and fold_num in [1, 2, 3]:
                samples.append(info)
            elif self.split == 'val' and fold_num == 4:
                samples.append(info)
            elif self.split == 'test' and fold_num == 5:
                samples.append(info)

        return samples

    def _get_norm_params(self) -> Tuple[np.ndarray, np.ndarray]:
        """获取归一化参数。"""
        fold_key = f'Fold_{self.fold}'

        if fold_key in self.norm_params:
            params = self.norm_params[fold_key]
            mean = np.array(params['mean'])
            std = np.array(params['std'])
        else:
            # 使用默认值
            print(f'Warning: No norm params for {fold_key}, using defaults')
            mean = np.zeros(13)
            std = np.ones(13)

        return mean, std

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict:
        """获取一个样本。

        Returns:
            dict: {
                'image': torch.Tensor,  # [T, C, H, W] 时序影像
                'label': torch.Tensor,  # [H, W] 标签
                'meta': torch.Tensor,   # [4] 元信息 [lon, lat, time, area]
                'patch_id': str,        # 样本 ID
            }
        """
        info = self.samples[idx]
        patch_id = info.get('ID_PATCH')

        # 1. 加载时序影像
        img_path = os.path.join(self.data_root, 'DATA_S2_PT', f'S2_{patch_id}.pt')
        image = torch.load(img_path)  # [T, 13, 128, 128]

        # 只取前 num_time_steps 个时间步
        if image.shape[0] > self.num_time_steps:
            image = image[:self.num_time_steps]

        # 2. 加载标签
        label_path = os.path.join(self.data_root, 'label_pt', f'S2_{patch_id}.pt')
        label = torch.load(label_path)  # [1, 128, 128] 或 [128, 128]

        if label.dim() == 3:
            label = label.squeeze(0)  # [128, 128]

        # 3. 获取元信息
        lon = info.get('lon', 0.0)
        lat = info.get('lat', 0.0)

        # 获取时间信息 (使用第一个日期)
        avg_dates = info.get('avg_dates_S2', [])
        if avg_dates and len(avg_dates) > 0:
            # 解析日期格式 (YYYYMMDD)
            try:
                date_str = str(avg_dates[0])
                image_date = datetime.strptime(date_str, '%Y%m%d').date()
                reference_date = date(1970, 1, 1)
                time_days = (image_date - reference_date).days
            except:
                time_days = 0.0
        else:
            time_days = 0.0

        # 计算面积 (128 像素 * 10m 分辨率)
        area = (128 * 10 / 1000) ** 2  # km²

        meta = torch.tensor([lon, lat, time_days, area], dtype=torch.float32)

        # 4. 归一化
        if self.normalize:
            image = self._normalize(image)

        # 5. 数据增强
        if self.transform is not None:
            image, label = self.transform(image, label)

        return {
            'image': image,      # [T, 13, 128, 128]
            'label': label.long(),  # [128, 128]
            'meta': meta,        # [4]
            'patch_id': patch_id,
        }

    def _normalize(self, image: torch.Tensor) -> torch.Tensor:
        """归一化图像。"""
        # image: [T, 13, H, W]
        mean = torch.tensor(self.mean, dtype=torch.float32).view(1, -1, 1, 1)
        std = torch.tensor(self.std, dtype=torch.float32).view(1, -1, 1, 1)

        image = (image - mean) / std

        return image


class PASTISTransform:
    """PASTIS 数据增强。"""

    def __init__(self, split: str = 'train', img_size: int = 128):
        self.split = split
        self.img_size = img_size

    def __call__(self, image: torch.Tensor, label: torch.Tensor):
        """
        Args:
            image: [T, C, H, W]
            label: [H, W]

        Returns:
            image, label
        """
        if self.split == 'train':
            # 随机水平翻转
            if torch.rand(1) > 0.5:
                image = torch.flip(image, dims=[-1])
                label = torch.flip(label, dims=[-1])

            # 随机垂直翻转
            if torch.rand(1) > 0.5:
                image = torch.flip(image, dims=[-2])
                label = torch.flip(label, dims=[-2])

        return image, label


def build_pastis_dataset(
    data_root: str,
    fold: int,
    split: str,
    num_time_steps: int = 12,
    img_size: int = 128,
    normalize: bool = True,
) -> PASTISDataset:
    """构建 PASTIS 数据集。"""
    transform = PASTISTransform(split=split, img_size=img_size)

    dataset = PASTISDataset(
        data_root=data_root,
        fold=fold,
        split=split,
        num_time_steps=num_time_steps,
        img_size=img_size,
        transform=transform if split == 'train' else None,
        normalize=normalize,
    )

    return dataset
