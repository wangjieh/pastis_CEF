# CopernicusFM 迁移到 OpenMMLab 完成

## 迁移概述

本项目将 Copernicus Foundation Model 的图像分割功能迁移到 OpenMMLab (mmseg) 框架中。

## 迁移状态

### ✅ 已完成

1. **核心模型定义**（~1400 行代码，直接复用）
   - `models_dwv.py` - ViT 编码器（分类）
   - `models_dwv_seg.py` - ViT 编码器（分割）
   - `dynamic_hypernetwork.py` - 动态 Patch Embedding
   - `aurora/fourier.py` - Fourier 展开
   - `flexivit/` - FlexiViT 支持

2. **任务包装器**（~200 行新代码）
   - `copernicusfm_seg.py` - 继承 mmseg 的 BaseSegmentor
   - 实现 `forward_train()` 和 `forward_test()`
   - 支持特征提取、损失计算、推理

3. **配置系统**
   - `copernicusfm_seg_default.py` - 默认配置
   - `copernicusfm_seg_s2_eurosat.py` - Sentinel-2 EuroSAT 配置

4. **工具脚本**
   - `train.py` - 训练脚本
   - `test.py` - 测试脚本
   - `test_model.py` - 模型验证脚本

5. **文档**
   - `README.md` - 使用说明
   - 本文档 - 迁移总结

### 📊 代码统计

| 类型 | 行数 | 说明 |
|-----|------|-----|
| 复用代码 | ~1400 | 来自 CopernicusFM 原项目 |
| 新增代码 | ~500 | OpenMMLab 适配代码 |
| 配置文件 | ~200 | mmseg 配置格式 |
| 工具脚本 | ~400 | 训练/测试/验证 |
| 文档 | ~300 | README 等 |
| **总计** | **~2800** | - |

## 项目结构

```
copernicusfm_mmlab/
├── copernicusfm/                    # 模型核心（复用 + 适配）
│   ├── __init__.py                 # ✅ 新增
│   ├── copernicusfm_seg.py         # ✅ 新增（继承 BaseSegmentor）
│   ├── models_dwv.py               # ✅ 直接复用
│   ├── models_dwv_seg.py           # ✅ 直接复用
│   ├── dynamic_hypernetwork.py     # ✅ 直接复用
│   ├── aurora/                     # ✅ 直接复用
│   └── flexivit/                   # ✅ 直接复用
├── configs/                         # 配置文件
│   ├── copernicusfm_seg_default.py          # ✅ 新增
│   └── copernicusfm_seg_s2_eurosat.py      # ✅ 新增
├── tools/                           # 工具脚本
│   ├── train.py                    # ✅ 新增
│   └── test.py                     # ✅ 新增
├── tests/                           # 测试
│   └── test_model.py               # ✅ 新增
└── README.md                        # ✅ 新增
```

## 关键改动说明

### 1. copernicusfm_seg.py（新文件，~200 行）

**改动原因**：
- 原项目使用 PyTorch Lightning（`LightningTask`）
- OpenMMLab 使用 mmseg 的 `BaseSegmentor`

**主要改动**：
```python
# 原代码（PyTorch Lightning）
class CopernicusFMSegmentation(LightningTask):
    def __init__(self, args, model_config, data_config):
        super().__init__(args, model_config, data_config)
        ...
    def training_step(self, batch, batch_idx):
        ...

# 新代码（OpenMMLab）
@MODELS.register_module()
class CopernicusFMSeg(BaseModule):
    def __init__(self, backbone, neck, decode_head, ...):
        ...
    def forward_train(self, img, img_metas, gt_semantic_seg):
        ...
```

**保留的功能**：
- ✅ backbone 提取
- ✅ neck 特征融合
- ✅ decode_head 和 auxiliary_head
- ✅ 预训练权重加载
- ✅ 特征提取、前向传播、推理

### 2. 配置文件（新文件）

采用 mmseg 标准配置格式：

```python
model = dict(
    type='CopernicusFMSeg',
    backbone=dict(...),
    neck=dict(...),
    decode_head=dict(...),
    auxiliary_head=dict(...),
)

data = dict(
    train=dict(...),
    val=dict(...),
    test=dict(...),
)
```

## 使用方式

### 快速开始

```bash
# 1. 进入项目目录
cd copernicusfm_mmlab

# 2. 验证模型（不需要数据）
conda run -n mmenv python tests/test_model.py

# 3. 准备数据（参考 README）

# 4. 修改配置（参考 configs/copernicusfm_seg_s2_eurosat.py）

# 5. 训练
conda run -n mmenv python tools/train.py configs/copernicusfm_seg_s2_eurosat.py

# 6. 测试
conda run -n mmenv python tools/test.py configs/copernicusfm_seg_s2_eurosat.py \
    work_dirs/copernicusfm_seg_s2_eurosat/latest.pth --eval mIoU
```

## 性能对比

### 原项目 vs 迁移后

| 方面 | 原项目 | 迁移后 |
|-----|--------|-------|
| 框架 | PyTorch Lightning | OpenMMLab (mmseg) |
| 训练器 | Lightning Trainer | mmengine Runner |
| 配置格式 | YAML + Hydra | mmengine Config (.py) |
| 模型注册 | Factory 模式 | Registry 模式 |
| 数据加载 | torchgeo | mmseg CustomDataset |
| Metrics | 自定义 | mmseg IoUMetric |

### 优势

1. **更好的生态系统**
   - 与 mmseg 丰富的解码器、损失函数集成
   - 社区支持和预训练模型更多

2. **更易扩展**
   - 使用 Registry，方便注册新模块
   - 配置系统更灵活

3. **更好的分布式支持**
   - mmengine 原生支持分布式训练
   - 与 mmcv 的 DataParallel 集成

## 待办事项

### 短期

- [ ] 在实际数据集上测试训练流程
- [ ] 对比原项目和迁移后的性能
- [ ] 优化数据预处理（支持原项目数据格式）

### 中期

- [ ] 支持其他任务（分类、回归、变化检测）
- [ ] 添加更多配置文件（不同数据集、不同模型规模）
- [ ] 添加模型导出功能（ONNX 等）

### 长期

- [ ] 集成到 mmseg 官方模型库
- [ ] 添加预训练模型和性能基准
- [ ] 优化推理速度（TensorRT 等）

## 技术细节

### 模型架构

```
输入: (B, C, H, W)
    ↓
[Dynamic Patch Embedding]
    - 根据波长/带宽动态生成权重
    - 支持 spectral 和 variable 两种模式
    ↓
[Position Embedding]
    - 标准位置编码
    - Fourier 坐标编码（经纬度）
    - Fourier 时间编码
    - Fourier 尺度编码
    ↓
[Transformer Blocks] (12 层)
    ↓
[Feature2Pyramid] (Neck)
    ↓
[UPerHead + FCNHead]
    ↓
输出: (B, num_classes, H, W)
```

### 关键创新

1. **Dynamic Patch Embedding**
   - 不使用固定的 conv 权重
   - 根据输入的波长/带宽动态生成
   - 支持任意数量的波段

2. **多源元信息编码**
   - 使用 Fourier 展开编码非图像信息
   - 支持坐标、时间、尺度等元数据

3. **灵活的输入模式**
   - `spectral`: 光谱数据（Sentinel-1/2）
   - `variable`: 非光谱变量（DEM、S5P 气体等）

## 参考资料

### 原项目
- GitHub: wangyi111/Copernicus-Bench
- HuggingFace: wangyi111/Copernicus-FM

### OpenMMLab
- mmseg: https://github.com/open-mmlab/mmsegmentation
- mmengine: https://github.com/open-mmlab/mmengine
- mmcv: https://github.com/open-mmlab/mmcv

## 许可证

本项目遵循原项目的许可证。

## 联系方式

如有问题或建议，欢迎提交 issue。
