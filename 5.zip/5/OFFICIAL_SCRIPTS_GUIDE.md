# 使用 mmseg 官方 train.py 和 test.py 指南

## 📋 概述

本项目现在使用 **mmseg 官方的 train.py 和 test.py**，而不是简化版本。

**优势**：
- ✅ 功能完整（支持分布式、日志、恢复训练等）
- ✅ 经过严格测试
- ✅ 生产就绪
- ✅ 社区支持

**位置**：
- 官方 train.py: `D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/train.py`
- 官方 test.py: `D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/test.py`

---

## 🚀 快速开始

### **方式 1：直接使用 mmseg 官方脚本（推荐）**

```bash
# 激活环境
conda activate mmenv

# 进入项目目录
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab

# 训练（单 GPU）
python D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/train.py \
    configs/copernicusfm_seg_s2_eurosat.py \
    --work-dir work_dirs/copernicusfm_s2_eurosat

# 训练（多 GPU）
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_train.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    4 \
    --work-dir work_dirs/copernicusfm_s2_eurosat

# 测试（单 GPU）
python D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/test.py \
    configs/copernicusfm_seg_s2_eurosat.py \
    work_dirs/copernicusfm_s2_eurosat/latest.pth \
    --eval mIoU

# 测试（多 GPU）
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_test.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    work_dirs/copernicusfm_s2_eurosat/latest.pth \
    4 \
    --eval mIoU
```

### **方式 2：使用本项目的启动脚本（简化路径）**

我已经创建了便捷的启动脚本：

```bash
# 进入项目目录
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab

# 训练（单 GPU）
bash scripts/train_single.sh configs/copernicusfm_seg_s2_eurosat.py

# 训练（多 GPU）
bash scripts/train_dist.sh configs/copernicusfm_seg_s2_eurosat.py 4

# 测试（单 GPU）
bash scripts/test_single.sh configs/copernicusfm_seg_s2_eurosat.py checkpoint.pth

# 测试（多 GPU）
bash scripts/test_dist.sh configs/copernicusfm_seg_s2_eurosat.py checkpoint.pth 4
```

### **方式 3：使用 Python 直接调用**

```python
# 在 Python 脚本中调用
import subprocess
import sys

config = 'configs/copernicusfm_seg_s2_eurosat.py'
checkpoint = 'work_dirs/copernicusfm_s2_eurosat/latest.pth'

# 训练
subprocess.run([
    sys.executable,
    'D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/train.py',
    config,
    '--work-dir', 'work_dirs/copernicusfm_s2_eurosat'
])

# 测试
subprocess.run([
    sys.executable,
    'D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/test.py',
    config,
    checkpoint,
    '--eval', 'mIoU'
])
```

---

## 📖 官方 train.py 参数说明

### **必需参数**

```bash
python train.py <config> [options]
```

- `<config>`: 配置文件路径（必需）

### **可选参数**

| 参数 | 类型 | 说明 | 示例 |
|-----|------|------|------|
| `--work-dir` | str | 工作目录（保存日志和模型） | `--work-dir work_dirs/exp1` |
| `--resume-from` | str | 从 checkpoint 恢复训练 | `--resume-from checkpoint.pth` |
| `--load-from` | str | 加载预训练权重 | `--load-from pretrained.pth` |
| `--no-validate` | flag | 训练时不做验证 | `--no-validate` |
| `--gpus` | int | GPU 数量（非分布式） | `--gpus 2` |
| `--gpu-ids` | int+ | GPU ID（非分布式） | `--gpu-ids 0 1` |
| `--seed` | int | 随机种子 | `--seed 42` |
| `--deterministic` | flag | 使用确定性算法 | `--deterministic` |
| `--launcher` | str | 启动方式 | `--launcher pytorch` |
| `--local-rank` | int | 分布式本地 rank | `--local-rank 0` |
| `--auto-resume` | flag | 自动恢复训练 | `--auto-resume` |
| `--cfg-options` | str+ | 覆盖配置 | `--cfg-options model.backbone.depth=24` |
| `--options` | str+ | 自定义选项（已弃用） | `--options key=value` |

### **示例**

```bash
# 基础训练
python train.py configs/my_config.py

# 指定工作目录
python train.py configs/my_config.py --work-dir work_dirs/exp1

# 从 checkpoint 恢复
python train.py configs/my_config.py --resume-from work_dirs/exp1/latest.pth

# 加载预训练权重
python train.py configs/my_config.py --load-from pretrained.pth

# 使用多 GPU（非分布式）
python train.py configs/my_config.py --gpus 4

# 覆盖配置参数
python train.py configs/my_config.py --cfg-options \
    model.backbone.depth=24 \
    data.samples_per_gpu=8 \
    runner.max_iters=20000

# 使用确定性算法
python train.py configs/my_config.py --seed 42 --deterministic
```

---

## 📖 官方 test.py 参数说明

### **必需参数**

```bash
python test.py <config> <checkpoint> [options]
```

- `<config>`: 配置文件路径（必需）
- `<checkpoint>`: checkpoint 文件路径（必需）

### **可选参数**

| 参数 | 类型 | 说明 | 示例 |
|-----|------|------|------|
| `--out` | str | 输出结果文件 | `--out results.pkl` |
| `--eval` | str+ | 评估指标 | `--eval mIoU` |
| `--show` | flag | 显示结果 | `--show` |
| `--show-dir` | str | 保存可视化结果 | `--show-dir vis_results` |
| `--format-only` | flag | 只格式化不评估 | `--format-only` |
| `--aug-test` | flag | 使用数据增强测试 | `--aug-test` |
| `--gpu-collect` | flag | 使用 GPU 收集结果 | `--gpu-collect` |
| `--tmpdir` | str | 临时目录 | `--tmpdir /tmp` |
| `--launcher` | str | 启动方式 | `--launcher pytorch` |
| `--local-rank` | int | 分布式本地 rank | `--local-rank 0` |
| `--eval-options` | str+ | 评估选项 | `--eval-options efficient_test=True` |
| `--cfg-options` | str+ | 覆盖配置 | `--cfg-options model.test_cfg.mode=slide` |

### **示例**

```bash
# 基础测试（mIoU 评估）
python test.py configs/my_config.py checkpoint.pth --eval mIoU

# 保存结果
python test.py configs/my_config.py checkpoint.pth --out results.pkl --eval mIoU

# 显示可视化结果
python test.py configs/my_config.py checkpoint.pth --show --show-dir vis_results

# 使用数据增强测试
python test.py configs/my_config.py checkpoint.pth --aug-test --eval mIoU

# 格式化结果（不评估）
python test.py configs/my_config.py checkpoint.pth --format-only

# 使用 efficient_test（节省内存）
python test.py configs/my_config.py checkpoint.pth \
    --eval mIoU \
    --eval-options efficient_test=True

# 覆盖配置
python test.py configs/my_config.py checkpoint.pth \
    --eval mIoU \
    --cfg-options model.test_cfg.mode=slide
```

---

## 🔧 分布式训练/测试

### **使用 dist_train.sh（推荐）**

```bash
# 2 GPU 训练
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_train.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    2

# 4 GPU 训练，指定工作目录
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_train.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    4 \
    --work-dir work_dirs/copernicusfm_s2_eurosat

# 8 GPU 训练，使用 port 避免冲突
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_train.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    8 \
    --work-dir work_dirs/copernicusfm_s2_eurosat \
    29500
```

### **使用 dist_test.sh（推荐）**

```bash
# 2 GPU 测试
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_test.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    checkpoint.pth \
    2 \
    --eval mIoU

# 4 GPU 测试，保存结果
bash D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/dist_test.sh \
    configs/copernicusfm_seg_s2_eurosat.py \
    checkpoint.pth \
    4 \
    --out results.pkl \
    --eval mIoU
```

### **使用 torchrun（PyTorch 原生分布式）**

```bash
# 训练
torchrun --nproc_per_node=4 --master_port=29500 \
    D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/train.py \
    configs/copernicusfm_seg_s2_eurosat.py \
    --work-dir work_dirs/exp1 \
    --launcher pytorch

# 测试
torchrun --nproc_per_node=4 --master_port=29500 \
    D:/Anaconda/setup/envs/mmenv/Lib/site-packages/mmseg/.mim/tools/test.py \
    configs/copernicusfm_seg_s2_eurosat.py \
    checkpoint.pth \
    --eval mIoU \
    --launcher pytorch
```

---

## 💡 常用技巧

### **1. 覆盖配置参数**

```bash
# 修改学习率
python train.py configs/my_config.py \
    --cfg-options optimizer.lr=0.001

# 修改 batch size
python train.py configs/my_config.py \
    --cfg-options data.samples_per_gpu=8

# 修改迭代次数
python train.py configs/my_config.py \
    --cfg-options runner.max_iters=50000

# 修改多行配置
python train.py configs/my_config.py \
    --cfg-options \
    optimizer.lr=0.001 \
    data.samples_per_gpu=8 \
    runner.max_iters=50000
```

### **2. 恢复训练**

```bash
# 方式 1：使用 --resume-from
python train.py configs/my_config.py \
    --resume-from work_dirs/exp1/latest.pth

# 方式 2：使用 --auto-resume
python train.py configs/my_config.py \
    --auto-resume
```

### **3. 使用 TensorBoard**

在配置文件中添加：
```python
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook', by_epoch=False),
        dict(type='TensorboardLoggerHook', by_epoch=False),
    ])
```

然后训练时：
```bash
python train.py configs/my_config.py --work-dir work_dirs/exp1

# 查看 TensorBoard
tensorboard --logdir work_dirs/exp1
```

### **4. 测试时使用滑动窗口**

```bash
python test.py configs/my_config.py checkpoint.pth \
    --eval mIoU \
    --cfg-options model.test_cfg.mode=slide \
    model.test_cfg.crop_size=(512, 512) \
    model.test_cfg.stride=(341, 341)
```

---

## 🐛 常见问题

### **Q1: ImportError: cannot import name 'xxx'**

**原因**：mmseg 版本不兼容

**解决**：
```bash
# 检查 mmseg 版本
python -c "import mmseg; print(mmseg.__version__)"

# 升级 mmseg
pip install mmsegmentation --upgrade
```

### **Q2: RuntimeError: CUDA out of memory**

**原因**：GPU 内存不足

**解决**：
```bash
# 方式 1：减少 batch size
python train.py configs/my_config.py \
    --cfg-options data.samples_per_gpu=4

# 方式 2：使用 gradient accumulation
# 在配置文件中修改
optimizer_config = dict(type="GradientCumulativeOptimizerHook", cumulative_iters=4)

# 方式 3：使用 mixed precision
python train.py configs/my_config.py \
    --cfg-options fp16=dict(loss_scale=512.)
```

### **Q3: RuntimeError: Address already in use**

**原因**：分布式训练端口被占用

**解决**：
```bash
# 指定其他端口
bash dist_train.sh configs/my_config.py 4 29501

# 或者使用 torchrun
torchrun --nproc_per_node=4 --master_port=29501 train.py configs/my_config.py
```

### **Q4: KeyError: 'xxx' in config**

**原因**：配置文件缺少必要字段

**解决**：检查配置文件，确保包含所有必要字段（参考 `configs/copernicusfm_seg_default.py`）

---

## 📚 相关资源

### **官方文档**
- mmseg 使用指南：https://mmsegmentation.readthedocs.io/
- mmseg GitHub：https://github.com/open-mmlab/mmsegmentation

### **本项目**
- 配置文件：`configs/copernicusfm_seg_s2_eurosat.py`
- 模型定义：`copernicusfm/copernicusfm_seg.py`
- 预训练权重：`weights/CopernicusFM_ViT_base_varlang_e100.pth`

---

## 🎓 最佳实践

### **1. 从简单开始**

```bash
# 先用小数据集测试
python train.py configs/my_config.py \
    --cfg-options \
    data.samples_per_gpu=2 \
    runner.max_iters=1000

# 确认无误后再用完整数据集
python train.py configs/my_config.py
```

### **2. 保存重要实验**

```bash
# 为每个实验指定唯一的工作目录
python train.py configs/my_config.py \
    --work-dir work_dirs/exp_$(date +%Y%m%d_%H%M%S)
```

### **3. 监控训练**

```bash
# 实时查看日志
tail -f work_dirs/exp1/*.log

# 查看 TensorBoard
tensorboard --logdir work_dirs/exp1 --port 6006
```

### **4. 定期保存 checkpoint**

在配置文件中设置：
```python
checkpoint_config = dict(by_epoch=False, interval=2000)
```

---

## ✅ 快速参考卡

### **训练命令**

```bash
# 单 GPU
python tools/train.py <config> --work-dir <dir>

# 多 GPU
bash tools/dist_train.sh <config> <num_gpus> [--work-dir <dir>]

# 恢复训练
python tools/train.py <config> --resume-from <checkpoint>

# 覆盖配置
python tools/train.py <config> --cfg-options key=value
```

### **测试命令**

```bash
# 单 GPU
python tools/test.py <config> <checkpoint> --eval mIoU

# 多 GPU
bash tools/dist_test.sh <config> <checkpoint> <num_gpus> --eval mIoU

# 保存结果
python tools/test.py <config> <checkpoint> --out results.pkl --eval mIoU

# 可视化
python tools/test.py <config> <checkpoint> --show --show-dir vis/
```

---

**最后更新**: 2024年

**状态**: ✅ 生产就绪
