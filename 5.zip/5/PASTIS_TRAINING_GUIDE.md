# PASTIS 数据集训练指南

## 项目结构

```
copernicusfm_mmlab/
├── configs/
│   └── pastis/                              # PASTIS 配置文件
│       ├── config1_linear_probe_finetune.py  # 配置 1
│       ├── config2_linear_probe_only_decoder.py # 配置 2
│       ├── config3_upernet_finetune.py       # 配置 3
│       └── config4_upernet_only_decoder.py   # 配置 4
├── copernicusfm/
│   ├── datasets/
│   │   ├── __init__.py
│   │   └── pastis_dataset.py                # PASTIS 数据集
│   ├── hooks/
│   │   ├── __init__.py
│   │   └── freeze_backbone_hook.py          # 冻结骨干钩子
│   └── copernicusfm_temporal_seg.py          # 时序分割模型
├── tools/
│   ├── train_pastis.py                       # 训练脚本
│   └── test_pastis.py                        # 测试脚本
└── run_pastis.sh                            # 快速启动脚本
```

## 快速开始

### 1. 检查环境

```bash
# 进入项目目录
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab

# 激活环境
conda activate mmenv

# 检查 PyTorch
python -c "import torch; print('PyTorch:', torch.__version__); print('CUDA:', torch.cuda.is_available())"
```

### 2. 下载预训练权重

```bash
# 创建 weights 目录
mkdir -p weights

# 下载 CopernicusFM 权重
wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/
```

### 3. 检查数据集路径

确保 PASTIS 数据集在以下位置：
```
F:\PythonProject\PASTIS_evel\
├── metadata_summary.json
├── NORM_S2_patch.json
├── DATA_S2_PT/
│   ├── S2_1.pt
│   ├── S2_2.pt
│   └── ...
└── label_pt/
    ├── 1.pt
    ├── 2.pt
    └── ...
```

---

## 训练配置说明

### 配置 1: Copernicus-base + Linear Probe (Fine-tune)

```bash
python tools/train_pastis.py configs/pastis/config1_linear_probe_finetune.py
```

- **模型**: CopernicusFM-Base + Linear 分类头
- **策略**: 前 10 轮冻结骨干，之后全量训练
- **训练轮数**: 50 epochs
- **适合**: 快速验证，计算资源有限

### 配置 2: Copernicus-base + Linear Probe (Only Decoder)

```bash
python tools/train_pastis.py configs/pastis/config2_linear_probe_only_decoder.py
```

- **模型**: CopernicusFM-Base + Linear 分类头
- **策略**: 始终冻结骨干，只训练分类头
- **训练轮数**: 50 epochs
- **适合**: 最快训练速度，保持预训练特征

### 配置 3: Copernicus-base + UPerHead (Fine-tune)

```bash
python tools/train_pastis.py configs/pastis/config3_upernet_finetune.py
```

- **模型**: CopernicusFM-Base + UPerHead 分割头
- **策略**: 前 10 轮冻结骨干，之后全量训练
- **训练轮数**: 50 epochs
- **适合**: 最佳性能，计算资源充足

### 配置 4: Copernicus-base + UPerHead (Only Decoder)

```bash
python tools/train_pastis.py configs/pastis/config4_upernet_only_decoder.py
```

- **模型**: CopernicusFM-Base + UPerHead 分割头
- **策略**: 始终冻结骨干，只训练解码头
- **训练轮数**: 50 epochs
- **适合**: 平衡性能和训练速度

---

## 快速启动脚本

使用 `run_pastis.sh` 脚本快速启动训练：

```bash
# 配置 1
bash run_pastis.sh 1

# 配置 2
bash run_pastis.sh 2

# 配置 3
bash run_pastis.sh 3

# 配置 4
bash run_pastis.sh 4

# 指定工作目录
bash run_pastis.sh 3 --work-dir work_dirs/pastis_exp1
```

---

## 修改配置

### 修改模型尺寸

在配置文件中修改 `backbone.model_size`：

```python
model = dict(
    backbone=dict(
        model_size='large',  # 可选: 'base', 'large', 'small'
        embed_dim=1024,      # large: 1024, base: 768, small: 384
        depth=24,            # large: 24, base: 12, small: 12
    ),
    ...
)
```

### 修改时序融合策略

在配置文件中修改 `temporal_fusion`：

```python
model = dict(
    temporal_fusion='mean',  # 可选: 'mean', 'max'
    ...
)
```

### 修改数据集路径

在配置文件中修改 `data_root`：

```python
data_root = 'your/data/path'
```

### 修改训练参数

```python
# 修改 batch size
data = dict(
    samples_per_gpu=16,  # 根据 GPU 内存调整
    workers_per_gpu=4,
)

# 修改学习率
optimizer = dict(
    lr=0.0001,
)

# 修改训练轮数
runner = dict(
    max_epochs=100,
)
```

---

## 测试模型

### 测试脚本

```bash
# 测试配置 1
python tools/test_pastis.py \
    configs/pastis/config1_linear_probe_finetune.py \
    work_dirs/config1_linear_probe_finetune/latest.pth \
    --eval mIoU

# 测试配置 3
python tools/test_pastis.py \
    configs/pastis/config3_upernet_finetune.py \
    work_dirs/config3_upernet_finetune/latest.pth \
    --eval mIoU
```

### 保存测试结果

```bash
python tools/test_pastis.py \
    configs/pastis/config3_upernet_finetune.py \
    work_dirs/config3_upernet_finetune/latest.pth \
    --out results.pkl \
    --eval mIoU
```

---

## 常见问题

### Q1: CUDA 内存不足

**错误**: `RuntimeError: CUDA out of memory`

**解决**:
```bash
# 减少 batch size
data = dict(
    samples_per_gpu=4,  # 从 8 减少到 4
)

# 或者使用 gradient accumulation
optimizer_config = dict(
    type='GradientCumulativeOptimizerHook',
    cumulative_iters=4,
)
```

### Q2: 权重加载失败

**错误**: `Missing keys in state_dict`

**解决**:
- 确保使用正确的预训练权重
- 检查 `model_size` 配置是否匹配

### Q3: 数据集加载失败

**错误**: `FileNotFoundError`

**解决**:
- 检查 `data_root` 路径是否正确
- 确保 `metadata_summary.json` 存在
- 确保 `DATA_S2_PT/` 和 `label_pt/` 目录存在

### Q4: SyncBatchNorm 错误

**错误**: `SyncBatchNorm expected input tensor to be on GPU`

**解决**:
- 使用分布式训练
- 或将 SyncBatchNorm 改为 BatchNorm

---

## 性能对比

| 配置 | 模型 | 训练策略 | 预期 mIoU | 训练时间 |
|-----|------|---------|----------|---------|
| 1 | Linear Probe | 前10轮冻结 | ~60% | ~2小时 |
| 2 | Linear Probe | 只训练解码器 | ~55% | ~1小时 |
| 3 | UPerHead | 前10轮冻结 | ~70% | ~4小时 |
| 4 | UPerHead | 只训练解码器 | ~65% | ~2小时 |

*注: 实际性能取决于数据集和超参数设置*

---

## 进阶用法

### 分布式训练

```bash
# 2 GPU 训练
bash run_pastis.sh 3 --launcher pytorch --local_rank 0

# 或使用 torchrun
torchrun --nproc_per_node=2 tools/train_pastis.py \
    configs/pastis/config3_upernet_finetune.py \
    --launcher pytorch
```

### 恢复训练

```bash
python tools/train_pastis.py \
    configs/pastis/config3_upernet_finetune.py \
    --resume-from work_dirs/config3_upernet_finetune/latest.pth
```

### 加载预训练权重

```bash
python tools/train_pastis.py \
    configs/pastis/config3_upernet_finetune.py \
    --load-from pretrained.pth
```

---

## 联系方式

如有问题，请查看：
- README.md: 项目文档
- OFFICIAL_SCRIPTS_GUIDE.md: mmseg 官方脚本使用指南
- FINAL_REPORT.md: 完整项目报告

---

**最后更新**: 2024年

**状态**: ✅ 生产就绪
