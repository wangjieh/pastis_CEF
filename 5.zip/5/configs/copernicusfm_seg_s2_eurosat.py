"""CopernicusFM Segmentation for Sentinel-2 EuroSAT."""

_base_ = ['./copernicusfm_seg_default.py']

# Model configuration - override for Sentinel-2
model = dict(
    backbone=dict(
        model_size='base',
        out_indices=[5, 8, 11],
    ),
    decode_head=dict(
        num_classes=10,  # EuroSAT has 10 classes
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0)),
    auxiliary_head=dict(
        num_classes=10,  # EuroSAT has 10 classes
        loss_decode=dict(
            type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4)),
    pretrained='CopernicusFM_ViT_base_varlang_e100.pth',
)

# Dataset configuration for Sentinel-2
dataset_type = 'CustomDataset'
data_root = 'data/eurosat_s2'

# Sentinel-2 normalization (13 bands)
# You should compute these from your dataset
img_norm_cfg = dict(
    mean=[1353.7, 1117.2, 1041.8, 946.5, 1199.1, 2003.0, 2374.0, 2301.2,
          2599.7, 732.1, 12.1, 1820.6, 1118.2],
    std=[897.3, 736.0, 684.8, 620.0, 791.9, 1341.3, 1595.4, 1545.5,
         1750.1, 475.1, 98.3, 1216.5, 736.7],
    to_rgb=False)

crop_size = (224, 224)

# Training pipeline
train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations'),
    dict(type='Resize', img_scale=(224, 224), keep_ratio=True),
    dict(type='RandomFlip', prob=0.5),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='Pad', size=crop_size, pad_val=0, seg_pad_val=255),
    dict(type='DefaultFormatBundle'),
    dict(type='Collect', keys=['img', 'gt_semantic_seg']),
]

# Test pipeline
test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(
        type='MultiScaleFlipAug',
        img_scale=(224, 224),
        flip=False,
        transforms=[
            dict(type='Resize', keep_ratio=True),
            dict(type='Normalize', **img_norm_cfg),
            dict(type='ImageToTensor', keys=['img']),
            dict(type='Collect', keys=['img']),
        ])
]

data = dict(
    samples_per_gpu=16,
    workers_per_gpu=4,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        img_dir='images/train',
        ann_dir='annotations/train',
        pipeline=train_pipeline),
    val=dict(
        type=dataset_type,
        data_root=data_root,
        img_dir='images/val',
        ann_dir='annotations/val',
        pipeline=test_pipeline),
    test=dict(
        type=dataset_type,
        data_root=data_root,
        img_dir='images/test',
        ann_dir='annotations/test',
        pipeline=test_pipeline))

# Training settings
optimizer = dict(
    type='AdamW',
    lr=0.001,
    betas=(0.9, 0.999),
    weight_decay=0.05)

lr_config = dict(
    policy='poly',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1e-6,
    power=1.0,
    min_lr=0.0,
    by_epoch=False)

runner = dict(type='IterBasedRunner', max_iters=10000)
checkpoint_config = dict(by_epoch=False, interval=1000)
evaluation = dict(interval=1000, metric='mIoU', pre_eval=True)
