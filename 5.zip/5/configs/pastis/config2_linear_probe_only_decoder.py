"""配置 2: Copernicus-base + Linear Probe, 只训练解码器"""

# 模型配置
model = dict(
    type='CopernicusFMLinearProbe',
    backbone=dict(
        type='CopernicusFMViT',
        model_size='base',
        embed_dim=768,
        depth=12,
        out_indices=[3, 5, 7, 11],
    ),
    pretrained='weights/CopernicusFM_ViT_base_varlang_e100.pth',
    num_classes=19,
    temporal_fusion='mean',  # 可选 'mean' 或 'max'
)

# 数据集配置
dataset_type = 'PASTISDataset'
data_root = 'F:/PythonProject/PASTIS_evel'

img_norm_cfg = dict(
    mean=[0.0] * 13,
    std=[1.0] * 13,
    to_rgb=False,
)

train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadAnnotations'),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='DefaultFormatBundle'),
    dict(type='Collect', keys=['img', 'gt_semantic_seg']),
]

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(
        type='MultiScaleFlipAug',
        img_scale=(128, 128),
        flip=False,
        transforms=[
            dict(type='Normalize', **img_norm_cfg),
            dict(type='ImageToTensor', keys=['img']),
            dict(type='Collect', keys=['img']),
        ]),
]

data = dict(
    samples_per_gpu=8,
    workers_per_gpu=0,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        fold=[1, 2, 3],
        split='train',
        num_time_steps=12,
        img_size=128,
        pipeline=train_pipeline,
    ),
    val=dict(
        type=dataset_type,
        data_root=data_root,
        fold=4,
        split='val',
        num_time_steps=12,
        img_size=128,
        pipeline=test_pipeline,
    ),
    test=dict(
        type=dataset_type,
        data_root=data_root,
        fold=5,
        split='test',
        num_time_steps=12,
        img_size=128,
        pipeline=test_pipeline,
    ),
)

# 训练配置
optimizer = dict(
    type='AdamW',
    lr=0.001,
    betas=(0.9, 0.999),
    weight_decay=0.01,
)

optimizer_config = dict(
    grad_clip=dict(max_norm=1.0, norm_type=2),
)

# 学习率调度
lr_config = dict(
    policy='poly',
    warmup='linear',
    warmup_iters=100,
    warmup_ratio=1e-6,
    power=1.0,
    min_lr=0.0,
    by_epoch=True,
)

# 迭代器
runner = dict(type='EpochBasedRunner', max_epochs=50)

# 检查点配置
checkpoint_config = dict(by_epoch=True, interval=10)

# 评估配置
evaluation = dict(interval=5, metric='mIoU', pre_eval=True)

# 日志配置
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook', by_epoch=True),
    ])

# 分布式训练配置
dist_params = dict(backend='nccl')
log_level = 'INFO'
load_from = None
resume_from = None
workflow = [('train', 1)]

# 自定义钩子：始终冻结骨干（只训练解码器）
custom_hooks = [
    dict(
        type='FreezeBackboneHook',
        freeze_epochs=999,  # 始终冻结
    ),
]

# fp16 配置
fp16 = dict(loss_scale=512.)
