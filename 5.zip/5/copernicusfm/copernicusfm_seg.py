"""CopernicusFM Segmentation Model for mmseg."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple, Union

from mmengine.model import BaseModule
from mmseg.models.builder import MODELS
from mmseg.models.decode_heads import UPerHead, FCNHead
from mmseg.models.necks import Feature2Pyramid
from mmseg.utils import add_prefix

from .models_dwv_seg import vit_base_patch16, vit_large_patch16, vit_small_patch16


@MODELS.register_module()
class CopernicusFMSeg(BaseModule):
    """CopernicusFM Segmentation Model.

    This model uses CopernicusFM as the backbone and adds segmentation heads
    for semantic segmentation tasks.

    Args:
        backbone (dict): Config dict for backbone.
        neck (dict): Config dict for neck. Default: None.
        decode_head (dict): Config dict for decode head.
        auxiliary_head (dict): Config dict for auxiliary head. Default: None.
        pretrained (str): Path to pretrained weights. Default: None.
        train_cfg (dict): Config dict for training. Default: None.
        test_cfg (dict): Config dict for testing. Default: None.
    """

    def __init__(self,
                 backbone: Dict,
                 neck: Optional[Dict] = None,
                 decode_head: Dict = None,
                 auxiliary_head: Optional[Dict] = None,
                 pretrained: Optional[str] = None,
                 train_cfg: Optional[Dict] = None,
                 test_cfg: Optional[Dict] = None,
                 init_cfg: Optional[Dict] = None):
        super().__init__(init_cfg=init_cfg)

        # Build backbone (CopernicusFM encoder)
        self.backbone = self._build_backbone(backbone)

        # Build neck (Feature2Pyramid)
        if neck is not None:
            self.neck = MODELS.build(neck)

        # Build decode head (UPerHead)
        self.decode_head = MODELS.build(decode_head)

        # Build auxiliary head (FCNHead)
        if auxiliary_head is not None:
            self.auxiliary_head = MODELS.build(auxiliary_head)

        # Load pretrained weights
        if pretrained is not None:
            self._load_pretrained_weights(pretrained)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

    def _build_backbone(self, backbone_cfg: Dict) -> nn.Module:
        """Build CopernicusFM backbone."""
        model_size = backbone_cfg.get('model_size', 'base')
        out_indices = backbone_cfg.get('out_indices', [5, 8, 11])

        if model_size == 'base':
            backbone = vit_base_patch16(out_indices=out_indices)
        elif model_size == 'large':
            backbone = vit_large_patch16(out_indices=out_indices)
        elif model_size == 'small':
            backbone = vit_small_patch16(out_indices=out_indices)
        else:
            raise ValueError(f'Unknown model size: {model_size}')

        return backbone

    def _load_pretrained_weights(self, pretrained_path: str):
        """Load pretrained weights."""
        import os
        from torchvision.datasets.utils import download_url

        url = "https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/{}"
        dir = os.getenv("MODEL_WEIGHTS_DIR", "weights")
        filename = os.path.basename(pretrained_path)
        path = os.path.join(dir, filename)

        if not os.path.exists(path):
            print(f'Downloading pretrained weights to {path}...')
            download_url(url.format(filename), dir, filename=filename)

        checkpoint = torch.load(path, map_location='cpu')
        if 'model' in checkpoint:
            state_dict = checkpoint['model']
        else:
            state_dict = checkpoint

        # Load weights with strict=False to allow missing keys
        msg = self.backbone.load_state_dict(state_dict, strict=False)
        print(f'Loaded pretrained weights: {msg}')

    def extract_feat(self, img: torch.Tensor,
                     img_metas: List[Dict]) -> Tuple[torch.Tensor]:
        """Extract features from images.

        Args:
            img (torch.Tensor): Input images.
            img_metas (list[dict]): List of image info dict.

        Returns:
            tuple[Tensor]: Multi-level features.
        """
        # Extract meta information
        metas = self._prepare_meta(img_metas, img.device)

        # Extract features from backbone
        feats = self.backbone(img, metas)

        # Apply neck if exists
        if hasattr(self, 'neck'):
            feats = self.neck(feats)

        return feats

    def _prepare_meta(self, img_metas: List[Dict],
                      device: torch.device) -> torch.Tensor:
        """Prepare meta information for backbone.

        Args:
            img_metas (list[dict]): List of image info dict.
            device: Target device.

        Returns:
            torch.Tensor: Meta information tensor.
        """
        batch_metas = []
        for meta in img_metas:
            lon = meta.get('lon', float('nan'))
            lat = meta.get('lat', float('nan'))
            time = meta.get('time', float('nan'))
            area = meta.get('area', float('nan'))
            batch_metas.append([lon, lat, time, area])

        return torch.tensor(batch_metas, dtype=torch.float32, device=device)

    def forward_train(self, img: torch.Tensor,
                      img_metas: List[Dict],
                      gt_semantic_seg: torch.Tensor,
                      **kwargs) -> Dict[str, torch.Tensor]:
        """Forward training.

        Args:
            img (torch.Tensor): Input images.
            img_metas (list[dict]): List of image info dict.
            gt_semantic_seg (torch.Tensor): Ground truth segmentation masks.

        Returns:
            dict[str, Tensor]: Losses.
        """
        # Extract features
        feats = self.extract_feat(img, img_metas)

        # Decode head forward
        losses = dict()
        loss_decode = self._decode_head_forward_train(feats, img_metas,
                                                       gt_semantic_seg)
        losses.update(loss_decode)

        # Auxiliary head forward
        if hasattr(self, 'auxiliary_head'):
            loss_aux = self._auxiliary_head_forward_train(
                feats, img_metas, gt_semantic_seg)
            losses.update(loss_aux)

        return losses

    def _decode_head_forward_train(self, feats: Tuple[torch.Tensor],
                                   img_metas: List[Dict],
                                   gt_semantic_seg: torch.Tensor
                                   ) -> Dict[str, torch.Tensor]:
        """Run forward and calculate loss for decode head."""
        seg_logits = self.decode_head(feats)
        losses = self.decode_head.losses(seg_logits, gt_semantic_seg)
        return losses

    def _auxiliary_head_forward_train(self, feats: Tuple[torch.Tensor],
                                      img_metas: List[Dict],
                                      gt_semantic_seg: torch.Tensor
                                      ) -> Dict[str, torch.Tensor]:
        """Run forward and calculate loss for auxiliary head."""
        seg_logits = self.auxiliary_head(feats)
        losses = self.auxiliary_head.losses(seg_logits, gt_semantic_seg)
        return losses

    def forward_test(self, img: torch.Tensor,
                     img_metas: List[Dict],
                     **kwargs) -> List[torch.Tensor]:
        """Forward testing.

        Args:
            img (torch.Tensor): Input images.
            img_metas (list[dict]): List of image info dict.

        Returns:
            list[Tensor]: Segmentation logits.
        """
        # Extract features
        feats = self.extract_feat(img, img_metas)

        # Decode head forward
        seg_logits = self.decode_head(feats)

        # Resize to original size
        seg_logits = F.interpolate(
            seg_logits,
            size=img.shape[2:],
            mode='bilinear',
            align_corners=False)

        return [seg_logits]

    def forward(self, img, img_metas, return_loss=True, **kwargs):
        """Forward function."""
        if return_loss:
            return self.forward_train(img, img_metas, **kwargs)
        else:
            return self.forward_test(img, img_metas, **kwargs)
