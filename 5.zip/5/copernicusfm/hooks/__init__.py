"""Hooks for CopernicusFM."""

from .freeze_backbone_hook import FreezeBackboneHook

__all__ = ['FreezeBackboneHook']
