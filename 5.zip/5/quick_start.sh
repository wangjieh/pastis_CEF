#!/bin/bash
# CopernicusFM Quick Start Script

set -e

echo "=========================================="
echo "CopernicusFM for OpenMMLab - Quick Start"
echo "=========================================="

# Check environment
echo "1. Checking environment..."
if ! conda activate mmenv 2>/dev/null; then
    echo "Warning: mmenv not found, using current environment"
fi

# Check PyTorch
python -c "import torch; print('PyTorch:', torch.__version__)" || {
    echo "Error: PyTorch not installed"
    exit 1
}

# Check mmcv/mmseg
python -c "import mmcv; print('mmcv:', mmcv.__version__)" || {
    echo "Warning: mmcv not installed. Install with: pip install mmcv-full"
}

python -c "import mmseg; print('mmseg:', mmseg.__version__)" || {
    echo "Warning: mmseg not installed. Install with: pip install mmseg"
}

echo ""
echo "2. Project structure:"
echo "   copernicusfm_mmlab/"
echo "   ├── copernicusfm/      # Model definition"
echo "   ├── configs/           # Configuration files"
echo "   ├── tools/             # Train/test scripts"
echo "   └── tests/             # Test scripts"

echo ""
echo "3. Quick verification..."
cd "$(dirname "$0")"
python tests/test_model.py || {
    echo "Error: Model verification failed"
    exit 1
}

echo ""
echo "=========================================="
echo "✓ Quick start complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Prepare your dataset (see README.md)"
echo "2. Download pretrained weights:"
echo "   mkdir -p weights"
echo "   wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/"
echo ""
echo "3. Modify config file:"
echo "   configs/copernicusfm_seg_s2_eurosat.py"
echo ""
echo "4. Start training:"
echo "   python tools/train.py configs/copernicusfm_seg_s2_eurosat.py"
echo ""
echo "5. Run tests:"
echo "   python tools/test.py configs/copernicusfm_seg_s2_eurosat.py <checkpoint> --eval mIoU"
echo ""
