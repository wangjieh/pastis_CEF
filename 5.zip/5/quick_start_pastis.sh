#!/bin/bash
# PASTIS 快速开始脚本

set -e

echo "=========================================="
echo "PASTIS 训练快速开始"
echo "=========================================="

# 1. 检查环境
echo "1. 检查环境..."
conda activate mmenv
python -c "import torch; print('PyTorch:', torch.__version__); print('CUDA:', torch.cuda.is_available())" || {
    echo "错误: PyTorch 未安装或 CUDA 不可用"
    exit 1
}

# 2. 检查预训练权重
echo ""
echo "2. 检查预训练权重..."
WEIGHT_PATH="weights/CopernicusFM_ViT_base_varlang_e100.pth"
if [ ! -f "$WEIGHT_PATH" ]; then
    echo "预训练权重不存在，正在下载..."
    mkdir -p weights
    wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/
else
    echo "✓ 预训练权重存在: $WEIGHT_PATH"
fi

# 3. 检查数据集
echo ""
echo "3. 检查数据集..."
DATA_ROOT="F:/PythonProject/PASTIS_evel"
if [ ! -d "$DATA_ROOT" ]; then
    echo "错误: PASTIS 数据集不存在: $DATA_ROOT"
    exit 1
fi

if [ ! -f "$DATA_ROOT/metadata_summary.json" ]; then
    echo "错误: metadata_summary.json 不存在"
    exit 1
fi

echo "✓ 数据集检查通过"

# 4. 显示可用配置
echo ""
echo "4. 可用配置:"
echo "  1: Copernicus-base + Linear Probe, 前10轮冻结骨干，之后全量训练"
echo "  2: Copernicus-base + Linear Probe, 只训练解码器"
echo "  3: Copernicus-base + UPerHead, 前10轮冻结骨干，之后全量训练"
echo "  4: Copernicus-base + UPerHead, 只训练解码器"

# 5. 提示运行
echo ""
echo "=========================================="
echo "✓ 环境检查完成！"
echo "=========================================="
echo ""
echo "开始训练:"
echo "  bash run_pastis.sh 1  # 配置 1"
echo "  bash run_pastis.sh 2  # 配置 2"
echo "  bash run_pastis.sh 3  # 配置 3"
echo "  bash run_pastis.sh 4  # 配置 4"
echo ""
echo "或直接使用 Python:"
echo "  python tools/train_pastis.py configs/pastis/config1_linear_probe_finetune.py"
echo ""
