#!/bin/bash
# PASTIS 训练快速启动脚本

set -e

# 检查参数
if [ $# -lt 1 ]; then
    echo "用法: bash run_pastis.sh <config_num> [其他参数]"
    echo "  config_num: 1, 2, 3, 4"
    echo ""
    echo "配置说明:"
    echo "  1: Copernicus-base + Linear Probe, 前10轮冻结骨干，之后全量训练"
    echo "  2: Copernicus-base + Linear Probe, 只训练解码器"
    echo "  3: Copernicus-base + UPerHead, 前10轮冻结骨干，之后全量训练"
    echo "  4: Copernicus-base + UPerHead, 只训练解码器"
    echo ""
    echo "示例:"
    echo "  bash run_pastis.sh 1"
    echo "  bash run_pastis.sh 3 --work-dir work_dirs/pastis_exp1"
    exit 1
fi

CONFIG_NUM=$1
shift

# 配置文件映射
case $CONFIG_NUM in
    1)
        CONFIG="configs/pastis/config1_linear_probe_finetune.py"
        ;;
    2)
        CONFIG="configs/pastis/config2_linear_probe_only_decoder.py"
        ;;
    3)
        CONFIG="configs/pastis/config3_upernet_finetune.py"
        ;;
    4)
        CONFIG="configs/pastis/config4_upernet_only_decoder.py"
        ;;
    *)
        echo "错误: 无效的配置编号 $CONFIG_NUM"
        exit 1
        ;;
esac

# 检查配置文件是否存在
if [ ! -f "$CONFIG" ]; then
    echo "错误: 配置文件不存在: $CONFIG"
    exit 1
fi

# 运行训练
echo "=========================================="
echo "PASTIS 训练 - 配置 $CONFIG_NUM"
echo "=========================================="
echo "配置文件: $CONFIG"
echo "=========================================="

# 激活环境
conda activate mmenv

# 运行训练脚本
python tools/train_pastis.py "$CONFIG" "$@"

echo ""
echo "训练完成！"
