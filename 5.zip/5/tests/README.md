# 测试脚本说明

## 📋 测试文件清单

### 1. init_copernicusfm_base.py ⭐ 主要测试

**功能**：初始化 CopernicusFM-Base 模型并加载预训练权重

**测试内容**：
- ✅ 模型初始化
- ✅ 预训练权重加载
- ✅ 模型结构分析
- ✅ 前向传播测试
- ✅ 分割头集成测试（可选）

**使用方法**：
```bash
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab
conda activate mmenv
python tests/init_copernicusfm_base.py
```

**输出**：
- 控制台：详细的测试过程和结果
- 文件：`tests/model_init_report.txt`（测试报告）

---

### 2. test_model.py（已有）

**功能**：基本的模型功能测试

**使用方法**：
```bash
python tests/test_model.py
```

---

## 🚀 快速开始

### 步骤 1：下载预训练权重

```bash
# 创建 weights 目录
mkdir -p weights

# 下载权重（选择一种方式）
# 方式 1：直接下载
wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/

# 方式 2：使用 huggingface-hub
pip install huggingface-hub
python -c "from huggingface_hub import hf_hub_download; hf_hub_download(repo_id='wangyi111/Copernicus-FM', filename='CopernicusFM_ViT_base_varlang_e100.pth', local_dir='weights')"
```

### 步骤 2：运行测试

```bash
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab
conda activate mmenv
python tests/init_copernicusfm_base.py
```

### 步骤 3：查看结果

测试完成后会显示：
- 模型参数统计
- 权重加载状态
- 前向传播结果
- 测试报告路径

---

## 📊 预期输出示例

```
================================================================================
  CopernicusFM-Base 模型初始化和预训练权重加载测试
================================================================================

================================================================================
  1. 模型初始化
================================================================================
✓ 成功导入 vit_base_patch16

正在初始化 CopernicusFM-Base 模型...
✓ 模型初始化成功！

参数统计:
  总参数数量: 86,567,872
  可训练参数: 86,567,872
  模型大小: 330.3 MB (float32)

================================================================================
  2. 加载预训练权重
================================================================================
✓ 找到权重文件: weights/CopernicusFM_ViT_base_varlang_e100.pth
  文件大小: 533.0 MB

正在加载权重...
加载结果:
  成功加载: 210 层
  缺失的键: 0
  多余的键: 0

✓ 权重加载完美！所有层都匹配。

...

================================================================================
  测试总结
================================================================================

测试结果:
  模型初始化: ✓ 成功
  权重加载: ✓ 成功
  前向传播: ✓ 成功
  分割头: ✓ 成功

总体结果: ✓ 全部通过！

================================================================================
  🎉 恭喜！CopernicusFM-Base 模型初始化成功！
================================================================================
```

---

## 🔧 故障排除

### 问题 1：找不到权重文件

**错误信息**：
```
✗ 权重文件不存在: weights/CopernicusFM_ViT_base_varlang_e100.pth
```

**解决**：
```bash
# 下载权重
wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/
```

### 问题 2：导入错误

**错误信息**：
```
ModuleNotFoundError: No module named 'copernicusfm'
```

**解决**：
```bash
# 确保在正确的目录运行
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm_mmlab
python tests/init_copernicusfm_base.py
```

### 问题 3：CUDA 内存不足

**错误信息**：
```
RuntimeError: CUDA out of memory
```

**解决**：
测试脚本使用 CPU 进行测试，不会出现此问题。如果在 GPU 上测试，请减少 batch size。

### 问题 4：mmseg 导入错误

**错误信息**：
```
ImportError: cannot import name 'UPerHead' from 'mmseg.models.decode_heads'
```

**解决**：
```bash
# 安装 mmseg
pip install mmsegmentation
```

---

## 📝 测试报告

测试完成后，会在 `tests/model_init_report.txt` 生成报告，包含：
- 模型配置
- 参数统计
- 测试结果
- 性能指标

---

## 💡 进阶使用

### 自定义测试参数

修改 `init_copernicusfm_base.py` 中的参数：

```python
# 修改图像大小
img_size = 512  # 默认 224

# 修改通道数
num_channels = 13  # Sentinel-2 13 波段

# 修改 batch size
batch_size = 4
```

### 在 GPU 上测试

```python
# 将模型移到 GPU
model = model.cuda()

# 将输入移到 GPU
dummy_img = dummy_img.cuda()
dummy_meta = dummy_meta.cuda()
```

### 测试不同的模型规模

```python
# ViT-Large
from copernicusfm.models_dwv_seg import vit_large_patch16
model = vit_large_patch16(out_indices=[5, 8, 11])

# ViT-Small
from copernicusfm.models_dwv_seg import vit_small_patch16
model = vit_small_patch16(out_indices=[5, 8, 11])
```

---

## 📚 相关文档

- **README.md**: 项目主文档
- **OFFICIAL_SCRIPTS_GUIDE.md**: mmseg 官方脚本使用指南
- **MIGRATION_SUMMARY.md**: 迁移技术总结
- **FINAL_REPORT.md**: 完整项目报告

---

## 🐛 报告问题

如果测试失败，请提供：
1. 完整的错误信息
2. Python 和 mmseg 版本
3. 操作系统和 GPU 信息
4. 权重文件是否完整

---

**最后更新**: 2024年

**维护状态**: ✅ 活跃维护中
