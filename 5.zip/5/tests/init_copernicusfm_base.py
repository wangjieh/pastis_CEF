"""
CopernicusFM-Base 模型初始化和预训练权重加载测试脚本

功能：
1. 初始化 CopernicusFM-Base 模型
2. 加载预训练权重
3. 验证模型结构和参数
4. 测试前向传播

使用方法：
    conda activate mmenv
    python tests/init_copernicusfm_base.py
"""

import sys
import os
import torch
import numpy as np

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

def print_header(title):
    """打印带格式的标题"""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80)

def print_section(title):
    """打印段落标题"""
    print(f"\n{'─' * 60}")
    print(f"  {title}")
    print(f"{'─' * 60}")

def test_model_initialization():
    """测试模型初始化"""
    print_header("1. 模型初始化")

    try:
        from copernicusfm.models_dwv_seg import vit_base_patch16

        print("[OK] 成功导入 vit_base_patch16")

        # 初始化模型
        print("\n正在初始化 CopernicusFM-Base 模型...")
        print("  (注意: 跳过 variable embedding，仅测试 spectral 模式)")

        # 直接使用 models_dwv_seg 中的 CopernicusFMViT
        from copernicusfm.models_dwv_seg import CopernicusFMViT
        import torch.nn as nn
        from functools import partial

        model = CopernicusFMViT(
            img_size=224,
            patch_size=16,
            embed_dim=768,
            depth=12,
            num_heads=12,
            mlp_ratio=4,
            norm_layer=partial(nn.LayerNorm, eps=1e-6),
            out_indices=[3, 5, 7, 11],
            var_option='language',
            loc_option='lonlat',
        )

        print("[OK] 模型初始化成功！")

        # 统计参数
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        print(f"\n参数统计:")
        print(f"  总参数数量: {total_params:,}")
        print(f"  可训练参数: {trainable_params:,}")
        print(f"  模型大小: {total_params * 4 / 1024**2:.1f} MB (float32)")

        return model

    except Exception as e:
        print(f"[FAIL] 模型初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def load_pretrained_weights(model, weight_path):
    """加载预训练权重"""
    print_header("2. 加载预训练权重")

    if not os.path.exists(weight_path):
        print(f"[FAIL] 权重文件不存在: {weight_path}")
        print("\n请下载预训练权重:")
        print("  1. 从 HuggingFace 下载:")
        print("     wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/")
        print("\n  2. 或使用 huggingface-hub:")
        print("     pip install huggingface-hub")
        print("     python -c \"from huggingface_hub import hf_hub_download; hf_hub_download(repo_id='wangyi111/Copernicus-FM', filename='CopernicusFM_ViT_base_varlang_e100.pth', local_dir='weights')\"")
        return None

    print(f"[OK] 找到权重文件: {weight_path}")
    print(f"  文件大小: {os.path.getsize(weight_path) / 1024**2:.1f} MB")

    try:
        # 加载权重
        print("\n正在加载权重...")
        checkpoint = torch.load(weight_path, map_location='cpu')

        # 检查权重格式
        if isinstance(checkpoint, dict):
            print(f"  权重类型: dict")
            print(f"  包含的键: {list(checkpoint.keys())[:5]}...")

            if 'model' in checkpoint:
                state_dict = checkpoint['model']
                print("  使用 'model' 键")
            elif 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
                print("  使用 'state_dict' 键")
            else:
                state_dict = checkpoint
                print("  直接使用顶层字典")
        else:
            state_dict = checkpoint
            print(f"  权重类型: 直接的 state_dict")

        print(f"  权重层数: {len(state_dict)}")

        # 加载到模型
        print("\n正在将权重加载到模型...")
        msg = model.load_state_dict(state_dict, strict=False)

        print("\n加载结果:")
        print(f"  成功加载: {len(state_dict) - len(msg.missing_keys)} 层")
        print(f"  缺失的键: {len(msg.missing_keys)}")
        print(f"  多余的键: {len(msg.unexpected_keys)}")

        if msg.missing_keys:
            print("\n  缺失的键（前 10 个）:")
            for key in msg.missing_keys[:10]:
                print(f"    - {key}")
            if len(msg.missing_keys) > 10:
                print(f"    ... 还有 {len(msg.missing_keys) - 10} 个")

        if msg.unexpected_keys:
            print("\n  多余的键（前 10 个）:")
            for key in msg.unexpected_keys[:10]:
                print(f"    - {key}")
            if len(msg.unexpected_keys) > 10:
                print(f"    ... 还有 {len(msg.unexpected_keys) - 10} 个")

        # 检查加载状态
        if len(msg.missing_keys) == 0 and len(msg.unexpected_keys) == 0:
            print("\n[OK] 权重加载完美！所有层都匹配。")
        elif len(msg.missing_keys) <= 5:  # 允许少量缺失（如分类头）
            print("\n[OK] 权重加载成功！（少量层缺失是正常的，如分类头）")
        else:
            print("\n[WARN] 权重加载完成，但有较多层不匹配。请检查模型配置。")

        return model

    except Exception as e:
        print(f"\n[FAIL] 权重加载失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def analyze_model_structure(model):
    """分析模型结构"""
    print_header("3. 模型结构分析")

    print_section("3.1 主要模块")

    # 遍历主要模块
    modules = {}
    for name, module in model.named_children():
        modules[name] = module
        param_count = sum(p.numel() for p in module.parameters())
        print(f"  {name}: {module.__class__.__name__} ({param_count:,} 参数)")

    print_section("3.2 关键参数形状")

    # 获取关键参数
    key_params = {
        'cls_token': model.cls_token,
        'pos_embed': model.pos_embed,
    }

    for name, param in key_params.items():
        print(f"  {name}: {param.shape}")

    # 检查 blocks
    if hasattr(model, 'blocks'):
        print(f"\n  Transformer Blocks: {len(model.blocks)} 层")
        block = model.blocks[0]
        print(f"  Block 结构: {block.__class__.__name__}")

        # 检查注意力头数
        if hasattr(block, 'attn'):
            attn = block.attn
            if hasattr(attn, 'num_heads'):
                print(f"  注意力头数: {attn.num_heads}")

    # 检查 MLP 比例
    if hasattr(model.blocks[0], 'mlp'):
        mlp = model.blocks[0].mlp
        if hasattr(mlp, 'fc1'):
            in_features = mlp.fc1.in_features
            out_features = mlp.fc1.out_features
            mlp_ratio = out_features / in_features
            print(f"  MLP 比例: {mlp_ratio:.1f}x")

    print_section("3.3 Patch Embedding")

    # 检查 patch embedding 类型
    has_spectral = hasattr(model, 'patch_embed_spectral')
    has_variable = hasattr(model, 'patch_embed_variable')

    print(f"  Spectral Embedding: {'[OK]' if has_spectral else '[FAIL]'}")
    print(f"  Variable Embedding: {'[OK]' if has_variable else '[FAIL]'}")

    if has_spectral:
        print(f"    - 权重生成器: {model.patch_embed_spectral.weight_generator.__class__.__name__}")

    print_section("3.4 位置编码器")

    # 检查位置编码
    has_coord = hasattr(model, 'coord_fc')
    has_time = hasattr(model, 'time_fc')
    has_scale = hasattr(model, 'scale_fc')

    print(f"  坐标编码: {'[OK]' if has_coord else '[FAIL]'}")
    print(f"  时间编码: {'[OK]' if has_time else '[FAIL]'}")
    print(f"  尺度编码: {'[OK]' if has_scale else '[FAIL]'}")

def test_forward_pass(model):
    """测试前向传播"""
    print_header("4. 前向传播测试 (Spectral 模式)")

    try:
        # 准备输入
        batch_size = 2
        img_size = 224
        num_channels = 13  # Sentinel-2 13 波段

        print(f"输入配置:")
        print(f"  批次大小: {batch_size}")
        print(f"  图像大小: {img_size}x{img_size}")
        print(f"  通道数: {num_channels} (Sentinel-2)")

        # 创建虚拟输入（Sentinel-2 13 波段）
        dummy_img = torch.randn(batch_size, num_channels, img_size, img_size)
        print(f"  输入形状: {dummy_img.shape}")

        # 创建元信息
        dummy_meta = torch.tensor([
            [120.0, 30.0, 100.0, 1.0],  # lon, lat, time, area
            [121.0, 31.0, 101.0, 1.0]
        ])
        print(f"  元信息形状: {dummy_meta.shape}")

        # 准备光谱参数（Sentinel-2 波长和带宽）
        wave_list = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]  # nm
        bandwidth = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]  # nm

        print(f"\n光谱参数:")
        print(f"  波长范围: {min(wave_list)} - {max(wave_list)} nm")
        print(f"  带宽范围: {min(bandwidth)} - {max(bandwidth)} nm")
        print(f"  输入模式: spectral")

        # Spectral 模式的额外参数
        key = None  # spectral 模式不需要 key
        language_embed = None  # spectral 模式不需要语言嵌入
        input_mode = 'spectral'

        # 测试特征提取
        print("\n正在执行前向传播...")
        model.eval()

        with torch.no_grad():
            # 提取多尺度特征
            features = model(
                dummy_img,
                dummy_meta,
                key,
                wave_list,
                bandwidth,
                language_embed,
                input_mode
            )

            print("\n[OK] 前向传播成功！")
            print(f"\n输出特征:")
            print(f"  特征层数: {len(features)}")

            for i, feat in enumerate(features):
                print(f"  Level {i}: {feat.shape}")

        # 计算 FLOPs（可选）
        print("\n性能统计:")
        print(f"  输入尺寸: {dummy_img.shape}")
        print(f"  输出尺寸: {features[-1].shape}")

        return True

    except Exception as e:
        print(f"\n[FAIL] 前向传播失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_segmentation_head(model):
    """测试分割头"""
    print_header("5. 分割头测试（可选）")

    try:
        from mmseg.models.decode_heads import UPerHead, FCNHead
        from mmseg.models.necks import Feature2Pyramid

        print("[OK] 成功导入 mmseg 组件")

        # 构建 neck
        print("\n正在构建 Neck (Feature2Pyramid)...")
        neck = Feature2Pyramid(
            embed_dim=768,
            rescales=[4, 2, 1, 0.5]
        )
        print("[OK] Neck 构建成功")

        # 构建 decode head
        print("\n正在构建 Decode Head (UPerHead)...")
        decode_head = UPerHead(
            in_channels=[768, 768, 768, 768],
            in_index=[0, 1, 2, 3],
            pool_scales=(1, 2, 3, 6),
            channels=512,
            dropout_ratio=0.1,
            num_classes=10,  # 示例类别数
            norm_cfg=dict(type='SyncBN', requires_grad=True),
            align_corners=False,
            loss_decode=dict(
                type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0
            )
        )
        print("[OK] Decode Head 构建成功")

        # 测试完整前向传播
        print("\n正在测试完整前向传播（Backbone + Neck + Head）...")

        # 准备输入
        dummy_img = torch.randn(1, 13, 224, 224)  # 13 波段
        dummy_meta = torch.tensor([[120.0, 30.0, 100.0, 1.0]])

        # 光谱参数
        wave_list = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
        bandwidth = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]
        key = None
        language_embed = None
        input_mode = 'spectral'

        model.eval()
        neck.eval()
        decode_head.eval()

        with torch.no_grad():
            # 提取特征
            feats = model(
                dummy_img,
                dummy_meta,
                key,
                wave_list,
                bandwidth,
                language_embed,
                input_mode
            )
            print(f"  Backbone 输出: {len(feats)} 层")

            # Neck
            feats_neck = neck(feats)
            print(f"  Neck 输出: {len(feats_neck)} 层")

            # Decode head
            seg_logits = decode_head(feats_neck)
            print(f"  Head 输出形状: {seg_logits.shape}")

            # 上采样到原始大小
            seg_logits_up = torch.nn.functional.interpolate(
                seg_logits,
                size=dummy_img.shape[2:],
                mode='bilinear',
                align_corners=False
            )
            print(f"  上采样后形状: {seg_logits_up.shape}")

        print("\n[OK] 完整前向传播测试成功！")
        return True

    except ImportError as e:
        print(f"\n[WARN] 跳过分割头测试: 缺少 mmseg 组件")
        print(f"  错误: {e}")
        print("\n如需测试分割头，请安装 mmseg:")
        print("  pip install mmsegmentation")
        return None

    except Exception as e:
        print(f"\n[FAIL] 分割头测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def save_test_report(model, success):
    """保存测试报告"""
    print_header("6. 测试报告")

    report = {
        'model_type': 'CopernicusFM-Base',
        'embed_dim': 768,
        'depth': 12,
        'total_params': sum(p.numel() for p in model.parameters()),
        'model_size_mb': sum(p.numel() for p in model.parameters()) * 4 / 1024**2,
        'forward_pass': success,
    }

    print("\n模型信息:")
    for key, value in report.items():
        print(f"  {key}: {value}")

    # 保存报告
    report_path = os.path.join(project_root, 'tests', 'model_init_report.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("CopernicusFM-Base 模型初始化报告\n")
        f.write("=" * 80 + "\n\n")

        f.write("测试结果:\n")
        f.write(f"  模型初始化: {'成功' if model else '失败'}\n")
        f.write(f"  前向传播: {'成功' if success else '失败'}\n\n")

        f.write("模型配置:\n")
        f.write(f"  类型: CopernicusFM-Base\n")
        f.write(f"  嵌入维度: 768\n")
        f.write(f"  深度: 12 层\n")
        f.write(f"  参数量: {report['total_params']:,}\n")
        f.write(f"  模型大小: {report['model_size_mb']:.1f} MB\n")

    print(f"\n[OK] 测试报告已保存: {report_path}")

def main():
    """主测试函数"""
    print_header("CopernicusFM-Base 模型初始化和预训练权重加载测试")

    # 设置路径
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    weight_path = os.path.join(project_root, 'weights', 'CopernicusFM_ViT_base_varlang_e100.pth')

    print(f"项目根目录: {project_root}")
    print(f"权重路径: {weight_path}")

    # 1. 初始化模型
    model = test_model_initialization()
    if model is None:
        print("\n[FAIL] 测试终止：模型初始化失败")
        return 1

    # 2. 加载预训练权重
    model = load_pretrained_weights(model, weight_path)

    # 3. 分析模型结构
    analyze_model_structure(model)

    # 4. 测试前向传播
    forward_success = test_forward_pass(model)

    # 5. 测试分割头（可选）
    seg_success = test_segmentation_head(model)

    # 6. 保存测试报告
    save_test_report(model, forward_success)

    # 总结
    print_header("测试总结")

    results = [
        ("模型初始化", model is not None),
        ("权重加载", model is not None),
        ("前向传播", forward_success),
    ]

    if seg_success is not None:
        results.append(("分割头", seg_success))

    print("\n测试结果:")
    for name, success in results:
        status = "[OK] 成功" if success else "[FAIL] 失败"
        print(f"  {name}: {status}")

    all_success = all(success for _, success in results if success is not None)

    print(f"\n总体结果: {'[OK] 全部通过！' if all_success else '[FAIL] 部分测试失败'}")

    if all_success:
        print("\n" + "=" * 80)
        print("  [SUCCESS] 恭喜！CopernicusFM-Base 模型初始化成功！")
        print("=" * 80)
        print("\n后续步骤:")
        print("  1. 查看测试报告: tests/model_init_report.txt")
        print("  2. 准备数据集（参考 README.md）")
        print("  3. 修改配置文件（configs/copernicusfm_seg_s2_eurosat.py）")
        print("  4. 开始训练（使用 mmseg 官方 train.py）")

    return 0 if all_success else 1

if __name__ == '__main__':
    sys.exit(main())
