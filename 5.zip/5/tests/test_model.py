# CopernicusFM for OpenMMLab

基于 Copernicus Foundation Model 的图像分割模型，适配 OpenMMLab (mmseg) 框架。

## 项目结构

```
copernicusfm_mmlab/
├── copernicusfm/                # 模型定义
│   ├── __init__.py             # 模块初始化
│   ├── copernicusfm_seg.py     # 分割模型包装器（继承 mmseg）
│   ├── models_dwv.py           # CopernicusFM Encoder (cls)
│   ├── models_dwv_seg.py       # CopernicusFM Encoder (seg)
│   ├── dynamic_hypernetwork.py # 动态 Patch Embedding
│   ├── aurora/                 # Fourier 展开模块
│   │   ├── fourier.py
│   │   └── area.py
│   └── flexivit/              # FlexiViT 支持
│       ├── patch_embed.py
│       └── utils.py
├── configs/                    # 配置文件
│   ├── copernicusfm_seg_default.py      # 默认配置
│   └── copernicusfm_seg_s2_eurosat.py  # Sentinel-2 EuroSAT 配置
├── tools/                     # 工具脚本
│   ├── train.py              # 训练脚本
│   └── test.py               # 测试脚本
├── tests/                    # 测试文件
└── README.md                 # 本文档
```

## 环境要求

- Python >= 3.8
- PyTorch >= 1.10
- mmcv-full >= 1.3.0
- mmseg >= 0.20.0
- torchgeo (for original datasets)

```bash
# 使用 conda 环境
conda activate mmenv

# 或者安装依赖
pip install torch torchvision
pip install mmcv-full -f https://download.openmmlab.com/mmcv/dist/cu113/torch1.10/index.html
pip install mmseg
```

## 快速开始

### 1. 准备数据

#### 选项 A：使用原始 Copernicus-Bench 数据

```bash
# 从 HuggingFace 下载数据集
# 例如 EuroSAT-S2
git lfs install
git clone https://huggingface.co/datasets/wangyi111/Copernicus-Bench
cd Copernicus-Bench
# 按照数据集说明进行下载和解压
```

#### 选项 B：使用自定义数据

组织为 mmseg 标准格式：

```
data/
├── your_dataset/
│   ├── images/
│   │   ├── train/
│   │   ├── val/
│   │   └── test/
│   └── annotations/
│       ├── train/
│       ├── val/
│       └── test/
```

### 2. 下载预训练权重

从 HuggingFace 下载 CopernicusFM 预训练权重：

```bash
# 创建 weights 目录
mkdir -p weights

# 下载权重（使用 huggingface-hub 或直接下载）
pip install huggingface-hub
python -c "from huggingface_hub import hf_hub_download; hf_hub_download(repo_id='wangyi111/Copernicus-FM', filename='CopernicusFM_ViT_base_varlang_e100.pth', local_dir='weights')"
```

或者直接下载：
```bash
wget https://huggingface.co/wangyi111/Copernicus-FM/resolve/main/CopernicusFM_ViT_base_varlang_e100.pth -P weights/
```

### 3. 修改配置

编辑配置文件 `configs/copernicusfm_seg_s2_eurosat.py`：

```python
# 修改数据集路径
data_root = 'data/your_dataset'

# 修改类别数
model = dict(
    decode_head=dict(num_classes=YOUR_NUM_CLASSES),
    auxiliary_head=dict(num_classes=YOUR_NUM_CLASSES),
)

# 修改训练参数
data = dict(
    samples_per_gpu=16,  # 根据 GPU 内存调整
    workers_per_gpu=4,
)
```

### 4. 训练

```bash
# 单 GPU 训练
python tools/train.py configs/copernicusfm_seg_s2_eurosat.py --work-dir work_dirs/copernicusfm_s2_eurosat

# 多 GPU 训练
tools/dist_train.sh configs/copernicusfm_seg_s2_eurosat.py 4  # 4 GPUs
```

### 5. 测试

```bash
# 单 GPU 测试
python tools/test.py configs/copernicusfm_seg_s2_eurosat.py \
    work_dirs/copernicusfm_s2_eurosat/latest.pth \
    --eval mIoU

# 多 GPU 测试
tools/dist_test.sh configs/copernicusfm_seg_s2_eurosat.py \
    work_dirs/copernicusfm_s2_eurosat/latest.pth \
    4 --eval mIoU  # 4 GPUs
```

## 模型架构

### CopernicusFM Encoder

- **基础架构**: Vision Transformer (ViT-Base/Large/Small)
- **嵌入维度**: 768 (Base) / 1024 (Large) / 384 (Small)
- **深度**: 12 层 (Base)
- **创新点**:
  - Dynamic Patch Embedding（根据波长/带宽动态生成权重）
  - 支持 spectral 和 variable 两种模式
  - Fourier 位置编码（坐标、时间、尺度）

### 分割解码器

- **Neck**: Feature2Pyramid（多尺度特征融合）
- **Decode Head**: UPerHead（统一感知头）
- **Auxiliary Head**: FCNHead（辅助损失）

## 性能对比

| 模型 | 数据集 | mIoU | 备注 |
|-----|--------|-----|------|
| CopernicusFM + UPerHead | EuroSAT-S2 | TBD | 待测试 |
| CopernicusFM + UPerHead | Cloud-S2 | TBD | 待测试 |

## 常见问题

### Q1: 如何修改输入通道数？

在配置文件中修改 `num_channels`，并确保数据预处理正确：

```python
img_norm_cfg = dict(
    mean=[...],  # 你的通道均值
    std=[...],   # 你的通道标准差
    to_rgb=False)  # 如果不是 RGB，设置为 False
```

### Q2: 如何使用 RGB 图像？

修改配置文件：

```python
# 对于 RGB 图像，使用标准 ImageNet 归一化
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53],
    std=[58.395, 57.12, 57.37],
    to_rgb=True)

# 修改模型配置以适应 3 通道输入
model = dict(
    backbone=dict(
        num_channels=3,
        band_wavelengths=[650, 550, 450],  # R, G, B 中心波长
        band_bandwidths=[100, 100, 100],
    ),
)
```

### Q3: 如何冻结 backbone 进行微调？

在配置文件中添加：

```python
optimizer = dict(
    paramwise_cfg=dict(
        custom_keys={
            'backbone': dict(lr_mult=0.0),  # 冻结 backbone
        }))
```

## 贡献

欢迎提交 issue 和 pull request！

## 许可证

本项目遵循原项目的许可证。

## 引用

如果使用 CopernicusFM，请引用原论文：

```bibtex
@article{wang2024copernicus,
  title={Copernicus-FM: A Foundation Model for Earth Observation},
  author={Wang, Yi and others},
  journal={arXiv preprint},
  year={2024}
}
```

## 联系方式

- GitHub Issues: [项目 issues 页面]
- Email: [你的邮箱]
```

现在创建一个简单的测试脚本来验证模型：</think>现在创建一个测试脚本来验证模型加载：<tool_call>
<function=Write>
<parameter=content>"""Test script to verify CopernicusFM model can be loaded."""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import torch
from copernicusfm.copernicusfm_seg import CopernicusFMSeg


def test_model_initialization():
    """Test that model can be initialized with config."""
    print("Testing CopernicusFM Segmentation Model Initialization...")

    # Model configuration
    model_cfg = dict(
        type='CopernicusFMSeg',
        backbone=dict(
            model_size='base',
            out_indices=[5, 8, 11],
            img_size=224,
            patch_size=16,
            embed_dim=768,
            depth=12,
            num_heads=12,
        ),
        neck=dict(
            type='Feature2Pyramid',
            embed_dim=768,
            rescales=[4, 2, 1, 0.5],
        ),
        decode_head=dict(
            type='UPerHead',
            in_channels=[768, 768, 768, 768],
            in_index=[0, 1, 2, 3],
            pool_scales=(1, 2, 3, 6),
            channels=512,
            dropout_ratio=0.1,
            num_classes=10,
            norm_cfg=dict(type='SyncBN', requires_grad=True),
            align_corners=False,
            loss_decode=dict(
                type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0)),
        auxiliary_head=dict(
            type='FCNHead',
            in_channels=768,
            in_index=2,
            channels=256,
            num_convs=1,
            concat_input=False,
            dropout_ratio=0.1,
            num_classes=10,
            norm_cfg=dict(type='SyncBN', requires_grad=True),
            align_corners=False,
            loss_decode=dict(
                type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4)),
        pretrained=None,  # Skip pretrained for testing
        train_cfg=dict(),
        test_cfg=dict(mode='whole'),
    )

    try:
        # Build model
        model = CopernicusFMSeg(**model_cfg)
        print("✓ Model initialized successfully!")

        # Count parameters
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"\nParameter Statistics:")
        print(f"  Total parameters: {total_params:,}")
        print(f"  Trainable parameters: {trainable_params:,}")
        print(f"  Model size: {total_params * 4 / 1024**2:.1f} MB (float32)")

        # Test forward pass
        print("\nTesting forward pass...")
        batch_size = 2
        img_size = 224
        num_channels = 3  # RGB input

        # Create dummy input
        dummy_img = torch.randn(batch_size, num_channels, img_size, img_size)

        # Create dummy meta information
        dummy_metas = [
            {'lon': 120.0, 'lat': 30.0, 'time': 100.0, 'area': 1.0}
            for _ in range(batch_size)
        ]

        # Forward pass (inference mode)
        model.eval()
        with torch.no_grad():
            # Test extract features
            feats = model.extract_feat(dummy_img, dummy_metas)
            print(f"✓ Feature extraction successful!")
            print(f"  Feature levels: {len(feats)}")
            for i, feat in enumerate(feats):
                print(f"  Level {i}: {feat.shape}")

            # Test forward test
            seg_logits = model.forward_test(dummy_img, dummy_metas)
            print(f"\n✓ Forward test successful!")
            print(f"  Output shape: {seg_logits[0].shape}")

        print("\n" + "=" * 60)
        print("✓ All tests passed!")
        print("=" * 60)

        return True

    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_backbone_only():
    """Test that backbone can be loaded separately."""
    print("\n" + "=" * 60)
    print("Testing Backbone Only...")
    print("=" * 60)

    try:
        from copernicusfm.models_dwv_seg import vit_base_patch16

        # Build backbone
        backbone = vit_base_patch16(out_indices=[5, 8, 11])
        print("✓ Backbone initialized!")

        # Count parameters
        total_params = sum(p.numel() for p in backbone.parameters())
        print(f"  Parameters: {total_params:,}")

        # Test forward
        dummy_input = torch.randn(1, 3, 224, 224)
        dummy_meta = torch.tensor([[120.0, 30.0, 100.0, 1.0]])

        backbone.eval()
        with torch.no_grad():
            features = backbone(dummy_input, dummy_meta)
            print(f"✓ Backbone forward successful!")
            print(f"  Output levels: {len(features)}")
            for i, feat in enumerate(features):
                print(f"  Level {i}: {feat.shape}")

        return True

    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("=" * 60)
    print("CopernicusFM Model Verification Tests")
    print("=" * 60)

    results = []

    # Test 1: Full model
    results.append(("Full Model", test_model_initialization()))

    # Test 2: Backbone only
    results.append(("Backbone", test_backbone_only()))

    # Summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    for name, success in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{name}: {status}")

    all_passed = all(success for _, success in results)
    print(f"\nOverall: {'✓ All tests passed!' if all_passed else '✗ Some tests failed!'}")

    return 0 if all_passed else 1


if __name__ == '__main__':
    sys.exit(main())
