"""PASTIS 测试脚本 - 使用 mmseg 官方 test.py"""

import sys
import os
import argparse

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)


def parse_args():
    parser = argparse.ArgumentParser(description='Test CopernicusFM on PASTIS')
    parser.add_argument('config', help='config file path')
    parser.add_argument('checkpoint', help='checkpoint file')
    parser.add_argument('--out', help='output result file')
    parser.add_argument('--eval', type=str, nargs='+', default=['mIoU'],
                        help='evaluation metrics')
    parser.add_argument('--show', action='store_true')
    parser.add_argument('--show-dir', help='directory where painted images will be saved')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'],
                        default='none')
    parser.add_argument('--local_rank', type=int, default=0)

    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)

    return args


def main():
    args = parse_args()

    # 加载配置
    from mmcv import Config
    cfg = Config.fromfile(args.config)

    # 打印配置信息
    print('=' * 80)
    print('Testing Configuration')
    print('=' * 80)
    print(f'Config: {args.config}')
    print(f'Checkpoint: {args.checkpoint}')
    print(f'Eval metrics: {args.eval}')
    print('=' * 80)

    # 使用 mmseg 官方的 single_gpu_test / multi_gpu_test
    from mmseg.apis import single_gpu_test, multi_gpu_test
    from mmseg.datasets import build_dataset, build_dataloader
    from mmseg.models import build_segmentor
    from mmcv.runner import load_checkpoint, get_dist_info, init_dist
    from mmcv.parallel import MMDataParallel, MMDistributedDataParallel

    # 构建数据集和数据加载器
    dataset = build_dataset(cfg.data.test)
    data_loader = build_dataloader(
        dataset,
        samples_per_gpu=1,
        workers_per_gpu=cfg.data.workers_per_gpu,
        dist=args.launcher != 'none',
        shuffle=False,
    )

    # 构建模型
    model = build_segmentor(
        cfg.model,
        train_cfg=None,
        test_cfg=cfg.get('test_cfg'),
    )

    # 加载权重
    checkpoint = load_checkpoint(model, args.checkpoint, map_location='cpu')

    # 添加类别信息
    model.CLASSES = dataset.CLASSES

    # 打印模型信息
    print(f'\nModel: {model.__class__.__name__}')
    print(f'Dataset: {dataset.__class__.__name__}')
    print(f'Test samples: {len(dataset)}')

    # 测试
    distributed = args.launcher != 'none'

    if not distributed:
        model = MMDataParallel(model, device_ids=[0])
        outputs = single_gpu_test(
            model,
            data_loader,
            args.show,
            args.show_dir,
        )
    else:
        init_dist(args.launcher, **cfg.dist_params)
        model = MMDistributedDataParallel(
            model.cuda(),
            device_ids=[torch.cuda.current_device()],
            broadcast_buffers=False,
        )
        outputs = multi_gpu_test(model, data_loader, None, False)

    # 评估
    rank, _ = get_dist_info()
    if rank == 0:
        if args.out:
            print(f'\nWriting results to {args.out}')
            import mmcv
            mmcv.dump(outputs, args.out)

        if args.eval:
            dataset.evaluate(outputs, args.eval)


if __name__ == '__main__':
    main()
