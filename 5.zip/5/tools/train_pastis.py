"""PASTIS 训练脚本 - 使用 mmseg 官方 train.py"""

import sys
import os
import argparse

# 添加项目根目录到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from mmseg.apis import set_random_seed
from mmcv import Config


def parse_args():
    parser = argparse.ArgumentParser(description='Train CopernicusFM on PASTIS')
    parser.add_argument('config', help='config file path')
    parser.add_argument('--work-dir', help='the dir to save logs and models')
    parser.add_argument('--load-from', help='the checkpoint file to load weights from')
    parser.add_argument('--resume-from', help='the checkpoint file to resume from')
    parser.add_argument('--no-validate', action='store_true')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'],
                        default='none')
    parser.add_argument('--local_rank', type=int, default=0)

    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)

    return args


def main():
    args = parse_args()

    # 加载配置
    cfg = Config.fromfile(args.config)

    # 设置工作目录
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    elif cfg.get('work_dir', None) is None:
        cfg.work_dir = os.path.join(
            './work_dirs',
            os.path.splitext(os.path.basename(args.config))[0]
        )

    # 设置随机种子
    if args.seed is not None:
        set_random_seed(args.seed, deterministic=True)

    # 打印配置信息
    print('=' * 80)
    print('Training Configuration')
    print('=' * 80)
    print(f'Config: {args.config}')
    print(f'Work dir: {cfg.work_dir}')
    print(f'Seed: {args.seed}')
    print('=' * 80)

    # 使用 mmseg 官方的 train_segmentor
    from mmseg.apis import train_segmentor
    from mmseg.datasets import build_dataset
    from mmseg.models import build_segmentor

    # 构建数据集
    datasets = [build_dataset(cfg.data.train)]

    # 构建模型
    model = build_segmentor(
        cfg.model,
        train_cfg=cfg.get('train_cfg'),
        test_cfg=cfg.get('test_cfg'),
    )

    # 添加类别信息
    model.CLASSES = datasets[0].CLASSES

    # 打印模型信息
    print(f'\nModel: {model.__class__.__name__}')
    print(f'Dataset: {datasets[0].__class__.__name__}')
    print(f'Training samples: {len(datasets[0])}')

    # 统计参数
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'Total parameters: {total_params:,}')
    print(f'Trainable parameters: {trainable_params:,}')

    # 开始训练
    distributed = args.launcher != 'none'

    train_segmentor(
        model,
        datasets,
        cfg,
        distributed=distributed,
        validate=not args.no_validate,
        timestamp=None,
        meta=dict(
            config=cfg.pretty_text,
            seed=args.seed,
        ),
    )


if __name__ == '__main__':
    main()
