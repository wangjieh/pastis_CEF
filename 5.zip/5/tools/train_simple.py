"""Training script for CopernicusFM Segmentation."""

import argparse
import os
import os.path as osp
import time
import warnings

import mmcv
import torch
from mmcv import Config
from mmcv.runner import init_dist
from mmseg import __version__
from mmseg.apis import set_random_seed, train_segmentor
from mmseg.datasets import build_dataset
from mmseg.models import build_segmentor


def parse_args():
    parser = argparse.ArgumentParser(description='Train a segmentor')
    parser.add_argument('config', help='train config file path')
    parser.add_argument('--work-dir', help='the dir to save logs and models')
    parser.add_argument(
        '--load-from', help='the checkpoint file to load weights from')
    parser.add_argument(
        '--resume-from', help='the checkpoint file to resume from')
    parser.add_argument(
        '--no-validate',
        action='store_true',
        help='whether not to evaluate during training')
    group_gpus = parser.add_mutually_exclusive_group()
    group_gpus.add_argument(
        '--gpus',
        type=int,
        help='number of gpus to use '
        '(only applicable to non-distributed training)')
    group_gpus.add_argument(
        '--gpu-ids',
        type=int,
        nargs='+',
        help='ids of gpus to use '
        '(only applicable to non-distributed training)')
    parser.add_argument('--seed', type=int, default=None, help='random seed')
    parser.add_argument(
        '--deterministic',
        action='store_true',
        help='whether to set deterministic options for CUDNN backend.')
    parser.add_argument(
        '--options', nargs='+', action=DictAction, help='custom options')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='job launcher')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)

    return args


def main():
    args = parse_args()

    cfg = Config.fromfile(args.config)

    if args.options is not None:
        cfg.merge_from_dict(args.options)

    # Set cudnn_benchmark
    if cfg.get('cudnn_benchmark', False):
        torch.backends.cudnn.benchmark = True

    # Set work directory
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    elif cfg.get('work_dir', None) is None:
        cfg.work_dir = osp.join('./work_dirs',
                                osp.splitext(osp.basename(args.config))[0])

    # Resume from checkpoint
    if args.resume_from is not None:
        cfg.resume_from = args.resume_from

    # Load from checkpoint
    if args.load_from is not None:
        cfg.load_from = args.load_from

    # Initialize distributed training
    if args.launcher == 'none':
        distributed = False
    else:
        distributed = True
        init_dist(args.launcher, **cfg.dist_params)

    # Set random seed
    if args.seed is not None:
        set_random_seed(args.seed, deterministic=args.deterministic)

    # Create work directory
    mmcv.mkdir_or_exist(osp.abspath(cfg.work_dir))

    # Dump config
    cfg.dump(osp.join(cfg.work_dir, osp.basename(args.config)))

    # Build dataset
    datasets = [build_dataset(cfg.data.train)]

    # Build model
    model = build_segmentor(
        cfg.model,
        train_cfg=cfg.get('train_cfg'),
        test_cfg=cfg.get('test_cfg'))

    # Add CLASSES and PALETTE attributes to model
    model.CLASSES = datasets[0].CLASSES
    if hasattr(datasets[0], 'PALETTE'):
        model.PALETTE = datasets[0].PALETTE

    # Print model info
    print(f'Model: {model.__class__.__name__}')
    print(f'Dataset: {datasets[0].__class__.__name__}')
    print(f'Training samples: {len(datasets[0])}')

    # Start training
    train_segmentor(
        model,
        datasets,
        cfg,
        distributed=distributed,
        validate=(not args.no_validate),
        timestamp=time.strftime('%Y%m%d_%H%M%S', time.localtime()),
        meta=dict(
            dist_url=None,
            dist=None))


if __name__ == '__main__':
    main()
