"""CopernicusFM Temporal Segmentation Model."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple, Union

from mmengine.model import BaseModule
from mmseg.registry import MODELS
from mmseg.models.decode_heads import UPerHead, FCNHead
from mmseg.models.necks import Feature2Pyramid

from .models_dwv_seg import vit_base_patch16, vit_large_patch16, vit_small_patch16


@MODELS.register_module()
class CopernicusFMTemporalSeg(BaseModule):
    """CopernicusFM Temporal Segmentation Model.

    处理时序遥感影像的语义分割模型。每个时间步独立通过 backbone，
    然后进行时序特征融合。

    Args:
        backbone (dict): Backbone 配置。
        neck (dict, optional): Neck 配置。
        decode_head (dict): Decode head 配置。
        auxiliary_head (dict, optional): Auxiliary head 配置。
        pretrained (str, optional): 预训练权重路径。
        temporal_fusion (str): 时序融合策略，'mean' 或 'max'。默认 'mean'。
        train_cfg (dict, optional): 训练配置。
        test_cfg (dict, optional): 测试配置。
    """

    def __init__(
        self,
        backbone: Dict,
        neck: Optional[Dict] = None,
        decode_head: Dict = None,
        auxiliary_head: Optional[Dict] = None,
        pretrained: Optional[str] = None,
        temporal_fusion: str = 'mean',
        train_cfg: Optional[Dict] = None,
        test_cfg: Optional[Dict] = None,
        init_cfg: Optional[Dict] = None,
    ):
        super().__init__(init_cfg=init_cfg)

        # 时序融合策略
        assert temporal_fusion in ['mean', 'max'], \
            f"temporal_fusion must be 'mean' or 'max', got {temporal_fusion}"
        self.temporal_fusion = temporal_fusion

        # 训练和测试配置
        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

        # 构建 backbone
        self.backbone = self._build_backbone(backbone)

        # 构建 neck
        if neck is not None:
            self.neck = MODELS.build(neck)

        # 构建 decode head
        self.decode_head = MODELS.build(decode_head)

        # 构建 auxiliary head
        if auxiliary_head is not None:
            self.auxiliary_head = MODELS.build(auxiliary_head)

        # 加载预训练权重
        if pretrained is not None:
            self._load_pretrained_weights(pretrained)

    def _build_backbone(self, backbone_cfg: Dict) -> nn.Module:
        """构建 CopernicusFM backbone。"""
        model_size = backbone_cfg.get('model_size', 'base')

        if model_size == 'base':
            backbone = vit_base_patch16()
        elif model_size == 'large':
            backbone = vit_large_patch16()
        elif model_size == 'small':
            backbone = vit_small_patch16()
        else:
            raise ValueError(f'Unknown model size: {model_size}')

        return backbone

    def _load_pretrained_weights(self, pretrained_path: str):
        """加载预训练权重。"""
        import os

        if not os.path.exists(pretrained_path):
            raise FileNotFoundError(f'Pretrained weights not found: {pretrained_path}')

        print(f'Loading pretrained weights from {pretrained_path}...')
        checkpoint = torch.load(pretrained_path, map_location='cpu')

        if isinstance(checkpoint, dict):
            if 'model' in checkpoint:
                state_dict = checkpoint['model']
            elif 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
            else:
                state_dict = checkpoint
        else:
            state_dict = checkpoint

        # 加载 backbone 权重
        msg = self.backbone.load_state_dict(state_dict, strict=False)
        print(f'Loaded pretrained weights: {len(state_dict)} layers')
        if msg.missing_keys:
            print(f'  Missing keys: {len(msg.missing_keys)}')
        if msg.unexpected_keys:
            print(f'  Unexpected keys: {len(msg.unexpected_keys)}')

    def extract_single_timestep(
        self,
        img: torch.Tensor,
        meta: torch.Tensor,
    ) -> Tuple[torch.Tensor]:
        """提取单个时间步的特征。

        Args:
            img: [B, C, H, W]
            meta: [B, 4]

        Returns:
            多尺度特征 tuple
        """
        # 准备光谱参数
        wave_list = self.backbone.wave_list if hasattr(self.backbone, 'wave_list') else \
            [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
        bandwidth = self.backbone.bandwidth if hasattr(self.backbone, 'bandwidth') else \
            [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]

        # 提取特征
        feats = self.backbone(
            img,
            meta,
            None,  # key
            wave_list,
            bandwidth,
            None,  # language_embed
            'spectral'
        )

        return feats

    def temporal_feature_fusion(
        self,
        feat_list: List[Tuple[torch.Tensor]],
    ) -> Tuple[torch.Tensor]:
        """时序特征融合。

        Args:
            feat_list: 时序特征列表，每个元素是多尺度特征 tuple

        Returns:
            融合后的多尺度特征 tuple
        """
        if len(feat_list) == 0:
            raise ValueError("Empty feature list")

        num_levels = len(feat_list[0])
        fused_feats = []

        for level_idx in range(num_levels):
            # 堆叠所有时间步的特征 [T, B, C, H, W]
            level_feats = torch.stack([feats[level_idx] for feats in feat_list], dim=0)

            # 融合
            if self.temporal_fusion == 'mean':
                fused = level_feats.mean(dim=0)  # [B, C, H, W]
            elif self.temporal_fusion == 'max':
                fused = level_feats.max(dim=0)[0]  # [B, C, H, W]
            else:
                raise ValueError(f"Unknown temporal_fusion: {self.temporal_fusion}")

            fused_feats.append(fused)

        return tuple(fused_feats)

    def extract_feat(self, img: torch.Tensor, meta: torch.Tensor) -> Tuple[torch.Tensor]:
        """提取时序特征。

        Args:
            img: [B, T, C, H, W] 时序影像
            meta: [B, T, 4] 时序元信息

        Returns:
            融合后的多尺度特征 tuple
        """
        B, T, C, H, W = img.shape

        # 逐时间步提取特征
        feat_list = []
        for t in range(T):
            img_t = img[:, t]  # [B, C, H, W]
            meta_t = meta[:, t]  # [B, 4]
            feats_t = self.extract_single_timestep(img_t, meta_t)
            feat_list.append(feats_t)

        # 时序特征融合
        fused_feats = self.temporal_feature_fusion(feat_list)

        # 应用 neck
        if hasattr(self, 'neck'):
            fused_feats = self.neck(fused_feats)

        return fused_feats

    def _prepare_meta_tensor(self, img_metas: List[Dict], device: torch.device = None) -> torch.Tensor:
        """从 img_metas 提取 meta tensor。

        Args:
            img_metas: List[Dict]，每个 dict 包含 'meta' 键
            device: 目标设备

        Returns:
            meta: [B, T, 4] 或 [B, 4]
        """
        if isinstance(img_metas, torch.Tensor):
            if device is not None:
                return img_metas.to(device)
            return img_metas

        meta_list = []
        for m in img_metas:
            if isinstance(m, dict) and 'meta' in m:
                meta = m['meta']
                if isinstance(meta, torch.Tensor):
                    meta_list.append(meta)
                else:
                    meta_list.append(torch.tensor(meta))
            elif isinstance(m, torch.Tensor):
                meta_list.append(m)
            else:
                # 默认元信息
                meta_list.append(torch.zeros(4))

        # stack 成 [B, T, 4] 或 [B, 4]
        result = torch.stack(meta_list, dim=0)

        # 移动到目标设备
        if device is not None:
            result = result.to(device)

        return result

    def forward_train(
        self,
        img: torch.Tensor,
        img_metas: List[Dict],
        gt_semantic_seg: torch.Tensor,
        **kwargs,
    ) -> Dict[str, torch.Tensor]:
        """前向训练。

        Args:
            img: [B, T, C, H, W] 时序影像
            img_metas: 元信息列表
            gt_semantic_seg: [B, 1, H, W] 标签

        Returns:
            损失字典
        """
        # 准备 meta tensor (确保在同一设备)
        meta = self._prepare_meta_tensor(img_metas, device=img.device)

        # 提取特征
        feats = self.extract_feat(img, meta)

        # Decode head
        losses = dict()
        loss_decode = self._decode_head_forward_train(feats, img_metas, gt_semantic_seg)
        losses.update(loss_decode)

        # Auxiliary head
        if hasattr(self, 'auxiliary_head'):
            loss_aux = self._auxiliary_head_forward_train(feats, img_metas, gt_semantic_seg)
            losses.update(loss_aux)

        return losses

    def _decode_head_forward_train(
        self,
        feats: Tuple[torch.Tensor],
        img_metas: List[Dict],
        gt_semantic_seg: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Decode head 前向训练。"""
        seg_logits = self.decode_head(feats)
        losses = self.decode_head.losses(seg_logits, gt_semantic_seg)
        return losses

    def _auxiliary_head_forward_train(
        self,
        feats: Tuple[torch.Tensor],
        img_metas: List[Dict],
        gt_semantic_seg: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Auxiliary head 前向训练。"""
        seg_logits = self.auxiliary_head(feats)
        losses = self.auxiliary_head.losses(seg_logits, gt_semantic_seg)
        return losses

    def forward_test(
        self,
        img: torch.Tensor,
        img_metas: List[Dict],
        **kwargs,
    ) -> List[torch.Tensor]:
        """前向测试。

        Args:
            img: [B, T, C, H, W] 时序影像
            img_metas: 元信息列表

        Returns:
            分割结果列表
        """
        # 准备 meta tensor (确保在同一设备)
        meta = self._prepare_meta_tensor(img_metas, device=img.device)

        # 提取特征
        feats = self.extract_feat(img, meta)

        # Decode head
        seg_logits = self.decode_head(feats)

        # 上采样到原始大小
        seg_logits = F.interpolate(
            seg_logits,
            size=img.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )

        return [seg_logits]

    def forward(
        self,
        img: torch.Tensor,
        img_metas: Optional[List[Dict]] = None,
        return_loss: bool = True,
        **kwargs,
    ):
        """前向传播。"""
        if return_loss:
            return self.forward_train(img, img_metas, **kwargs)
        else:
            return self.forward_test(img, img_metas, **kwargs)


@MODELS.register_module()
class CopernicusFMLinearProbe(BaseModule):
    """CopernicusFM with Linear Probe.

    只训练一个简单的线性分类头，backbone 完全冻结。

    Args:
        backbone (dict): Backbone 配置。
        pretrained (str, optional): 预训练权重路径。
        num_classes (int): 类别数。
        temporal_fusion (str): 时序融合策略，'mean' 或 'max'。默认 'mean'。
    """

    def __init__(
        self,
        backbone: Dict,
        pretrained: Optional[str] = None,
        num_classes: int = 19,
        temporal_fusion: str = 'mean',
        init_cfg: Optional[Dict] = None,
    ):
        super().__init__(init_cfg=init_cfg)

        # 时序融合策略
        assert temporal_fusion in ['mean', 'max'], \
            f"temporal_fusion must be 'mean' or 'max', got {temporal_fusion}"
        self.temporal_fusion = temporal_fusion

        # 构建 backbone
        self.backbone = self._build_backbone(backbone)

        # 冻结 backbone
        for param in self.backbone.parameters():
            param.requires_grad = False

        # 线性分类头
        embed_dim = backbone.get('embed_dim', 768)
        self.classifier = nn.Conv2d(embed_dim, num_classes, kernel_size=1)

        # 加载预训练权重
        if pretrained is not None:
            self._load_pretrained_weights(pretrained)

    def _build_backbone(self, backbone_cfg: Dict) -> nn.Module:
        """构建 CopernicusFM backbone。"""
        model_size = backbone_cfg.get('model_size', 'base')

        if model_size == 'base':
            backbone = vit_base_patch16()
        elif model_size == 'large':
            backbone = vit_large_patch16()
        elif model_size == 'small':
            backbone = vit_small_patch16()
        else:
            raise ValueError(f'Unknown model size: {model_size}')

        return backbone

    def _load_pretrained_weights(self, pretrained_path: str):
        """加载预训练权重。"""
        import os

        if not os.path.exists(pretrained_path):
            raise FileNotFoundError(f'Pretrained weights not found: {pretrained_path}')

        print(f'Loading pretrained weights from {pretrained_path}...')
        checkpoint = torch.load(pretrained_path, map_location='cpu')

        if isinstance(checkpoint, dict):
            if 'model' in checkpoint:
                state_dict = checkpoint['model']
            elif 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
            else:
                state_dict = checkpoint
        else:
            state_dict = checkpoint

        msg = self.backbone.load_state_dict(state_dict, strict=False)
        print(f'Loaded pretrained weights: {len(state_dict)} layers')

    def extract_single_timestep(
        self,
        img: torch.Tensor,
        meta: torch.Tensor,
    ) -> torch.Tensor:
        """提取单个时间步的特征（只返回最后一层）。"""
        wave_list = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
        bandwidth = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]

        feats = self.backbone(
            img,
            meta,
            None,
            wave_list,
            bandwidth,
            None,
            'spectral'
        )

        # 只返回最后一层特征
        return feats[-1]

    def forward(
        self,
        img: torch.Tensor,
        img_metas: Optional[List[Dict]] = None,
        return_loss: bool = True,
        **kwargs,
    ):
        """前向传播。

        Args:
            img: [B, T, C, H, W]
            img_metas: 元信息（对于 linear probe 不使用）
            return_loss: 是否返回损失

        Returns:
            损失字典或分割结果
        """
        B, T, C, H, W = img.shape

        # 准备元信息
        if img_metas is None:
            meta = torch.zeros(B, T, 4, device=img.device)
        else:
            meta_list = []
            for m in img_metas:
                if isinstance(m, dict) and 'meta' in m:
                    meta_list.append(m['meta'])
                elif isinstance(m, torch.Tensor):
                    meta_list.append(m)
                else:
                    meta_list.append(torch.zeros(4))
            meta = torch.stack(meta_list, dim=0).to(img.device)  # [B, T, 4]

        # 逐时间步提取特征
        feat_list = []
        for t in range(T):
            img_t = img[:, t]  # [B, C, H, W]
            meta_t = meta[:, t] if meta.dim() == 3 else meta  # [B, 4]
            feat_t = self.extract_single_timestep(img_t, meta_t)
            feat_list.append(feat_t)

        # 时序融合
        if self.temporal_fusion == 'mean':
            fused_feat = torch.stack(feat_list, dim=0).mean(dim=0)  # [B, C, H, W]
        elif self.temporal_fusion == 'max':
            fused_feat = torch.stack(feat_list, dim=0).max(dim=0)[0]  # [B, C, H, W]

        # 线性分类
        seg_logits = self.classifier(fused_feat)  # [B, num_classes, H, W]

        # 上采样到原始大小
        seg_logits = F.interpolate(
            seg_logits,
            size=(H, W),
            mode='bilinear',
            align_corners=False,
        )

        if return_loss:
            # 需要标签来计算损失
            gt_semantic_seg = kwargs.get('gt_semantic_seg')
            if gt_semantic_seg is None:
                raise ValueError("gt_semantic_seg is required for training")

            loss = F.cross_entropy(
                seg_logits,
                gt_semantic_seg.squeeze(1),
                ignore_index=-1,
            )
            return {'loss_seg': loss}
        else:
            return [seg_logits]
