"""Custom hooks for CopernicusFM training."""

from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze backbone for first N epochs, then unfreeze.

    Args:
        freeze_epochs (int): Number of epochs to freeze backbone.
    """

    def __init__(self, freeze_epochs=10):
        self.freeze_epochs = freeze_epochs

    def before_train_epoch(self, runner):
        """在每个 epoch 开始前检查是否需要解冻。"""
        epoch = runner.epoch + 1

        if epoch <= self.freeze_epochs:
            # 冻结 backbone
            self._freeze_backbone(runner.model)
            if epoch == 1:
                print(f'[FreezeBackboneHook] Backbone frozen for first {self.freeze_epochs} epochs')
        else:
            # 解冻 backbone
            self._unfreeze_backbone(runner.model)
            if epoch == self.freeze_epochs + 1:
                print(f'[FreezeBackboneHook] Backbone unfrozen at epoch {epoch}')

    def _freeze_backbone(self, model):
        """冻结 backbone 参数。"""
        # 处理分布式模型
        if hasattr(model, 'module'):
            model = model.module

        if hasattr(model, 'backbone'):
            for param in model.backbone.parameters():
                param.requires_grad = False

    def _unfreeze_backbone(self, model):
        """解冻 backbone 参数。"""
        # 处理分布式模型
        if hasattr(model, 'module'):
            model = model.module

        if hasattr(model, 'backbone'):
            for param in model.backbone.parameters():
                param.requires_grad = True
