arch = 'base'
auto_scale_lr = dict(base_batch_size=16, enable=True)
base_lr = 0.01
batch_size = 16
cfm_channels = 768
custom_imports = dict(
    allow_failed_imports=False, imports=[
        'cfm_mmseg',
    ])
data_root = '/mnt/ht2-nas2/wj/PASTIS_evel/dataset/dataset_for_OEF_64'
default_hooks = dict(
    checkpoint=dict(
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        rule='greater',
        save_best='mIoU',
        type='CheckpointHook'),
    logger=dict(interval=50, log_metric_by_epoch=True, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'),
    visualization=dict(type='SegVisualizationHook'))
default_scope = 'mmseg'
env_cfg = dict(
    cudnn_benchmark=True,
    dist_cfg=dict(backend='nccl'),
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0))
ignore_index = -1
launcher = 'pytorch'
load_from = None
log_level = 'INFO'
log_processor = dict(by_epoch=True)
max_epochs = 50
model = dict(
    backbone=dict(
        arch='base',
        freeze_backbone=True,
        img_size=64,
        input_mode='spectral',
        kernel_size=4,
        meta_mode='nan',
        out_indices=(
            3,
            5,
            7,
            11,
        ),
        patch_size=4,
        pretrained=
        '/mnt/ht2-nas2/EO_test/cyz/Copernicus-FM/weights/CopernicusFM_ViT_base_varlang_e100.pth',
        temporal_fusion='mean',
        time_chunk_size=None,
        type='CopernicusFMTemporalSegBackbone',
        var_option='spectrum'),
    data_preprocessor=dict(
        mean=None,
        pad_size_divisor=1,
        seg_pad_value=-1,
        std=None,
        type='PastisTemporalDataPreprocessor'),
    decode_head=dict(
        align_corners=False,
        channels=768,
        dropout_ratio=0.0,
        ignore_index=-1,
        in_channels=768,
        in_index=-1,
        input_transform=None,
        loss_decode=dict(
            loss_weight=1.0, type='CrossEntropyLoss', use_sigmoid=False),
        num_classes=19,
        type='LinearProbeHead'),
    test_cfg=dict(mode='whole'),
    train_cfg=dict(),
    type='EncoderDecoder')
num_classes = 19
num_workers = 4
optim_wrapper = dict(
    clip_grad=dict(max_norm=1.0, norm_type=2),
    loss_scale='dynamic',
    optimizer=dict(
        betas=(
            0.9,
            0.999,
        ), lr=0.01, type='AdamW', weight_decay=0.05),
    paramwise_cfg=dict(
        bias_decay_mult=0.0,
        custom_keys=dict(
            cls_token=dict(decay_mult=0.0),
            coord_token=dict(decay_mult=0.0),
            pos_embed=dict(decay_mult=0.0),
            scale_token=dict(decay_mult=0.0),
            time_token=dict(decay_mult=0.0)),
        norm_decay_mult=0.0),
    type='AmpOptimWrapper')
out_indices = (
    3,
    5,
    7,
    11,
)
param_scheduler = [
    dict(
        begin=0, by_epoch=False, end=500, start_factor=1e-06, type='LinearLR'),
    dict(
        begin=0, by_epoch=True, end=50, eta_min=0.0, power=1.0, type='PolyLR'),
]
pretrained = '/mnt/ht2-nas2/EO_test/cyz/Copernicus-FM/weights/CopernicusFM_ViT_base_varlang_e100.pth'
randomness = dict(deterministic=False, seed=0)
resume = False
test_cfg = dict(type='TestLoop')
test_dataloader = dict(
    batch_size=1,
    dataset=dict(
        data_root='/mnt/ht2-nas2/wj/PASTIS_evel/dataset/dataset_for_OEF_64',
        pipeline=[
            dict(
                channel_map='s2_13',
                scale_factor=10000.0,
                type='LoadPastisTemporalImageFromFile'),
            dict(type='LoadPastisTemporalAnnotations'),
            dict(type='PackPastisSegInputs'),
        ],
        split='pastis_r_test',
        type='PASTISTemporalPtDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
test_evaluator = dict(
    iou_metrics=[
        'mIoU',
    ], type='IoUMetric')
test_pipeline = [
    dict(
        channel_map='s2_13',
        scale_factor=10000.0,
        type='LoadPastisTemporalImageFromFile'),
    dict(type='LoadPastisTemporalAnnotations'),
    dict(type='PackPastisSegInputs'),
]
train_cfg = dict(max_epochs=50, type='EpochBasedTrainLoop', val_interval=1)
train_dataloader = dict(
    batch_size=16,
    dataset=dict(
        data_root='/mnt/ht2-nas2/wj/PASTIS_evel/dataset/dataset_for_OEF_64',
        pipeline=[
            dict(
                channel_map='s2_13',
                scale_factor=10000.0,
                type='LoadPastisTemporalImageFromFile'),
            dict(type='LoadPastisTemporalAnnotations'),
            dict(type='PackPastisSegInputs'),
        ],
        split='pastis_r_train',
        type='PASTISTemporalPtDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=True, type='DefaultSampler'))
train_pipeline = [
    dict(
        channel_map='s2_13',
        scale_factor=10000.0,
        type='LoadPastisTemporalImageFromFile'),
    dict(type='LoadPastisTemporalAnnotations'),
    dict(type='PackPastisSegInputs'),
]
val_cfg = dict(type='ValLoop')
val_dataloader = dict(
    batch_size=1,
    dataset=dict(
        data_root='/mnt/ht2-nas2/wj/PASTIS_evel/dataset/dataset_for_OEF_64',
        pipeline=[
            dict(
                channel_map='s2_13',
                scale_factor=10000.0,
                type='LoadPastisTemporalImageFromFile'),
            dict(type='LoadPastisTemporalAnnotations'),
            dict(type='PackPastisSegInputs'),
        ],
        split='pastis_r_valid',
        type='PASTISTemporalPtDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
val_evaluator = dict(
    iou_metrics=[
        'mIoU',
    ], type='IoUMetric')
visualizer = dict(
    alpha=1.0,
    name='visualizer',
    type='SegLocalVisualizer',
    vis_backends=[
        dict(type='LocalVisBackend'),
    ])
work_dir = './work_dirs/linear_probe_frozen_50e'
