# Copernicus-FM + OpenMMLab/MMSegmentation for PASTIS temporal semantic segmentation

这个压缩包提供一个**无需 `pip install -e .`** 的 OpenMMLab 项目式集成：把 Copernicus-FM 作为时序 Sentinel-2 backbone，逐时相编码 PASTIS 的 `12×13×128×128` 张量，再做时序融合并接 MMSeg 分割头。

## 1. 目录结构

```text
cfm_pastis_openmmlab/
├── cfm_mmseg/                 # 本地注册的 dataset / backbone / head / hook
├── configs/                   # 4 个 50 epoch 配置
└── tools/                     # 本地 train/test/check_dataset 脚本
```

运行时只需要把本目录加入 `PYTHONPATH`。`tools/train.py` 和 `tools/dist_train.sh` 已经自动处理，所以不需要安装本项目本身。

## 2. 环境要求

建议使用和 MMSegmentation 1.x 兼容的 OpenMMLab 环境，例如：

```bash
pip install -U openmim
mim install mmengine
mim install 'mmcv>=2.0.0'
pip install 'mmsegmentation>=1.2.0'
```

你的 Copernicus-FM 权重文件需要单独放在本地，例如：

```text
/path/to/CopernicusFM_ViT_base_varlang_e100.pth
/path/to/CopernicusFM_ViT_large_varlang_e100.pth
```

## 3. 数据格式

默认读取你描述的格式：

```text
pastis_dataset/
├── pastis_r_train/
│   ├── s2_images/
│   │   ├── 0.pt      # [12,13,128,128]
│   │   └── ...
│   └── targets.pt    # [N,128,128], label=0..18, ignore=-1
├── pastis_r_val/
└── pastis_r_test/
```

先检查数据：

```bash
python tools/check_dataset.py --split-root /path/to/pastis_dataset/pastis_r_train
```

## 4. 重要配置项

每个 config 顶部都有这两个路径，必须先改：

```python
data_root = '/path/to/pastis_dataset'
cfm_checkpoint = '/path/to/CopernicusFM_ViT_base_varlang_e100.pth'
```

也可以不改文件，直接用 `--cfg-options` 覆盖：

```bash
--cfg-options data_root=/path/to/pastis_dataset cfm_checkpoint=/path/to/CopernicusFM_ViT_base_varlang_e100.pth
```

### 通道顺序

默认 `channel_order='s2_13'`，即假设输入 13 通道顺序是：

```text
B01,B02,B03,B04,B05,B06,B07,B08,B8A,B09,B10,B11,B12
```

如果你的 13 通道是把 10 个 PASTIS 原始通道后面追加 3 个 pad：

```text
B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12,pad,pad,pad
```

请改成：

```python
model.data_preprocessor.channel_order = 'pastis_10_plus_pad_end'
```

或命令行覆盖：

```bash
--cfg-options model.data_preprocessor.channel_order=pastis_10_plus_pad_end
```

### 归一化

默认 `scale_factor=10000.0`，即把 Sentinel-2 反射率 DN 除以 10000。若你的 `.pt` 已经是 0~1 浮点值，请改为：

```bash
--cfg-options model.data_preprocessor.scale_factor=1.0
```

## 5. 四个配置文件

四个 config 都训练 50 epoch：

1. `configs/pastis_cfm_base_linear_probe_frozen_50e.py`
   - Linear probe 分割头
   - Copernicus-FM 全程冻结，只训练分割头

2. `configs/pastis_cfm_base_linear_probe_freeze10_ft40_50e.py`
   - Linear probe 分割头
   - 前 10 epoch 冻结 Copernicus-FM，后 40 epoch 全量微调

3. `configs/pastis_cfm_base_upernet_frozen_50e.py`
   - UPerHead 分割头
   - Copernicus-FM 全程冻结，只训练 UPerHead

4. `configs/pastis_cfm_base_upernet_freeze10_ft40_50e.py`
   - UPerHead 分割头
   - 前 10 epoch 冻结 Copernicus-FM，后 40 epoch 全量微调

## 6. 单卡训练

```bash
python tools/train.py configs/pastis_cfm_base_linear_probe_frozen_50e.py \
  --cfg-options \
  data_root=/path/to/pastis_dataset \
  cfm_checkpoint=/path/to/CopernicusFM_ViT_base_varlang_e100.pth
```

## 7. 多卡训练

例如 4 卡：

```bash
bash tools/dist_train.sh configs/pastis_cfm_base_upernet_freeze10_ft40_50e.py 4 \
  --cfg-options \
  data_root=/path/to/pastis_dataset \
  cfm_checkpoint=/path/to/CopernicusFM_ViT_base_varlang_e100.pth
```

配置中默认使用 `AmpOptimWrapper + AdamW + grad clip + CosineAnnealingLR`，更适合多卡和较大的 ViT backbone。微调配置里对 `backbone.cfm` 使用 `lr_mult=0.1`，也就是 backbone 学习率是 head 的 0.1 倍。

## 8. 切换 Base / Large

代码接口没有写死 base。切换 large 时，需要同步改这些项：

```bash
--cfg-options \
model.backbone.arch=large \
model.backbone.checkpoint_path=/path/to/CopernicusFM_ViT_large_varlang_e100.pth \
model.backbone.intermediate_indices='[5,11,17,23]' \
model.decode_head.in_channels='[1024,1024,1024,1024]'
```

对于 linear probe 配置，large 需要：

```bash
--cfg-options \
model.backbone.arch=large \
model.backbone.checkpoint_path=/path/to/CopernicusFM_ViT_large_varlang_e100.pth \
model.backbone.intermediate_indices='[23]' \
model.decode_head.in_channels=1024 \
model.decode_head.channels=1024
```

Large 显存压力明显更高，建议先把 `train_dataloader.batch_size` 降到 1，并可设置：

```bash
--cfg-options train_dataloader.batch_size=1 model.backbone.time_forward_batch_size=12
```

## 9. 测试

```bash
python tools/test.py configs/pastis_cfm_base_linear_probe_frozen_50e.py \
  work_dirs/pastis_cfm_base_linear_probe_frozen_50e/best_mIoU*.pth \
  --cfg-options data_root=/path/to/pastis_dataset
```

多卡测试：

```bash
bash tools/dist_test.sh configs/pastis_cfm_base_upernet_frozen_50e.py /path/to/checkpoint.pth 4 \
  --cfg-options data_root=/path/to/pastis_dataset
```

## 10. 设计说明

核心数据流：

```text
B×12×13×128×128
→ reshape 为 (B×12)×13×128×128
→ Copernicus-FM spectral branch
→ 每个时相得到 D×8×8 dense feature
→ temporal mean / attention fusion
→ MMSeg decode head
→ B×19×128×128
```

当前四个配置默认使用 `temporal_fusion='mean'`，这是最稳的第一版。如果后续要尝试可学习时序融合，可以改：

```bash
--cfg-options model.backbone.temporal_fusion=attention
```

