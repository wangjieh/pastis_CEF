# -*- coding: utf-8 -*-
import os
import re
from typing import Optional, Sequence

import torch
from mmengine.dataset import BaseDataset
from mmengine.structures import PixelData
from mmseg.registry import DATASETS
from mmseg.structures import SegDataSample


def _natural_key(path):
    name = os.path.basename(path)
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', name)]


@DATASETS.register_module()
class PASTISTemporalDataset(BaseDataset):
    """Dataset for preprocessed PASTIS tensors.

    Expected split directory:
        split_root/
          s2_images/0.pt   # [T, C, H, W], e.g. [12, 13, 128, 128]
          s2_images/1.pt
          targets.pt       # [N, H, W], labels 0..18, ignore=-1
    """

    METAINFO = dict(
        classes=tuple([f'class_{i}' for i in range(19)]),
        palette=[
            [0, 0, 0], [230, 25, 75], [60, 180, 75], [255, 225, 25],
            [0, 130, 200], [245, 130, 48], [145, 30, 180], [70, 240, 240],
            [240, 50, 230], [210, 245, 60], [250, 190, 190], [0, 128, 128],
            [230, 190, 255], [170, 110, 40], [255, 250, 200], [128, 0, 0],
            [170, 255, 195], [128, 128, 0], [0, 0, 128]
        ],
        ignore_index=-1,
    )

    def __init__(self,
                 split_root: str,
                 image_dir: str = 's2_images',
                 target_file: str = 'targets.pt',
                 expected_time_steps: Optional[int] = 12,
                 expected_channels: Optional[int] = 13,
                 ignore_index: int = -1,
                 metainfo: Optional[dict] = None,
                 lazy_init: bool = False,
                 **kwargs):
        self.split_root = split_root
        self.image_dir = image_dir
        self.target_file = target_file
        self.expected_time_steps = expected_time_steps
        self.expected_channels = expected_channels
        self.ignore_index = ignore_index
        super().__init__(
            ann_file='', metainfo=metainfo, data_root=None, data_prefix=dict(),
            pipeline=[], lazy_init=lazy_init, **kwargs)

    def load_data_list(self):
        image_root = os.path.join(self.split_root, self.image_dir)
        target_path = os.path.join(self.split_root, self.target_file)
        if not os.path.isdir(image_root):
            raise FileNotFoundError(f'Image directory not found: {image_root}')
        if not os.path.isfile(target_path):
            raise FileNotFoundError(f'Target tensor not found: {target_path}')
        self.targets = torch.load(target_path, map_location='cpu')
        if self.targets.ndim != 3:
            raise ValueError(f'targets.pt must be [N,H,W], got {tuple(self.targets.shape)}')
        image_paths = [
            os.path.join(image_root, p) for p in os.listdir(image_root)
            if p.endswith('.pt')
        ]
        image_paths = sorted(image_paths, key=_natural_key)
        if len(image_paths) != int(self.targets.shape[0]):
            raise ValueError(
                f'Number of image tensors ({len(image_paths)}) != targets ({self.targets.shape[0]}).')
        data_list = []
        for idx, img_path in enumerate(image_paths):
            data_list.append(dict(img_path=img_path, sample_idx=idx))
        return data_list

    def __getitem__(self, idx):
        if not self._fully_initialized:
            self.full_init()
        info = self.data_list[idx]
        img = torch.load(info['img_path'], map_location='cpu')
        if not torch.is_tensor(img):
            raise TypeError(f'Image file must contain a torch.Tensor: {info["img_path"]}')
        if img.ndim != 4:
            raise ValueError(f'Image tensor must be [T,C,H,W], got {tuple(img.shape)} at {info["img_path"]}')
        if self.expected_time_steps is not None and img.shape[0] != self.expected_time_steps:
            raise ValueError(f'Expected T={self.expected_time_steps}, got T={img.shape[0]} at {info["img_path"]}')
        if self.expected_channels is not None and img.shape[1] != self.expected_channels:
            raise ValueError(f'Expected C={self.expected_channels}, got C={img.shape[1]} at {info["img_path"]}')
        img = img.float().contiguous()
        seg = self.targets[info['sample_idx']].long().contiguous()
        data_sample = SegDataSample()
        data_sample.gt_sem_seg = PixelData(data=seg.unsqueeze(0))
        h, w = int(seg.shape[-2]), int(seg.shape[-1])
        data_sample.set_metainfo(dict(
            img_path=info['img_path'], sample_idx=info['sample_idx'],
            ori_shape=(h, w), img_shape=(h, w), pad_shape=(h, w),
            reduce_zero_label=False, ignore_index=self.ignore_index,
        ))
        return dict(inputs=img, data_samples=data_sample)
