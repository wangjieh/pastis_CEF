# -*- coding: utf-8 -*-
from mmengine.hooks import Hook
from mmengine.logging import print_log
from mmengine.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze Copernicus-FM for the first N epochs, then unfreeze it."""

    priority = 'VERY_HIGH'

    def __init__(self, unfreeze_epoch=10):
        self.unfreeze_epoch = int(unfreeze_epoch)
        self._unfrozen = False

    @staticmethod
    def _unwrap(model):
        return model.module if hasattr(model, 'module') else model

    def _set_trainable(self, runner, trainable):
        model = self._unwrap(runner.model)
        backbone = getattr(model, 'backbone', None)
        if backbone is None and hasattr(model, 'segmentor'):
            backbone = getattr(model.segmentor, 'backbone', None)
        if backbone is None:
            print_log('FreezeBackboneHook: model has no backbone.', logger='current')
            return
        if hasattr(backbone, 'set_cfm_trainable'):
            backbone.set_cfm_trainable(trainable)
        else:
            for p in backbone.parameters():
                p.requires_grad = trainable
        state = 'unfrozen' if trainable else 'frozen'
        print_log(f'FreezeBackboneHook: backbone is {state}.', logger='current')

    def before_train(self, runner):
        self._set_trainable(runner, False)

    def before_train_epoch(self, runner):
        if (not self._unfrozen) and runner.epoch >= self.unfreeze_epoch:
            self._set_trainable(runner, True)
            self._unfrozen = True
