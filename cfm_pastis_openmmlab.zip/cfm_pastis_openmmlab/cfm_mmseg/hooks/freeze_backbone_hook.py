from mmengine.hooks import Hook
from mmengine.model import is_model_wrapper
from mmseg.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneBeforeEpochHook(Hook):
    """Freeze backbone first, then unfreeze at a specified epoch.

    Epoch numbers are zero-based internally. ``unfreeze_epoch=10`` means the
    first 10 epochs are frozen and epoch 11 starts full fine-tuning.
    """

    priority = 'VERY_HIGH'

    def __init__(self, unfreeze_epoch: int = 10, verbose: bool = True):
        self.unfreeze_epoch = unfreeze_epoch
        self.verbose = verbose
        self._unfrozen = False

    def _get_model(self, runner):
        model = runner.model
        if is_model_wrapper(model):
            model = model.module
        return model

    def _set_backbone_trainable(self, runner, trainable: bool):
        model = self._get_model(runner)
        if not hasattr(model, 'backbone'):
            raise AttributeError('Runner model has no attribute backbone')
        backbone = model.backbone
        if hasattr(backbone, 'set_backbone_trainable'):
            backbone.set_backbone_trainable(trainable)
        else:
            for p in backbone.parameters():
                p.requires_grad = trainable
            if not trainable:
                backbone.eval()
        if self.verbose:
            state = 'trainable' if trainable else 'frozen'
            runner.logger.info(f'[FreezeBackboneBeforeEpochHook] backbone is now {state}.')

    def before_train(self, runner):
        self._set_backbone_trainable(runner, False)

    def before_train_epoch(self, runner):
        if (not self._unfrozen) and runner.epoch >= self.unfreeze_epoch:
            self._set_backbone_trainable(runner, True)
            self._unfrozen = True
