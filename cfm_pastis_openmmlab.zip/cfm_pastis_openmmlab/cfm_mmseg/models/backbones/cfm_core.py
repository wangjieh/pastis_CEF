# -*- coding: utf-8 -*-
"""Minimal Copernicus-FM ViT core used by the MMSeg wrapper.

This file keeps the public module/parameter names of the official Copernicus-FM
implementation so that official *.pth checkpoints can be loaded directly.
Only the spectral branch is used by PASTIS, but the variable branch is retained
for checkpoint compatibility.
"""

import math
from functools import partial
from typing import List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class FourierExpansion(nn.Module):
    def __init__(self, lower: float, upper: float, assert_range: bool = True) -> None:
        super().__init__()
        self.lower = lower
        self.upper = upper
        self.assert_range = assert_range

    def forward(self, x: torch.Tensor, d: int) -> torch.Tensor:
        if d % 2 != 0:
            raise ValueError('FourierExpansion dimension must be even.')
        if self.assert_range:
            ok = torch.logical_or(
                torch.logical_and(x.abs() >= self.lower, x.abs() <= self.upper),
                x == 0,
            )
            if not bool(torch.all(ok)):
                raise AssertionError(f'Input is outside [{self.lower}, {self.upper}].')
        x = x.double()
        wavelengths = torch.logspace(
            math.log10(self.lower), math.log10(self.upper), d // 2,
            base=10, device=x.device, dtype=x.dtype)
        prod = torch.einsum('...i,j->...ij', x, 2 * np.pi / wavelengths)
        return torch.cat((torch.sin(prod), torch.cos(prod)), dim=-1).float()


def _to_2tuple(x):
    if isinstance(x, (tuple, list)):
        return tuple(x)
    return (x, x)


def resize_abs_pos_embed(pos_embed: torch.Tensor,
                         new_size,
                         old_size=None,
                         num_prefix_tokens: int = 1,
                         interpolation: str = 'bicubic',
                         antialias: bool = True) -> torch.Tensor:
    new_size = _to_2tuple(new_size)
    if old_size is None:
        old_size = int(math.sqrt(pos_embed.shape[1] - num_prefix_tokens))
    old_size = _to_2tuple(old_size)
    if new_size == old_size:
        return pos_embed
    if num_prefix_tokens:
        prefix, pos = pos_embed[:, :num_prefix_tokens], pos_embed[:, num_prefix_tokens:]
    else:
        prefix, pos = None, pos_embed
    pos = pos.reshape(1, old_size[0], old_size[1], -1).permute(0, 3, 1, 2)
    pos = F.interpolate(pos, size=new_size, mode=interpolation, antialias=antialias)
    pos = pos.permute(0, 2, 3, 1).reshape(1, new_size[0] * new_size[1], -1)
    return torch.cat([prefix, pos], dim=1) if prefix is not None else pos


def pi_resize_patch_embed(patch_embed: torch.Tensor,
                          new_patch_size: Tuple[int, int],
                          interpolation: str = 'bicubic',
                          antialias: bool = True) -> torch.Tensor:
    # The default kernel_size=16 path does not resize. This interpolation fallback
    # keeps kernel_size=8/12 experiments usable without depending on functorch.
    if tuple(patch_embed.shape[-2:]) == tuple(new_patch_size):
        return patch_embed
    return F.interpolate(patch_embed, size=new_patch_size, mode=interpolation, antialias=antialias)


class TransformerWeightGenerator(nn.Module):
    def __init__(self, input_dim, output_dim, embed_dim, num_heads=4, num_layers=1):
        super().__init__()
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=input_dim, nhead=num_heads, activation='gelu',
            norm_first=False, batch_first=False, dropout=0.0)
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=num_layers, enable_nested_tensor=False)
        self.fc_weight = nn.Linear(input_dim, output_dim)
        self.fc_bias = nn.Linear(input_dim, embed_dim)
        self.wt_num = 128
        self.weight_tokens = nn.Parameter(torch.empty([self.wt_num, input_dim]))
        self.bias_token = nn.Parameter(torch.empty([1, input_dim]))
        torch.nn.init.normal_(self.weight_tokens, std=0.02)
        torch.nn.init.normal_(self.bias_token, std=0.02)

    def forward(self, x):
        pos_wave = x
        x = torch.cat([self.weight_tokens, pos_wave], dim=0)
        x = torch.cat([x, self.bias_token], dim=0)
        transformer_output = self.transformer_encoder(x)
        weights = self.fc_weight(transformer_output[self.wt_num:-1] + pos_wave)
        bias = self.fc_bias(transformer_output[-1])
        return weights, bias


class FCResLayer(nn.Module):
    def __init__(self, linear_size=128):
        super().__init__()
        self.l_size = linear_size
        self.nonlin1 = nn.ReLU(inplace=True)
        self.nonlin2 = nn.ReLU(inplace=True)
        self.w1 = nn.Linear(self.l_size, self.l_size)
        self.w2 = nn.Linear(self.l_size, self.l_size)

    def forward(self, x):
        y = self.w1(x)
        y = self.nonlin1(y)
        y = self.w2(y)
        y = self.nonlin2(y)
        return x + y


class Dynamic_MLP_OFA_spectral(nn.Module):
    def __init__(self, wv_planes=128, inter_dim=128, kernel_size=16, embed_dim=1024):
        super().__init__()
        self.kernel_size = kernel_size
        self.wv_planes = wv_planes
        self.embed_dim = embed_dim
        self._num_kernel = self.kernel_size * self.kernel_size * self.embed_dim
        self.inter_dim = inter_dim
        self.patch_size = (kernel_size, kernel_size)
        self.num_patches = -1
        self.spectrum_central_expansion = FourierExpansion(100, 1e9)
        self.spectrum_bandwidth_expansion = FourierExpansion(1, 1e9)
        self.weight_generator = TransformerWeightGenerator(wv_planes, self._num_kernel, embed_dim)
        self.scaler = 0.01
        self.fclayer = FCResLayer(wv_planes)

    def forward(self, img_feat, wvs, bandwidths, kernel_size=None):
        inplanes = wvs.size(0)
        emb_central = self.spectrum_central_expansion(wvs, self.wv_planes)
        emb_bandwidth = self.spectrum_bandwidth_expansion(bandwidths, self.wv_planes)
        waves = self.fclayer(emb_central + emb_bandwidth)
        weight, bias = self.weight_generator(waves)
        dynamic_weight = weight.view(inplanes, self.kernel_size, self.kernel_size, self.embed_dim)
        dynamic_weight = dynamic_weight.permute(3, 0, 1, 2)
        if kernel_size is not None and self.kernel_size != kernel_size:
            dynamic_weight = pi_resize_patch_embed(dynamic_weight, (kernel_size, kernel_size))
        else:
            kernel_size = self.kernel_size
        bias = bias.view([self.embed_dim]) * self.scaler if bias is not None else None
        weights = dynamic_weight * self.scaler
        x = F.conv2d(img_feat, weights, bias=bias, stride=kernel_size, padding=1, dilation=1)
        x = x.flatten(2).transpose(1, 2)
        return x, waves


class Dynamic_MLP_OFA_variable(nn.Module):
    def __init__(self, wv_planes=128, inter_dim=128, kernel_size=16, embed_dim=1024):
        super().__init__()
        self.kernel_size = kernel_size
        self.wv_planes = wv_planes
        self.embed_dim = embed_dim
        self._num_kernel = self.kernel_size * self.kernel_size * self.embed_dim
        self.inter_dim = inter_dim
        self.patch_size = (kernel_size, kernel_size)
        self.num_patches = -1
        self.language_proj = nn.Linear(2048, self.wv_planes)
        self.weight_generator = TransformerWeightGenerator(wv_planes, self._num_kernel, embed_dim)
        self.scaler = 0.01
        self.fclayer = FCResLayer(wv_planes)

    def forward(self, img_feat, language_embed, kernel_size=None):
        emb_language = language_embed.unsqueeze(0)
        waves = self.fclayer(self.language_proj(emb_language))
        weight, bias = self.weight_generator(waves)
        inplanes = waves.size(0)
        dynamic_weight = weight.view(inplanes, self.kernel_size, self.kernel_size, self.embed_dim)
        dynamic_weight = dynamic_weight.permute(3, 0, 1, 2)
        if kernel_size is not None and self.kernel_size != kernel_size:
            dynamic_weight = pi_resize_patch_embed(dynamic_weight, (kernel_size, kernel_size))
        else:
            kernel_size = self.kernel_size
        bias = bias.view([self.embed_dim]) * self.scaler if bias is not None else None
        weights = dynamic_weight * self.scaler
        x = F.conv2d(img_feat, weights, bias=bias, stride=kernel_size, padding=1, dilation=1)
        x = x.flatten(2).transpose(1, 2)
        return x, waves


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.0):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.drop1 = nn.Dropout(drop)
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop2 = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class Block(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4.0, qkv_bias=True, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = Attention(dim, num_heads=num_heads, qkv_bias=qkv_bias)
        self.norm2 = norm_layer(dim)
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio))

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class CopernicusFMViT(nn.Module):
    def __init__(self,
                 img_size=224,
                 patch_size=16,
                 embed_dim=768,
                 depth=12,
                 num_heads=12,
                 mlp_ratio=4.0,
                 norm_layer=partial(nn.LayerNorm, eps=1e-6),
                 loc_option='lonlat',
                 return_intermediate=True,
                 intermediate_indices: Optional[Sequence[int]] = None):
        super().__init__()
        self.num_patches = (img_size // patch_size) ** 2
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim), requires_grad=False)
        self.coord_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.scale_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.time_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.patch_embed_spectral = Dynamic_MLP_OFA_spectral(wv_planes=128, inter_dim=128, kernel_size=16, embed_dim=embed_dim)
        self.patch_embed_variable = Dynamic_MLP_OFA_variable(wv_planes=128, inter_dim=128, kernel_size=16, embed_dim=embed_dim)
        self.loc_option = loc_option
        if loc_option == 'cartesian':
            self.coord_expansion = FourierExpansion(1e-7, 2)
        else:
            self.coord_expansion = FourierExpansion(0.0001, 720)
        self.scale_expansion = FourierExpansion(0.001, 5.1e8)
        self.time_expansion = FourierExpansion(1, 365.25, assert_range=False)
        self.coord_fc = nn.Linear(embed_dim, embed_dim)
        self.scale_fc = nn.Linear(embed_dim, embed_dim)
        self.time_fc = nn.Linear(embed_dim, embed_dim)
        self.blocks = nn.ModuleList([
            Block(embed_dim, num_heads, mlp_ratio=mlp_ratio, qkv_bias=True, norm_layer=norm_layer)
            for _ in range(depth)
        ])
        self.return_intermediate = return_intermediate
        self.intermediate_indices = list(intermediate_indices) if intermediate_indices is not None else [depth - 1]
        self.embed_dim = embed_dim
        self.depth = depth

    def get_coord_pos_embed(self, lons, lats, embed_dim):
        if self.loc_option == 'cartesian':
            spherical_x = torch.cos(lons * math.pi / 180) * torch.cos(lats * math.pi / 180) + 1 + 1e-7
            spherical_y = torch.sin(lons * math.pi / 180) * torch.cos(lats * math.pi / 180) + 1 + 1e-7
            spherical_z = torch.sin(lats * math.pi / 180) + 1 + 1e-7
            coord_embed = torch.cat([
                self.coord_expansion(spherical_x, embed_dim // 3),
                self.coord_expansion(spherical_y, embed_dim // 3),
                self.coord_expansion(spherical_z, embed_dim // 3),
            ], dim=-1)
        else:
            coord_embed = torch.cat([
                self.coord_expansion(lons + 180, embed_dim // 2),
                self.coord_expansion(lats + 90, embed_dim // 2),
            ], dim=-1)
        if coord_embed.shape[-1] < embed_dim:
            pad = torch.zeros(coord_embed.shape[0], embed_dim - coord_embed.shape[-1], device=coord_embed.device)
            coord_embed = torch.cat((coord_embed, pad), dim=-1)
        return coord_embed.unsqueeze(1)

    def forward_features(self, x, meta_info, wave_list, bandwidth, language_embed=None, input_mode='spectral', kernel_size=None):
        if input_mode == 'spectral':
            wavelist = torch.as_tensor(wave_list, device=x.device, dtype=torch.float32)
            bandwidths = torch.as_tensor(bandwidth, device=x.device, dtype=torch.float32)
            x, _ = self.patch_embed_spectral(x, wavelist, bandwidths, kernel_size)
        elif input_mode == 'variable':
            x, _ = self.patch_embed_variable(x, language_embed, kernel_size)
        else:
            raise ValueError(f'Unsupported input_mode: {input_mode}')

        num_patches = x.size(1)
        hw = int(math.sqrt(num_patches))
        if hw * hw != num_patches:
            raise RuntimeError(f'Patch token number {num_patches} is not a square.')
        origin_hw = int(math.sqrt(self.num_patches))
        pos_embed = resize_abs_pos_embed(self.pos_embed, hw, (origin_hw, origin_hw), num_prefix_tokens=1)

        lons, lats, times, areas = meta_info[:, 0], meta_info[:, 1], meta_info[:, 2], meta_info[:, 3]
        embed_dim = pos_embed.shape[-1]
        if torch.isnan(lons).any() or torch.isnan(lats).any():
            coord_embed = self.coord_token
        else:
            coord_embed = self.get_coord_pos_embed(lons, lats, embed_dim)
        coord_embed = self.coord_fc(coord_embed)
        if torch.isnan(areas).any():
            area_embed = self.scale_token
        else:
            area_embed = self.scale_expansion(areas, embed_dim).unsqueeze(1)
        area_embed = self.scale_fc(area_embed)
        if torch.isnan(times).any():
            time_embed = self.time_token
        else:
            time_embed = self.time_expansion(times, embed_dim).unsqueeze(1)
        time_embed = self.time_fc(time_embed)
        pos_embed = pos_embed + coord_embed + area_embed + time_embed

        x = x + pos_embed[:, 1:, :]
        cls_token = self.cls_token + pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        intermediate_features = []
        for i, block in enumerate(self.blocks):
            x = block(x)
            if self.return_intermediate and i in self.intermediate_indices:
                out = x[:, 1:]
                B, _, C = out.shape
                out = out.reshape(B, hw, hw, C).permute(0, 3, 1, 2).contiguous()
                intermediate_features.append(out)
        if self.return_intermediate:
            pooled = x[:, 1:, :].mean(dim=1)
            return pooled, intermediate_features
        return x[:, 1:, :].mean(dim=1)

    def forward(self, x, meta_info, wave_list, bandwidth, language_embed=None, input_mode='spectral', kernel_size=None):
        return self.forward_features(x, meta_info, wave_list, bandwidth, language_embed, input_mode, kernel_size)


def build_copernicus_fm_vit(arch='base', **kwargs):
    arch = arch.lower()
    specs = {
        'small': dict(embed_dim=384, depth=12, num_heads=6),
        'base': dict(embed_dim=768, depth=12, num_heads=12),
        'large': dict(embed_dim=1024, depth=24, num_heads=16),
    }
    if arch not in specs:
        raise ValueError(f'Unsupported arch={arch}. Supported: {list(specs)}')
    return CopernicusFMViT(patch_size=16, mlp_ratio=4.0, **specs[arch], **kwargs)
