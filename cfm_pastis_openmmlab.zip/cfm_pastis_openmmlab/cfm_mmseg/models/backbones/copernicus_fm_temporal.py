# -*- coding: utf-8 -*-
import os
from typing import Optional, Sequence

import torch
import torch.nn as nn
from mmengine.logging import print_log
from mmengine.model import BaseModule
from mmseg.registry import MODELS

from .cfm_core import build_copernicus_fm_vit


S2_13_WAVELENGTHS_NM = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
S2_13_BANDWIDTHS_NM = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]


class TemporalAttentionPool(nn.Module):
    def __init__(self, channels: int, hidden_ratio: float = 0.25):
        super().__init__()
        hidden = max(1, int(channels * hidden_ratio))
        self.score = nn.Sequential(
            nn.Conv2d(channels, hidden, kernel_size=1),
            nn.GELU(),
            nn.Conv2d(hidden, 1, kernel_size=1),
        )

    def forward(self, x):
        # x: [B, T, C, H, W]
        B, T, C, H, W = x.shape
        scores = self.score(x.reshape(B * T, C, H, W)).reshape(B, T, 1, H, W)
        weights = torch.softmax(scores, dim=1)
        return (x * weights).sum(dim=1)


@MODELS.register_module()
class CopernicusFMTemporalBackbone(BaseModule):
    """Temporal Copernicus-FM backbone for PASTIS-style S2 time series.

    Input shape: [B, T, C, H, W]. Output: tuple of fused dense features, each
    with shape [B, D, h, w], suitable for MMSeg decode heads.
    """

    def __init__(self,
                 arch: str = 'base',
                 checkpoint_path: Optional[str] = None,
                 img_size: int = 224,
                 kernel_size: int = 16,
                 intermediate_indices: Optional[Sequence[int]] = None,
                 temporal_fusion: str = 'mean',
                 wave_list: Optional[Sequence[float]] = None,
                 bandwidth: Optional[Sequence[float]] = None,
                 input_mode: str = 'spectral',
                 freeze_cfm: bool = False,
                 freeze_unused_variable_branch: bool = True,
                 time_forward_batch_size: int = 0,
                 use_default_area: bool = False,
                 ground_resolution_m: float = 10.0,
                 default_time_stride_days: Optional[float] = None,
                 init_cfg=None):
        super().__init__(init_cfg=init_cfg)
        self.arch = arch.lower()
        self.checkpoint_path = checkpoint_path
        self.kernel_size = kernel_size
        self.intermediate_indices = list(intermediate_indices) if intermediate_indices is not None else None
        self.temporal_fusion = temporal_fusion
        self.wave_list = list(wave_list) if wave_list is not None else S2_13_WAVELENGTHS_NM
        self.bandwidth = list(bandwidth) if bandwidth is not None else S2_13_BANDWIDTHS_NM
        self.input_mode = input_mode
        self.freeze_unused_variable_branch = freeze_unused_variable_branch
        self.time_forward_batch_size = int(time_forward_batch_size or 0)
        self.use_default_area = use_default_area
        self.ground_resolution_m = ground_resolution_m
        self.default_time_stride_days = default_time_stride_days

        if self.intermediate_indices is None:
            self.intermediate_indices = [11] if self.arch in ('small', 'base') else [23]

        self.cfm = build_copernicus_fm_vit(
            arch=self.arch,
            img_size=img_size,
            return_intermediate=True,
            intermediate_indices=self.intermediate_indices,
        )
        self.embed_dim = self.cfm.embed_dim
        self.out_channels = [self.embed_dim for _ in self.intermediate_indices]

        if temporal_fusion == 'attention':
            self.temporal_pool = nn.ModuleList([TemporalAttentionPool(self.embed_dim) for _ in self.intermediate_indices])
        elif temporal_fusion in ('mean', 'max'):
            self.temporal_pool = None
        else:
            raise ValueError("temporal_fusion must be one of: 'mean', 'max', 'attention'.")

        self._cfm_frozen = False
        if freeze_cfm:
            self.set_cfm_trainable(False)
        if self.freeze_unused_variable_branch:
            self._freeze_variable_branch()

    def _freeze_variable_branch(self):
        if hasattr(self.cfm, 'patch_embed_variable'):
            for p in self.cfm.patch_embed_variable.parameters():
                p.requires_grad = False
            self.cfm.patch_embed_variable.eval()

    def set_cfm_trainable(self, trainable: bool = True):
        self._cfm_frozen = not trainable
        for p in self.cfm.parameters():
            p.requires_grad = trainable
        if self.freeze_unused_variable_branch:
            self._freeze_variable_branch()
        self.cfm.train(trainable)

    def train(self, mode: bool = True):
        super().train(mode)
        if self._cfm_frozen:
            self.cfm.eval()
        if self.freeze_unused_variable_branch:
            self._freeze_variable_branch()
        return self

    @staticmethod
    def _clean_state_dict(ckpt):
        if isinstance(ckpt, dict):
            for key in ['state_dict', 'model', 'model_state_dict', 'module', 'net', 'network']:
                if key in ckpt and isinstance(ckpt[key], dict):
                    ckpt = ckpt[key]
                    break
        new_state = {}
        for k, v in ckpt.items():
            nk = k
            for prefix in ['module.', 'backbone.', 'cfm.', 'model.']:
                if nk.startswith(prefix):
                    nk = nk[len(prefix):]
            new_state[nk] = v
        return new_state

    def init_weights(self):
        super().init_weights()
        if not self.checkpoint_path:
            print_log('No Copernicus-FM checkpoint_path is set; using random initialization.', logger='current')
            return
        if not os.path.isfile(self.checkpoint_path):
            raise FileNotFoundError(f'Copernicus-FM checkpoint not found: {self.checkpoint_path}')
        ckpt = torch.load(self.checkpoint_path, map_location='cpu')
        state_dict = self._clean_state_dict(ckpt)
        missing, unexpected = self.cfm.load_state_dict(state_dict, strict=False)
        print_log(
            f'Loaded Copernicus-FM checkpoint: {self.checkpoint_path}; '
            f'missing={len(missing)}, unexpected={len(unexpected)}', logger='current')
        if missing:
            print_log(f'Missing keys preview: {missing[:20]}', logger='current')
        if unexpected:
            print_log(f'Unexpected keys preview: {unexpected[:20]}', logger='current')
        if self._cfm_frozen:
            self.set_cfm_trainable(False)
        elif self.freeze_unused_variable_branch:
            self._freeze_variable_branch()

    def _make_meta(self, batch_size, time_steps, device, dtype):
        meta = torch.full((batch_size, time_steps, 4), float('nan'), device=device, dtype=dtype)
        if self.default_time_stride_days is not None:
            t = torch.arange(time_steps, device=device, dtype=dtype) * float(self.default_time_stride_days)
            meta[:, :, 2] = t.unsqueeze(0).expand(batch_size, -1)
        if self.use_default_area:
            area = (float(self.kernel_size) * float(self.ground_resolution_m) / 1000.0) ** 2
            meta[:, :, 3] = area
        return meta.reshape(batch_size * time_steps, 4)

    def _forward_cfm_flat(self, x_flat, meta_flat):
        if len(self.wave_list) != x_flat.shape[1]:
            raise ValueError(
                f'wave_list length ({len(self.wave_list)}) must equal input channels ({x_flat.shape[1]}). '
                'Check whether your 13-channel PASTIS tensors are in S2-13 order.'
            )
        chunk = self.time_forward_batch_size
        if chunk <= 0 or chunk >= x_flat.shape[0]:
            _, feats = self.cfm(
                x_flat, meta_flat, self.wave_list, self.bandwidth,
                language_embed=None, input_mode=self.input_mode, kernel_size=self.kernel_size)
            return feats
        outs = [[] for _ in self.intermediate_indices]
        for start in range(0, x_flat.shape[0], chunk):
            end = min(start + chunk, x_flat.shape[0])
            _, feats = self.cfm(
                x_flat[start:end], meta_flat[start:end], self.wave_list, self.bandwidth,
                language_embed=None, input_mode=self.input_mode, kernel_size=self.kernel_size)
            for i, f in enumerate(feats):
                outs[i].append(f)
        return [torch.cat(v, dim=0) for v in outs]

    def _fuse(self, feat, batch_size, time_steps, stage_idx):
        BT, C, H, W = feat.shape
        feat = feat.reshape(batch_size, time_steps, C, H, W)
        if self.temporal_fusion == 'mean':
            return feat.mean(dim=1)
        if self.temporal_fusion == 'max':
            return feat.max(dim=1).values
        return self.temporal_pool[stage_idx](feat)

    def forward(self, x):
        if x.dim() == 4:
            x = x.unsqueeze(1)
        if x.dim() != 5:
            raise ValueError(f'Expected input shape [B,T,C,H,W], got {tuple(x.shape)}')
        B, T, C, H, W = x.shape
        x_flat = x.reshape(B * T, C, H, W)
        meta_flat = self._make_meta(B, T, x.device, x.dtype)
        flat_feats = self._forward_cfm_flat(x_flat, meta_flat)
        fused = [self._fuse(f, B, T, i) for i, f in enumerate(flat_feats)]
        return tuple(fused)
