import math
from typing import List, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
from mmengine.dist import master_only
from mmengine.model import BaseModule
from mmseg.registry import MODELS

from cfm_mmseg.copernicus_fm.model_vit import CopernicusFMViT


S2_13_WAVELENGTHS_NM = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
S2_13_BANDWIDTHS_NM = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]
S2_10_WAVELENGTHS_NM = [490, 560, 665, 705, 740, 783, 842, 860, 1610, 2190]
S2_10_BANDWIDTHS_NM = [65, 35, 30, 15, 15, 20, 115, 20, 90, 180]

ARCH_SETTINGS = {
    'small': dict(embed_dim=384, depth=12, num_heads=6),
    'base': dict(embed_dim=768, depth=12, num_heads=12),
    'large': dict(embed_dim=1024, depth=24, num_heads=16),
    'huge': dict(embed_dim=1280, depth=32, num_heads=16),
}


def _load_state_dict(path: str):
    try:
        ckpt = torch.load(path, map_location='cpu', weights_only=True)
    except TypeError:
        ckpt = torch.load(path, map_location='cpu')
    if isinstance(ckpt, dict):
        for key in ('state_dict', 'model', 'model_state_dict', 'module', 'net', 'network'):
            if key in ckpt and isinstance(ckpt[key], dict):
                ckpt = ckpt[key]
                break
    if not isinstance(ckpt, dict):
        raise TypeError(f'Unsupported checkpoint type from {path}: {type(ckpt)}')
    state_dict = {}
    for k, v in ckpt.items():
        if k.startswith('module.'):
            k = k[7:]
        if k.startswith('backbone.'):
            k = k[9:]
        if k.startswith('cfm.'):
            k = k[4:]
        state_dict[k] = v
    return state_dict


class TemporalAttentionFusion(nn.Module):
    def __init__(self, embed_dim: int, num_levels: int):
        super().__init__()
        hidden = max(embed_dim // 4, 64)
        self.score_mlps = nn.ModuleList([
            nn.Sequential(nn.Linear(embed_dim, hidden), nn.GELU(), nn.Linear(hidden, 1))
            for _ in range(num_levels)
        ])

    def forward_one(self, x: torch.Tensor, level: int) -> torch.Tensor:
        # x: B x T x C x H x W
        b, t, c, h, w = x.shape
        xt = x.permute(0, 3, 4, 1, 2).reshape(b * h * w, t, c)
        score = self.score_mlps[level](xt)
        weight = torch.softmax(score, dim=1)
        fused = (xt * weight).sum(dim=1)
        fused = fused.reshape(b, h, w, c).permute(0, 3, 1, 2).contiguous()
        return fused


@MODELS.register_module()
class CopernicusFMTemporalBackbone(BaseModule):
    """Temporal wrapper for Copernicus-FM.

    Input shape: ``B x T x C x H x W``.
    Output: tuple of fused dense feature maps. Each feature map has shape
    ``B x D x h x w`` and can be consumed by MMSeg decode heads.
    """

    def __init__(
        self,
        arch: Union[str, dict] = 'base',
        pretrained: Optional[str] = None,
        out_indices: Sequence[int] = (11,),
        img_size: int = 224,
        pretrain_patch_size: int = 16,
        kernel_size: int = 16,
        wave_list: Optional[Sequence[float]] = None,
        bandwidth: Optional[Sequence[float]] = None,
        input_mode: str = 'spectral',
        temporal_fusion: str = 'mean',
        time_chunk_size: Optional[int] = None,
        freeze_backbone: bool = False,
        meta_mode: str = 'nan',
        default_lon: float = float('nan'),
        default_lat: float = float('nan'),
        default_delta_time: float = float('nan'),
        default_patch_token_area: Optional[float] = None,
        pixel_size_m: float = 10.0,
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        if isinstance(arch, str):
            if arch not in ARCH_SETTINGS:
                raise KeyError(f'Unsupported arch={arch!r}. Available: {list(ARCH_SETTINGS)}')
            self.arch = arch
            arch_cfg = ARCH_SETTINGS[arch].copy()
        else:
            self.arch = 'custom'
            arch_cfg = arch.copy()
        self.embed_dim = arch_cfg['embed_dim']
        self.depth = arch_cfg['depth']
        self.num_heads = arch_cfg['num_heads']
        self.out_indices = tuple(out_indices)
        self.pretrained = pretrained
        self.kernel_size = kernel_size
        self.input_mode = input_mode
        self.temporal_fusion = temporal_fusion.lower()
        self.time_chunk_size = time_chunk_size
        self.meta_mode = meta_mode.lower()
        self.default_lon = default_lon
        self.default_lat = default_lat
        self.default_delta_time = default_delta_time
        self.default_patch_token_area = default_patch_token_area
        self.pixel_size_m = pixel_size_m
        self._frozen = False

        if wave_list is None:
            wave_list = S2_13_WAVELENGTHS_NM
        if bandwidth is None:
            bandwidth = S2_13_BANDWIDTHS_NM
        self.wave_list = [float(x) for x in wave_list]
        self.bandwidth = [float(x) for x in bandwidth]
        if len(self.wave_list) != len(self.bandwidth):
            raise ValueError('wave_list and bandwidth must have the same length')

        self.cfm = CopernicusFMViT(
            img_size=img_size,
            patch_size=pretrain_patch_size,
            embed_dim=self.embed_dim,
            depth=self.depth,
            num_heads=self.num_heads,
            mlp_ratio=4,
            num_classes=0,
            global_pool=True,
            return_intermediate=True,
            intermediate_indices=self.out_indices,
        )

        if self.temporal_fusion == 'attention':
            self.attention_fusion = TemporalAttentionFusion(self.embed_dim, len(self.out_indices))
        elif self.temporal_fusion in ('mean', 'avg', 'average'):
            self.attention_fusion = None
        else:
            raise ValueError(f'Unsupported temporal_fusion={temporal_fusion!r}. Use mean or attention.')

        if freeze_backbone:
            self.set_backbone_trainable(False)

    @property
    def out_channels(self):
        return [self.embed_dim for _ in self.out_indices]

    def init_weights(self):
        super().init_weights()
        if self.pretrained:
            state_dict = _load_state_dict(self.pretrained)
            msg = self.cfm.load_state_dict(state_dict, strict=False)
            self._print_load_msg(msg)
        if self._frozen:
            self.set_backbone_trainable(False)

    @master_only
    def _print_load_msg(self, msg):
        missing = list(msg.missing_keys)
        unexpected = list(msg.unexpected_keys)
        print('[CopernicusFMTemporalBackbone] Loaded checkpoint:', self.pretrained)
        print(f'[CopernicusFMTemporalBackbone] missing_keys={len(missing)}, unexpected_keys={len(unexpected)}')
        if missing:
            print('[CopernicusFMTemporalBackbone] First missing keys:', missing[:20])
        if unexpected:
            print('[CopernicusFMTemporalBackbone] First unexpected keys:', unexpected[:20])

    def set_backbone_trainable(self, trainable: bool = True):
        for p in self.parameters():
            p.requires_grad = trainable
        self._frozen = not trainable
        if not trainable:
            self.eval()

    def set_cfm_trainable(self, trainable: bool = True):
        for p in self.cfm.parameters():
            p.requires_grad = trainable
        if not trainable:
            self.cfm.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        if self._frozen:
            super().train(False)
        return self

    def _build_meta(self, n: int, device, dtype):
        if self.meta_mode == 'nan':
            return torch.full((n, 4), float('nan'), device=device, dtype=dtype)
        if self.meta_mode != 'constant':
            raise ValueError(f'Unsupported meta_mode={self.meta_mode!r}. Use nan or constant.')
        area = self.default_patch_token_area
        if area is None:
            area = (self.kernel_size * self.pixel_size_m / 1000.0) ** 2
        meta = torch.tensor(
            [self.default_lon, self.default_lat, self.default_delta_time, area],
            device=device, dtype=dtype,
        ).view(1, 4).repeat(n, 1)
        return meta

    def _forward_cfm_chunks(self, x: torch.Tensor) -> List[torch.Tensor]:
        n = x.shape[0]
        chunk_size = self.time_chunk_size or n
        features_by_level = [[] for _ in self.out_indices]
        for start in range(0, n, chunk_size):
            end = min(start + chunk_size, n)
            x_chunk = x[start:end]
            meta = self._build_meta(end - start, x_chunk.device, x_chunk.dtype)
            _, inter_feats = self.cfm(
                x_chunk,
                meta,
                self.wave_list,
                self.bandwidth,
                language_embed=None,
                input_mode=self.input_mode,
                kernel_size=self.kernel_size,
            )
            if len(inter_feats) != len(self.out_indices):
                raise RuntimeError(
                    f'Expected {len(self.out_indices)} intermediate features, got {len(inter_feats)}. '
                    f'Check out_indices={self.out_indices}.'
                )
            for i, feat in enumerate(inter_feats):
                features_by_level[i].append(feat)
        return [torch.cat(chunks, dim=0) for chunks in features_by_level]

    def _fuse_one_level(self, feat: torch.Tensor, b: int, t: int, level: int) -> torch.Tensor:
        # feat: (B*T) x C x h x w
        _, c, h, w = feat.shape
        feat = feat.reshape(b, t, c, h, w)
        if self.temporal_fusion in ('mean', 'avg', 'average'):
            return feat.mean(dim=1)
        if self.temporal_fusion == 'attention':
            return self.attention_fusion.forward_one(feat, level)
        raise AssertionError('unreachable')

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        if x.dim() == 4:
            x = x.unsqueeze(1)
        if x.dim() != 5:
            raise ValueError(f'CopernicusFMTemporalBackbone expects B x T x C x H x W, got {tuple(x.shape)}')
        b, t, c, h, w = x.shape
        if c != len(self.wave_list):
            raise ValueError(
                f'Input channel C={c}, but len(wave_list)={len(self.wave_list)}. '
                f'Check channel_map in LoadPastisTemporalImageFromFile and wave_list in config.'
            )
        x = x.reshape(b * t, c, h, w)
        flat_features = self._forward_cfm_chunks(x)
        fused = [self._fuse_one_level(feat, b, t, i) for i, feat in enumerate(flat_features)]
        return tuple(fused)
