# -*- coding: utf-8 -*-
from typing import Optional, Sequence, Union

import torch
from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS


@MODELS.register_module()
class TemporalSegDataPreProcessor(BaseDataPreprocessor):
    """Stack and normalize PASTIS temporal tensors.

    Input tensors are expected as [T,C,H,W]. The batched output is [B,T,C,H,W].
    """

    def __init__(self,
                 scale_factor: Optional[float] = 10000.0,
                 mean: Optional[Sequence[float]] = None,
                 std: Optional[Sequence[float]] = None,
                 channel_order: Union[str, Sequence[int], None] = 's2_13',
                 non_blocking: bool = True):
        super().__init__(non_blocking=non_blocking)
        self.scale_factor = scale_factor
        self.channel_order = channel_order
        self._mean = mean
        self._std = std

    def _stack_inputs(self, inputs):
        if isinstance(inputs, torch.Tensor):
            if inputs.dim() == 4:
                inputs = inputs.unsqueeze(0)
            return inputs
        return torch.stack(inputs, dim=0)

    def _reorder_channels(self, inputs):
        # inputs: [B,T,C,H,W]
        if self.channel_order is None or self.channel_order == 's2_13':
            return inputs
        if isinstance(self.channel_order, str):
            if self.channel_order == 'pastis_10_plus_pad_end':
                # From [B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12,pad,pad,pad]
                # to   [B01,B02,B03,B04,B05,B06,B07,B08,B8A,B09,B10,B11,B12]
                idx = [10, 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 8, 9]
            else:
                raise ValueError(f'Unsupported channel_order={self.channel_order}')
        else:
            idx = list(self.channel_order)
        return inputs[:, :, idx, :, :]

    def _normalize(self, inputs):
        inputs = inputs.float()
        if self.scale_factor is not None:
            inputs = inputs / float(self.scale_factor)
        if self._mean is not None:
            mean = torch.tensor(self._mean, device=inputs.device, dtype=inputs.dtype).view(1, 1, -1, 1, 1)
            inputs = inputs - mean
        if self._std is not None:
            std = torch.tensor(self._std, device=inputs.device, dtype=inputs.dtype).view(1, 1, -1, 1, 1)
            inputs = inputs / std
        return inputs

    def forward(self, data, training=False):
        data = self.cast_data(data)
        inputs = self._stack_inputs(data['inputs'])
        inputs = self._reorder_channels(inputs)
        inputs = self._normalize(inputs)
        return dict(inputs=inputs, data_samples=data.get('data_samples', None))
