from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


@MODELS.register_module()
class LinearProbeHead(BaseDecodeHead):
    """A minimal 1x1-conv linear probe head for dense prediction."""

    def forward(self, inputs):
        x = self._transform_inputs(inputs)
        if isinstance(x, (list, tuple)):
            x = x[-1]
        if self.dropout is not None:
            x = self.dropout(x)
        return self.cls_seg(x)
