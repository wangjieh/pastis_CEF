# -*- coding: utf-8 -*-
from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


@MODELS.register_module()
class LinearProbeHead(BaseDecodeHead):
    """One-layer 1x1-conv segmentation head for linear probing."""

    def __init__(self, **kwargs):
        super().__init__(input_transform=None, **kwargs)

    def forward(self, inputs):
        x = self._transform_inputs(inputs)
        return self.cls_seg(x)
