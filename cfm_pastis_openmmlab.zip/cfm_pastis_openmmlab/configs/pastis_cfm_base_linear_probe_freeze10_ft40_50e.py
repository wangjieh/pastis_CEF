# -*- coding: utf-8 -*-
# PASTIS temporal semantic segmentation with Copernicus-FM Base.
# Change cfm_arch/cfm_embed_dim/intermediate_indices/checkpoint_path to switch base/large.

custom_imports = dict(imports=['cfm_mmseg'], allow_failed_imports=False)
default_scope = 'mmseg'

# ===== User paths =====
data_root = '/path/to/pastis_dataset'
cfm_checkpoint = '/path/to/CopernicusFM_ViT_base_varlang_e100.pth'
work_dir = './work_dirs/pastis_cfm_base_linear_probe_freeze10_ft40_50e'

# ===== Data/model constants =====
num_classes = 19
ignore_index = -1
max_epochs = 50

model = dict(
    type='EncoderDecoder',
    data_preprocessor=dict(
        type='TemporalSegDataPreProcessor',
        scale_factor=10000.0,
        # Use 's2_13' if tensor order is [B01,B02,...,B12].
        # Use 'pastis_10_plus_pad_end' if tensor order is
        # [B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12,pad,pad,pad].
        channel_order='s2_13'),
    backbone=dict(
        type='CopernicusFMTemporalBackbone',
        arch='base',
        checkpoint_path=cfm_checkpoint,
        img_size=224,
        kernel_size=16,
        intermediate_indices=[11],
        temporal_fusion='mean',
        freeze_cfm=False,
        freeze_unused_variable_branch=True,
        time_forward_batch_size=0,
        use_default_area=False,
        default_time_stride_days=None),
    decode_head=dict(
        type='LinearProbeHead',
        in_channels=768,
        channels=768,
        in_index=0,
        num_classes=num_classes,
        dropout_ratio=0.0,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISTemporalDataset',
        split_root=data_root + '/pastis_r_train',
        expected_time_steps=12,
        expected_channels=13,
        ignore_index=ignore_index))

val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISTemporalDataset',
        split_root=data_root + '/pastis_r_val',
        expected_time_steps=12,
        expected_channels=13,
        ignore_index=ignore_index))

test_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    collate_fn=dict(type='pseudo_collate'),
    dataset=dict(
        type='PASTISTemporalDataset',
        split_root=data_root + '/pastis_r_test',
        expected_time_steps=12,
        expected_channels=13,
        ignore_index=ignore_index))

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

optim_wrapper = dict(
    type='AmpOptimWrapper',
    loss_scale='dynamic',
    optimizer=dict(type='AdamW', lr=6e-4, betas=(0.9, 0.999), weight_decay=0.05),
    clip_grad=dict(max_norm=1.0, norm_type=2),
    paramwise_cfg=dict(
        custom_keys={
            'backbone.cfm.pos_embed': dict(decay_mult=0.0),
            'backbone.cfm.cls_token': dict(decay_mult=0.0),
            'backbone.cfm.coord_token': dict(decay_mult=0.0),
            'backbone.cfm.scale_token': dict(decay_mult=0.0),
            'backbone.cfm.time_token': dict(decay_mult=0.0),
            'backbone.cfm': dict(lr_mult=0.1),
            'norm': dict(decay_mult=0.0),
        }))

param_scheduler = [
    dict(type='LinearLR', start_factor=1e-4, by_epoch=True, begin=0, end=1, convert_to_iter_based=True),
    dict(type='CosineAnnealingLR', eta_min=1e-6, by_epoch=True, begin=1, end=max_epochs),
]

custom_hooks = [dict(type='FreezeBackboneHook', unfreeze_epoch=10)]

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(type='CheckpointHook', by_epoch=True, interval=1, max_keep_ckpts=3, save_best='mIoU', rule='greater'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook', draw=False))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(type='LogProcessor', window_size=50, by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
launcher = 'none'
randomness = dict(seed=42, deterministic=False)
model_wrapper_cfg = dict(type='MMDistributedDataParallel', find_unused_parameters=False)
auto_scale_lr = dict(enable=False, base_batch_size=16)
