#!/usr/bin/env bash
set -e
CONFIG=$1
CHECKPOINT=$2
GPUS=${3:-4}
PORT=${PORT:-29500}
shift 3 || true
export PYTHONPATH="$(pwd):${PYTHONPATH}"
torchrun --nproc_per_node=${GPUS} --master_port=${PORT} tools/test.py "$CONFIG" "$CHECKPOINT" --launcher pytorch "$@"
