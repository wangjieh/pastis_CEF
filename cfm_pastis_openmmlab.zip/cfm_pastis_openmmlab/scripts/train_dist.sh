#!/usr/bin/env bash
set -e
CONFIG=$1
GPUS=${2:-4}
PORT=${PORT:-29500}
shift 2 || true
export PYTHONPATH="$(pwd):${PYTHONPATH}"
torchrun --nproc_per_node=${GPUS} --master_port=${PORT} tools/train.py "$CONFIG" --launcher pytorch "$@"
