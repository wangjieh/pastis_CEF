from _bootstrap import PROJECT_ROOT  # noqa: F401
import argparse

from mmengine.utils import import_modules_from_strings
from mmseg.registry import DATASETS
from mmseg.utils import register_all_modules

import cfm_mmseg  # noqa: F401


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--split', default='pastis_r_train')
    parser.add_argument('--channel-map', default='s2_13')
    parser.add_argument('--scale-factor', type=float, default=10000.0)
    parser.add_argument('--no-scale', action='store_true')
    return parser.parse_args()


def main():
    args = parse_args()
    register_all_modules(init_default_scope=False)
    import_modules_from_strings(['cfm_mmseg'])
    scale = None if args.no_scale else args.scale_factor
    pipeline = [
        dict(type='LoadPastisTemporalImageFromFile', to_float32=True, scale_factor=scale,
             input_layout='TCHW', channel_map=args.channel_map),
        dict(type='PackPastisSegInputs'),
    ]
    ds = DATASETS.build(dict(type='PASTISTemporalPtDataset', data_root=args.data_root, split=args.split, pipeline=pipeline))
    print('dataset length:', len(ds))
    item = ds[0]
    print('inputs shape:', tuple(item['inputs'].shape), item['inputs'].dtype)
    print('gt shape:', tuple(item['data_samples'].gt_sem_seg.data.shape), item['data_samples'].gt_sem_seg.data.dtype)
    print('gt unique preview:', item['data_samples'].gt_sem_seg.data.unique()[:30])
    print('metainfo:', item['data_samples'].metainfo)


if __name__ == '__main__':
    main()
