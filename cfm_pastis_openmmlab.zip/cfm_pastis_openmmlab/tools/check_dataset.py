# -*- coding: utf-8 -*-
import argparse
import os
import sys


def main():
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)
    import torch
    import cfm_mmseg  # noqa: F401
    from cfm_mmseg.datasets import PASTISTemporalDataset

    parser = argparse.ArgumentParser()
    parser.add_argument('--split-root', required=True, help='e.g. /data/pastis_dataset/pastis_r_train')
    args = parser.parse_args()
    ds = PASTISTemporalDataset(split_root=args.split_root)
    print('Dataset length:', len(ds))
    item = ds[0]
    print('inputs:', tuple(item['inputs'].shape), item['inputs'].dtype, 'min/max=', float(item['inputs'].min()), float(item['inputs'].max()))
    seg = item['data_samples'].gt_sem_seg.data
    print('gt_sem_seg:', tuple(seg.shape), seg.dtype, 'unique preview=', torch.unique(seg)[:30].tolist())


if __name__ == '__main__':
    main()
