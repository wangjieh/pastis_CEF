#!/usr/bin/env bash
set -e
CONFIG=$1
CHECKPOINT=$2
GPUS=${3:-1}
PORT=${PORT:-29501}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
export PYTHONPATH="$ROOT:$PYTHONPATH"
if [ -z "$CONFIG" ] || [ -z "$CHECKPOINT" ]; then
  echo "Usage: bash tools/dist_test.sh CONFIG CHECKPOINT GPUS [--cfg-options ...]"
  exit 1
fi
shift 3 || true
torchrun --nproc_per_node=$GPUS --master_port=$PORT "$ROOT/tools/test.py" "$CONFIG" "$CHECKPOINT" --launcher pytorch "$@"
