#!/usr/bin/env bash
set -e
CONFIG=$1
GPUS=${2:-1}
PORT=${PORT:-29500}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
export PYTHONPATH="$ROOT:$PYTHONPATH"
if [ -z "$CONFIG" ]; then
  echo "Usage: bash tools/dist_train.sh CONFIG GPUS [--cfg-options ...]"
  exit 1
fi
shift 2 || true
torchrun --nproc_per_node=$GPUS --master_port=$PORT "$ROOT/tools/train.py" "$CONFIG" --launcher pytorch "$@"
