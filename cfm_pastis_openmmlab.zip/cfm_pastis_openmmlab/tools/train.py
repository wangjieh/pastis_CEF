# -*- coding: utf-8 -*-
import argparse
import os
import sys

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmseg.utils import register_all_modules


def parse_args():
    parser = argparse.ArgumentParser(description='Train MMSeg with local CFM-PASTIS plugins')
    parser.add_argument('config', help='config file path')
    parser.add_argument('--work-dir', help='override work_dir')
    parser.add_argument('--resume', action='store_true', help='resume from latest checkpoint in work_dir')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'], default='none')
    parser.add_argument('--cfg-options', nargs='+', action=DictAction, help='override config options')
    return parser.parse_args()


def main():
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)
    import cfm_mmseg  # noqa: F401
    register_all_modules(init_default_scope=False)

    args = parse_args()
    cfg = Config.fromfile(args.config)
    cfg.launcher = args.launcher
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume:
        cfg.resume = True
    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
