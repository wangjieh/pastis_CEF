import argparse
import os

from mmengine.config import Config, DictAction
from mmengine.dist import init_dist
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmseg.utils import register_all_modules


def parse_args():
    parser = argparse.ArgumentParser(description='Train CFM-PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--launcher', choices=['none', 'pytorch', 'slurm', 'mpi'], default='none')
    parser.add_argument('--cfg-options', nargs='+', action=DictAction)
    return parser.parse_args()


def main():
    args = parse_args()
    register_all_modules(init_default_scope=False)
    cfg = Config.fromfile(args.config)
    if cfg.get('custom_imports', None):
        import_modules_from_strings(**cfg['custom_imports'])
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume:
        cfg.resume = True
    cfg.launcher = args.launcher
    if args.launcher != 'none':
        init_dist(args.launcher, **cfg.get('env_cfg', {}).get('dist_cfg', {}))
    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
