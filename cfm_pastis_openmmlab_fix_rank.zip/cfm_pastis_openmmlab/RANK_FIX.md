# RANK / distributed launcher fix

If you see:

```text
KeyError: 'RANK'
```

it means MMEngine is trying to initialize PyTorch distributed training, but the script was not launched by `torchrun`.

## Single GPU

```bash
cd cfm_pastis_openmmlab
export PYTHONPATH=$PWD:$PYTHONPATH

python tools/train.py configs/linear_probe_frozen_50e.py --launcher none
```

or:

```bash
bash scripts/train_single.sh configs/linear_probe_frozen_50e.py
```

## Multi-GPU on one node

```bash
cd cfm_pastis_openmmlab
export PYTHONPATH=$PWD:$PYTHONPATH

torchrun --standalone --nproc_per_node=4 --master_port=29500 \
  tools/train.py configs/upernet_freeze10_ft40_50e.py --launcher pytorch
```

or:

```bash
bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```

## Notes

- Do not use `python tools/train.py ... --launcher pytorch` directly.
- Use `--launcher pytorch` only with `torchrun`.
- Use `--launcher none` for single-process training.
- `tools/train.py` no longer calls `init_dist()` manually; `Runner.from_cfg()` handles distributed initialization once.
