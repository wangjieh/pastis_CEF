# Copernicus-FM + PASTIS Temporal Segmentation for OpenMMLab/MMSegmentation

这个压缩包实现了一个**无需 `pip install -e .`** 的 OpenMMLab/MMSegmentation 集成工程：

- Copernicus-FM backbone wrapper，支持 `small/base/large/huge/custom` 架构参数；
- PASTIS 时序 `.pt` 数据集读取，支持 `12 x 13 x 128 x 128` 输入；
- 时序逐时相经过 Copernicus-FM，再做 temporal mean/attention 融合；
- 支持 linear probe head 和 UPerHead；
- 支持前 10 epoch 冻结 backbone，后 40 epoch 全量 fine-tune；
- 训练配置均为 50 epoch；
- 多卡训练脚本使用 `torchrun` + AdamW + AMP。

## 1. 目录结构

```text
cfm_pastis_openmmlab/
├── cfm_mmseg/                    # 本项目注册模块
│   ├── copernicus_fm/             # Copernicus-FM 官方源码副本，已修正相对导入
│   ├── datasets/                  # PASTIS temporal dataset 和 transforms
│   ├── hooks/                     # freeze/unfreeze hook
│   └── models/                    # backbone / data preprocessor / decode head
├── configs/
│   ├── linear_probe_frozen_50e.py
│   ├── linear_probe_freeze10_ft40_50e.py
│   ├── upernet_head_frozen_50e.py
│   └── upernet_freeze10_ft40_50e.py
├── tools/
│   ├── train.py
│   ├── test.py
│   ├── check_dataset.py
│   └── check_model_forward.py
└── scripts/
    ├── train_single.sh
    ├── train_dist.sh
    └── test_dist.sh
```

## 2. 预期数据格式

```text
pastis_dataset/
├── pastis_r_train/
│   ├── s2_images/
│   │   ├── 0.pt      # 12 x 13 x 128 x 128
│   │   ├── 1.pt
│   │   └── ...
│   └── targets.pt    # N x 128 x 128, label=0..18, ignore=-1
├── pastis_r_val/
│   ├── s2_images/
│   └── targets.pt
└── pastis_r_test/
    ├── s2_images/
    └── targets.pt
```

有效类别数为 `19`，忽略标签为 `-1`。

## 3. 使用前修改配置

打开你要训练的配置文件，例如：

```bash
vim configs/linear_probe_frozen_50e.py
```

至少修改：

```python
data_root = '/你的路径/pastis_dataset'
cfm_pretrained = '/你的路径/CopernicusFM_ViT_base_varlang_e100.pth'
```

如果你的 13 通道顺序已经是：

```text
B01,B02,B03,B04,B05,B06,B07,B08,B8A,B09,B10,B11,B12
```

保持：

```python
channel_map = 's2_13'
```

如果你的 13 通道实际是：

```text
B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12,pad,pad,pad
```

请改成：

```python
channel_map = 'pastis10_padded_last_to_s2_13'
```

如果你的 `.pt` 已经是归一化后的 `[0,1]` 或 z-score 数据，请把：

```python
img_scale_factor = 10000.0
```

改成：

```python
img_scale_factor = None
```

或：

```python
img_scale_factor = 1.0
```

## 4. 检查数据集

在工程根目录执行：

```bash
export PYTHONPATH=$PWD:$PYTHONPATH
python tools/check_dataset.py --data-root /你的路径/pastis_dataset --split pastis_r_train --channel-map s2_13
```

如果你的 padded 13 通道是追加到最后的，请使用：

```bash
python tools/check_dataset.py --data-root /你的路径/pastis_dataset --split pastis_r_train --channel-map pastis10_padded_last_to_s2_13
```

成功时会打印：

```text
dataset length: ...
inputs shape: (12, 13, 128, 128)
gt shape: (1, 128, 128)
```

## 5. 检查模型 forward

不加载权重，仅检查结构：

```bash
python tools/check_model_forward.py configs/linear_probe_frozen_50e.py --checkpoint ""
```

加载 Copernicus-FM 权重检查：

```bash
python tools/check_model_forward.py configs/linear_probe_frozen_50e.py \
  --checkpoint /你的路径/CopernicusFM_ViT_base_varlang_e100.pth
```

默认输入是：

```text
B x T x C x H x W = 1 x 12 x 13 x 128 x 128
```

输出 backbone feature 约为：

```text
linear probe: 1 x 768 x 8 x 8
upernet:      4 个 1 x 768 x 8 x 8 feature
```

## 6. 单卡训练

```bash
bash scripts/train_single.sh configs/linear_probe_frozen_50e.py
```

## 7. 多卡训练

4 卡训练：

```bash
bash scripts/train_dist.sh configs/linear_probe_frozen_50e.py 4
```

指定端口：

```bash
PORT=29601 bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```

## 8. 四个配置文件说明

| 配置文件 | 说明 |
|---|---|
| `linear_probe_frozen_50e.py` | linear probe 分割头，冻结 Copernicus-FM backbone，只训练分割头，50 epoch |
| `linear_probe_freeze10_ft40_50e.py` | linear probe 分割头，前 10 epoch 冻结 backbone，后 40 epoch 全量 fine-tune |
| `upernet_head_frozen_50e.py` | UPerHead 分割头，冻结 Copernicus-FM backbone，只训练 UPerHead，50 epoch |
| `upernet_freeze10_ft40_50e.py` | UPerHead 分割头，前 10 epoch 冻结 backbone，后 40 epoch 全量 fine-tune |

> 你问题里第 3 点写的是“使用 upernet 作为分割头，只训练 linear probe”。这里我按工程语义实现为：**使用 UPerHead 作为分割头，只训练 UPerHead，backbone 冻结**。

## 9. 从 base 切换到 large

以 `linear_probe_frozen_50e.py` 为例，修改：

```python
cfm_pretrained = '/你的路径/CopernicusFM_ViT_large_varlang_e100.pth'
cfm_arch = 'large'
cfm_embed_dim = 1024
cfm_depth = 24
```

linear probe 的 `out_indices=(cfm_depth - 1,)` 会自动变成最后一层，即第 23 层。

UPerHead 配置中默认 `out_indices=(2,5,8,cfm_depth-1)` 是适合 base 的轻量设置。切到 large 时，建议改为：

```python
out_indices=(5, 11, 17, cfm_depth - 1)
```

同时把：

```python
in_channels=[cfm_embed_dim, cfm_embed_dim, cfm_embed_dim, cfm_embed_dim]
```

保持不变即可。

## 10. 显存建议

PASTIS 输入是 `B x 12 x 13 x 128 x 128`，逐时相过 ViT。显存不足时优先调整：

```python
train_dataloader = dict(batch_size=1, ...)
time_chunk_size = 2  # 或 4
```

`time_chunk_size` 会把 `B*T` 个时相分块送入 Copernicus-FM，降低瞬时显存。

## 11. 优化器说明

配置默认使用：

- `AdamW`
- `AmpOptimWrapper` 动态混合精度
- 梯度裁剪 `max_norm=1.0`
- fine-tune 配置中 backbone 使用 `lr_mult=0.1`
- 多卡训练使用 `torchrun` + `SyncBN` UPerHead

如果你扩大总 batch size，可以开启：

```python
auto_scale_lr = dict(enable=True, base_batch_size=16)
```


## Fix note: ignore_index

For MMSegmentation versions where `CrossEntropyLoss` does not accept `ignore_index`,
this project places `ignore_index=-1` at the `decode_head` level instead of inside
`loss_decode`. The decode head passes the ignore index to the loss during training.


## RANK 报错修复

如果出现 `KeyError: 'RANK'`，请看 `RANK_FIX.md`。单卡使用 `--launcher none`，多卡必须用 `torchrun` 或 `scripts/train_dist.sh`。
