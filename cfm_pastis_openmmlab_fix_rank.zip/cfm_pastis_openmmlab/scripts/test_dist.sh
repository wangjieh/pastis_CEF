#!/usr/bin/env bash
set -euo pipefail

CONFIG=$1
CHECKPOINT=$2
GPUS=${3:-4}
PORT=${PORT:-29500}
shift 3 || true

export PYTHONPATH="$(pwd):${PYTHONPATH:-}"
export MASTER_ADDR=${MASTER_ADDR:-127.0.0.1}

torchrun \
  --standalone \
  --nnodes=1 \
  --nproc_per_node="${GPUS}" \
  --master_port="${PORT}" \
  tools/test.py "$CONFIG" "$CHECKPOINT" --launcher pytorch "$@"
