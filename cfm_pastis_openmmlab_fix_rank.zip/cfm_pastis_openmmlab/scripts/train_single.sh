#!/usr/bin/env bash
set -euo pipefail

CONFIG=$1
shift || true

export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

python tools/train.py "$CONFIG" --launcher none "$@"
