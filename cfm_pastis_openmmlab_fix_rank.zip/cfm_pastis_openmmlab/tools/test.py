import argparse
import os

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmseg.utils import register_all_modules


def parse_args():
    parser = argparse.ArgumentParser(description='Test CFM-PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('checkpoint')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='Use "pytorch" only when launched by torchrun.',
    )
    parser.add_argument('--cfg-options', nargs='+', action=DictAction)
    return parser.parse_args()


def _check_launcher_env(launcher: str) -> None:
    if launcher == 'pytorch':
        required = ['RANK', 'WORLD_SIZE', 'LOCAL_RANK', 'MASTER_ADDR', 'MASTER_PORT']
        missing = [k for k in required if k not in os.environ]
        if missing:
            raise RuntimeError(
                'launcher="pytorch" requires torchrun/distributed environment variables. '
                f'Missing: {missing}. '
                'For single GPU/CPU, run with --launcher none. '
                'For multi-GPU, launch this script with torchrun.'
            )


def main():
    args = parse_args()
    register_all_modules(init_default_scope=False)

    cfg = Config.fromfile(args.config)

    if cfg.get('custom_imports', None):
        import_modules_from_strings(**cfg['custom_imports'])

    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)

    if args.work_dir is not None:
        cfg.work_dir = args.work_dir

    cfg.load_from = args.checkpoint
    cfg.launcher = args.launcher
    _check_launcher_env(cfg.launcher)

    runner = Runner.from_cfg(cfg)
    runner.test()


if __name__ == '__main__':
    main()
