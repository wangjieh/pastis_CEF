import argparse
import os

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmengine.utils import import_modules_from_strings
from mmseg.utils import register_all_modules


def parse_args():
    parser = argparse.ArgumentParser(description='Train CFM-PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help=(
            'Use "none" for single-process training. '
            'Use "pytorch" only when this script is launched by torchrun.'
        ),
    )
    parser.add_argument('--cfg-options', nargs='+', action=DictAction)
    return parser.parse_args()


def _check_launcher_env(launcher: str) -> None:
    """Fail early with a clear message for the common RANK error."""
    if launcher == 'pytorch':
        required = ['RANK', 'WORLD_SIZE', 'LOCAL_RANK', 'MASTER_ADDR', 'MASTER_PORT']
        missing = [k for k in required if k not in os.environ]
        if missing:
            raise RuntimeError(
                'launcher="pytorch" requires torchrun/distributed environment variables. '
                f'Missing: {missing}. '
                'For single GPU/CPU, run: python tools/train.py CONFIG --launcher none. '
                'For multi-GPU, run: torchrun --nproc_per_node=N tools/train.py CONFIG --launcher pytorch.'
            )


def main():
    args = parse_args()

    # Register MMSeg and this project. Keep PYTHONPATH pointing to the package root.
    register_all_modules(init_default_scope=False)

    cfg = Config.fromfile(args.config)

    if cfg.get('custom_imports', None):
        import_modules_from_strings(**cfg['custom_imports'])

    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)

    if args.work_dir is not None:
        cfg.work_dir = args.work_dir

    if args.resume:
        cfg.resume = True

    # Important:
    # Do NOT call mmengine.dist.init_dist() manually here.
    # Runner.from_cfg(cfg) will call init_dist() once according to cfg.launcher.
    cfg.launcher = args.launcher
    _check_launcher_env(cfg.launcher)

    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
