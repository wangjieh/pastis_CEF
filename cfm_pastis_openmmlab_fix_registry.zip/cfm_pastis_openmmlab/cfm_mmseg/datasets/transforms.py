from typing import Optional, Tuple

import numpy as np
import torch
from mmcv.transforms import BaseTransform
from mmengine.structures import PixelData
from mmseg.structures import SegDataSample

try:
    from mmengine.registry import TRANSFORMS as MMENGINE_TRANSFORMS
except Exception:  # pragma: no cover
    MMENGINE_TRANSFORMS = None

try:
    from mmseg.registry import TRANSFORMS as MMSEG_TRANSFORMS
except Exception:  # pragma: no cover
    MMSEG_TRANSFORMS = None


S2_13_ORDER = ('B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B8A', 'B09', 'B10', 'B11', 'B12')
PASTIS_10_ORDER = ('B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B8A', 'B11', 'B12')


def _register_transform(cls):
    """Register a transform into both MMEngine and MMSeg registries.

    Some MMSeg/MMEngine versions let ``BaseDataset`` build pipeline transforms
    from ``mmengine::transform`` instead of ``mmseg::transform``. Registering
    only to ``mmseg.registry.TRANSFORMS`` can therefore produce:

        KeyError: 'LoadPastisTemporalImageFromFile is not in the mmengine::transform registry'

    This helper makes the custom PASTIS transforms visible to both registries.
    ``force=True`` keeps repeated imports harmless in debug runs.
    """
    registries = []
    seen = set()
    for registry in (MMENGINE_TRANSFORMS, MMSEG_TRANSFORMS):
        if registry is not None and id(registry) not in seen:
            registries.append(registry)
            seen.add(id(registry))

    for registry in registries:
        try:
            registry.register_module(module=cls, force=True)
        except TypeError:
            registry.register_module(force=True)(cls)
    return cls


def _extract_tensor(obj):
    if torch.is_tensor(obj):
        return obj
    if isinstance(obj, np.ndarray):
        return torch.from_numpy(obj)
    if isinstance(obj, dict):
        for key in ('img', 'image', 's2', 's2_image', 'data', 'x'):
            if key in obj:
                return _extract_tensor(obj[key])
    raise TypeError(f'Cannot extract tensor from object of type {type(obj)}')


def _apply_channel_map(img: torch.Tensor, channel_map: Optional[str]) -> torch.Tensor:
    """Map channels to Copernicus-FM Sentinel-2 13-band order.

    Supported layouts:
    - None or 'none': do nothing.
    - 's2_13': already B01,B02,...,B12.
    - 'pastis10_to_s2_13': input C=10 in PASTIS order; insert zero B01/B09/B10.
    - 'pastis10_padded_last_to_s2_13': input C=13 where first 10 are PASTIS order
      and last 3 are padded channels; reorder to S2 13-band order.
    """
    if channel_map is None or str(channel_map).lower() in ('none', 'identity', 's2_13'):
        return img

    channel_map = str(channel_map).lower()
    if img.ndim != 4:
        raise ValueError(f'Expected image shape T x C x H x W before channel mapping, got {tuple(img.shape)}')
    t, c, h, w = img.shape

    if channel_map == 'pastis10_to_s2_13':
        if c != 10:
            raise ValueError(f'pastis10_to_s2_13 expects C=10, got C={c}')
        out = img.new_zeros((t, 13, h, w))
        # output S2-13: B01, B02, B03, B04, B05, B06, B07, B08, B8A, B09, B10, B11, B12
        # input PASTIS-10: B02, B03, B04, B05, B06, B07, B08, B8A, B11, B12
        out[:, 1] = img[:, 0]
        out[:, 2] = img[:, 1]
        out[:, 3] = img[:, 2]
        out[:, 4] = img[:, 3]
        out[:, 5] = img[:, 4]
        out[:, 6] = img[:, 5]
        out[:, 7] = img[:, 6]
        out[:, 8] = img[:, 7]
        out[:, 11] = img[:, 8]
        out[:, 12] = img[:, 9]
        return out

    if channel_map == 'pastis10_padded_last_to_s2_13':
        if c != 13:
            raise ValueError(f'pastis10_padded_last_to_s2_13 expects C=13, got C={c}')
        # Assumption: [B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12,pad_B01,pad_B09,pad_B10]
        idx = [10, 0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 8, 9]
        return img[:, idx]

    raise ValueError(f'Unsupported channel_map={channel_map!r}')


@_register_transform
class LoadPastisTemporalImageFromFile(BaseTransform):
    def __init__(
        self,
        to_float32: bool = True,
        scale_factor: Optional[float] = 10000.0,
        input_layout: str = 'TCHW',
        channel_map: Optional[str] = 's2_13',
    ):
        self.to_float32 = to_float32
        self.scale_factor = scale_factor
        self.input_layout = input_layout.upper()
        self.channel_map = channel_map

    def transform(self, results: dict) -> dict:
        obj = torch.load(results['img_path'], map_location='cpu')
        img = _extract_tensor(obj)
        if img.ndim == 3:
            img = img.unsqueeze(0)
        if img.ndim != 4:
            raise ValueError(f'Expected image tensor with 4 dims, got {tuple(img.shape)} from {results["img_path"]}')

        if self.input_layout == 'CTHW':
            img = img.permute(1, 0, 2, 3).contiguous()
        elif self.input_layout != 'TCHW':
            raise ValueError(f'Unsupported input_layout={self.input_layout!r}. Use TCHW or CTHW.')

        if self.to_float32:
            img = img.float()
        if self.scale_factor is not None:
            img = img / float(self.scale_factor)
        img = _apply_channel_map(img, self.channel_map)

        _, c, h, w = img.shape
        results['img'] = img.contiguous()
        results['ori_shape'] = (h, w)
        results['img_shape'] = (h, w)
        results['pad_shape'] = (h, w)
        results['num_channels'] = c
        results['num_timesteps'] = img.shape[0]
        return results


@_register_transform
class LoadPastisTemporalAnnotations(BaseTransform):
    """Optional annotation loader.

    The dataset already injects ``gt_seg_map`` for efficiency. This transform is kept
    for flexibility when a custom dataset only provides ``target_path`` and
    ``target_index`` in results.
    """

    def transform(self, results: dict) -> dict:
        if 'gt_seg_map' not in results:
            targets = torch.load(results['target_path'], map_location='cpu')
            if isinstance(targets, dict):
                for key in ('targets', 'target', 'labels', 'masks', 'y'):
                    if key in targets:
                        targets = targets[key]
                        break
            results['gt_seg_map'] = targets[results['target_index']]
        results['gt_seg_map'] = torch.as_tensor(results['gt_seg_map']).long()
        results.setdefault('seg_fields', []).append('gt_seg_map')
        return results


@_register_transform
class PackPastisSegInputs(BaseTransform):
    def __init__(
        self,
        meta_keys: Tuple[str, ...] = (
            'img_path', 'target_path', 'target_index', 'sample_idx',
            'ori_shape', 'img_shape', 'pad_shape', 'num_channels', 'num_timesteps'
        ),
    ):
        self.meta_keys = meta_keys

    def transform(self, results: dict) -> dict:
        img = results['img']
        if not torch.is_tensor(img):
            img = torch.as_tensor(img)
        img = img.contiguous()

        data_sample = SegDataSample()
        if 'gt_seg_map' in results:
            gt = torch.as_tensor(results['gt_seg_map']).long()
            if gt.ndim == 2:
                gt = gt.unsqueeze(0)
            data_sample.gt_sem_seg = PixelData(data=gt.contiguous())

        img_meta = {key: results[key] for key in self.meta_keys if key in results}
        data_sample.set_metainfo(img_meta)
        return dict(inputs=img, data_samples=data_sample)
