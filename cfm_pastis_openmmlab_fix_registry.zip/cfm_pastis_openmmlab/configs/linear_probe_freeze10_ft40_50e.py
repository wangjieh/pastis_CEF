custom_imports = dict(imports=['cfm_mmseg'], allow_failed_imports=False)
default_scope = 'mmseg'

# ======================== Paths you must edit ========================
data_root = '/path/to/pastis_dataset'
cfm_pretrained = '/path/to/CopernicusFM_ViT_base_varlang_e100.pth'
work_dir = './work_dirs/linear_probe_freeze10_ft40_50e'

# ======================== Dataset settings ===========================
num_classes = 19
ignore_index = -1
crop_size = (128, 128)

# If your 13-channel tensor is already [B01,B02,...,B12], keep channel_map='s2_13'.
# If it is [B02,B03,...,B12,pad,pad,pad], use 'pastis10_padded_last_to_s2_13'.
# If it is still 10 channels [B02,B03,...,B12], use 'pastis10_to_s2_13'.
channel_map = 's2_13'
img_scale_factor = 10000.0  # set to None or 1.0 if your .pt files are already normalized

train_pipeline = [
    dict(type='LoadPastisTemporalImageFromFile', to_float32=True, scale_factor=img_scale_factor,
         input_layout='TCHW', channel_map=channel_map),
    dict(type='PackPastisSegInputs'),
]
test_pipeline = train_pipeline

dataset_type = 'PASTISTemporalPtDataset'
train_dataloader = dict(
    batch_size=2,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(type=dataset_type, data_root=data_root, split='pastis_r_train', pipeline=train_pipeline),
)
val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(type=dataset_type, data_root=data_root, split='pastis_r_val', pipeline=test_pipeline),
)
test_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(type=dataset_type, data_root=data_root, split='pastis_r_test', pipeline=test_pipeline),
)

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU'], ignore_index=ignore_index)
test_evaluator = val_evaluator

# ======================== Copernicus-FM settings =====================
cfm_arch = 'base'
cfm_embed_dim = 768
cfm_depth = 12
kernel_size = 16
time_chunk_size = 12  # reduce this, e.g. 2 or 4, if GPU memory is insufficient

s2_13_wavelengths = [440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190]
s2_13_bandwidths = [20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180]

data_preprocessor = dict(type='PastisTemporalDataPreprocessor', pad_size_divisor=1, seg_pad_value=ignore_index)

# ======================== Runtime settings ===========================
default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=20, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(type='CheckpointHook', by_epoch=True, interval=1, max_keep_ckpts=3, save_best='mIoU'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'),
)
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)
vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(type='SegLocalVisualizer', vis_backends=vis_backends, name='visualizer')
log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

param_scheduler = [
    dict(type='LinearLR', start_factor=1e-3, by_epoch=True, begin=0, end=5),
    dict(type='CosineAnnealingLR', eta_min=1e-6, by_epoch=True, begin=5, end=50, T_max=45),
]

auto_scale_lr = dict(enable=False, base_batch_size=16)
randomness = dict(seed=42, deterministic=False)


model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='CopernicusFMTemporalBackbone',
        arch=cfm_arch,
        pretrained=cfm_pretrained,
        out_indices=(cfm_depth - 1,),
        kernel_size=kernel_size,
        wave_list=s2_13_wavelengths,
        bandwidth=s2_13_bandwidths,
        temporal_fusion='mean',
        time_chunk_size=time_chunk_size,
        freeze_backbone=False,
        meta_mode='nan',
    ),
    decode_head=dict(
        type='LinearProbeHead',
        in_channels=cfm_embed_dim,
        channels=cfm_embed_dim,
        in_index=0,
        num_classes=num_classes,
        dropout_ratio=0.0,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)


optim_wrapper = dict(
    type='AmpOptimWrapper',
    loss_scale='dynamic',
    optimizer=dict(type='AdamW', lr=1e-4, betas=(0.9, 0.999), weight_decay=0.05),
    paramwise_cfg=dict(
        custom_keys={
            'backbone.cfm': dict(lr_mult=0.1),
            'pos_embed': dict(decay_mult=0.0),
            'cls_token': dict(decay_mult=0.0),
            'coord_token': dict(decay_mult=0.0),
            'scale_token': dict(decay_mult=0.0),
            'time_token': dict(decay_mult=0.0),
            'norm': dict(decay_mult=0.0),
        }
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)
custom_hooks = [dict(type='FreezeBackboneBeforeEpochHook', unfreeze_epoch=10)]
