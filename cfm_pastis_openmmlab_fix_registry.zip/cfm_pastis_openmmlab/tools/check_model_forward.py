import os
import sys

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import argparse

import torch
from mmengine.config import Config
from mmengine.utils import import_modules_from_strings
from mmseg.registry import MODELS
from mmseg.utils import register_all_modules


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('config')
    parser.add_argument('--checkpoint', default=None, help='Override cfm_pretrained. Use empty string to skip loading.')
    parser.add_argument('--batch-size', type=int, default=1)
    parser.add_argument('--timesteps', type=int, default=12)
    parser.add_argument('--channels', type=int, default=13)
    parser.add_argument('--height', type=int, default=128)
    parser.add_argument('--width', type=int, default=128)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    return parser.parse_args()


def main():
    args = parse_args()
    register_all_modules(init_default_scope=False)
    cfg = Config.fromfile(args.config)
    if cfg.get('custom_imports', None):
        import_modules_from_strings(**cfg['custom_imports'])
    if args.checkpoint is not None:
        cfg.model.backbone.pretrained = args.checkpoint or None
    model = MODELS.build(cfg.model)
    model.init_weights()
    model.to(args.device)
    model.eval()
    x = torch.randn(args.batch_size, args.timesteps, args.channels, args.height, args.width, device=args.device)
    with torch.no_grad():
        feats = model.backbone(x)
    print('backbone outputs:')
    for i, feat in enumerate(feats):
        print(f'  level {i}: shape={tuple(feat.shape)}, dtype={feat.dtype}')


if __name__ == '__main__':
    main()
