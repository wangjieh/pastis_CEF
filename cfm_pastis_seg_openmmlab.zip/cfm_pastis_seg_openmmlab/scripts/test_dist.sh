#!/usr/bin/env bash
set -e
CONFIG=$1
CKPT=$2
GPUS=${3:-4}
PORT=${PORT:-29500}
torchrun --nproc_per_node=$GPUS --master_port=$PORT tools/test.py $CONFIG $CKPT ${@:4}
