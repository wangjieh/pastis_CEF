import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmengine.runner import Runner


def parse_args():
    parser = argparse.ArgumentParser(description='Train Copernicus-FM on PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--amp', action='store_true', help='Force AMPOptimWrapper when not already enabled in config')
    parser.add_argument('--cfg-options', nargs='+', action='append', default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = Config.fromfile(args.config)
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume:
        cfg.resume = True
    if args.amp:
        cfg.optim_wrapper.type = 'AmpOptimWrapper'
        cfg.optim_wrapper.setdefault('loss_scale', 'dynamic')
    if args.cfg_options:
        for opts in args.cfg_options:
            cfg.merge_from_dict(dict(opt.split('=', 1) for opt in opts))
    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
