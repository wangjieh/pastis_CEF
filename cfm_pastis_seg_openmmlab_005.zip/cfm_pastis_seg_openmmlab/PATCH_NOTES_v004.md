# v004 修复说明

本版本修复 `KeyError: 'RANK'`。

## 原因

v003 的 4 个 config 均写死：

```python
launcher = 'pytorch'
```

当使用普通单进程命令：

```bash
python tools/train.py configs/upernet_freeze10_ft40_50e.py
```

MMEngine 会按分布式方式初始化，并读取环境变量 `RANK`。
普通 `python` 启动不会设置 `RANK`，因此报错。

## 修复

- 4 个 config 默认改为：

```python
launcher = 'none'
```

- `tools/train.py` 和 `tools/test.py` 新增 `--launcher` 参数。
- 如果旧 config 仍然写了 `launcher='pytorch'`，但环境中没有 `RANK`，脚本会自动回退到 `launcher='none'`。
- 多卡脚本显式使用：

```bash
--launcher pytorch
```

## 单卡训练

```bash
python tools/train.py configs/linear_probe_frozen_50e.py
python tools/train.py configs/linear_probe_freeze10_ft40_50e.py
python tools/train.py configs/upernet_head_frozen_50e.py
python tools/train.py configs/upernet_freeze10_ft40_50e.py
```

## 多卡训练

```bash
bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```

或手动：

```bash
torchrun --nproc_per_node=4 --master_port=29500 \
  tools/train.py configs/upernet_freeze10_ft40_50e.py --launcher pytorch
```
