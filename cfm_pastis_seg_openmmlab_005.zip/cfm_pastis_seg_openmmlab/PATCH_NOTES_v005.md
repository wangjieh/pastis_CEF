# PATCH_NOTES_v005

修复训练启动时的 `urllib.error.HTTPError: HTTP Error 404: Not Found`。

## 根因

`CopernicusFMTemporalSegBackbone` 在构建 `CopernicusFMViT` 时硬编码 `var_option='language'`，导致
`Dynamic_MLP_OFA_variable` 初始化时尝试下载 `var_embed_llama3.2_1B.pt`。该下载 URL 在训练环境中返回 404。

PASTIS Sentinel-2 语义分割实际使用 `input_mode='spectral'`，不需要 language embedding 分支。

## 修改

1. `CopernicusFMTemporalSegBackbone` 新增 `var_option` 参数，默认 `'spectrum'`。
2. 4 个配置文件显式加入：

```python
input_mode='spectral',
var_option='spectrum',
```

3. `dynamic_hypernetwork.py` 不再自动联网下载 `var_embed_llama3.2_1B.pt`。如果用户手动选择
   `var_option='language'` 且文件不存在，会给出明确错误信息。

## 训练命令不变

单卡：

```bash
python tools/train.py configs/upernet_freeze10_ft40_50e.py
```

多卡：

```bash
bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```
