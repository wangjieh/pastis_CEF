# Copernicus-FM + PASTIS Temporal Semantic Segmentation for OpenMMLab


## v004 重要修复：单卡 / 多卡 launcher

本版本已修复 `KeyError: 'RANK'`。  
单卡或普通调试请直接使用：

```bash
python tools/train.py configs/upernet_freeze10_ft40_50e.py
```

多卡请使用：

```bash
bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```

不要用普通 `python` 搭配 `launcher='pytorch'`，否则 MMEngine 会寻找 `RANK/WORLD_SIZE` 等分布式环境变量。

这个版本按 **Copernicus-FM 官方分割骨干 `models_dwv_seg.py`** 重写，不再使用图像级全局 embedding。
骨干网逐时相处理 PASTIS 的 `B x T x C x H x W` 输入，提取多个 transformer block 的 dense feature map，
再做 temporal mean/attention 融合，最后接 Linear Probe 或 UPerNet 分割头。

## 1. 目录内容

```text
cfm_pastis_seg_openmmlab/
├── cfm_mmseg/
│   ├── copernicus_fm/              # Copernicus-FM 官方分割版核心代码
│   ├── datasets/                   # PASTIS-R .pt 时序数据集
│   ├── models/
│   │   ├── backbones/              # CopernicusFMTemporalSegBackbone
│   │   ├── decode_heads/           # LinearProbeHead
│   │   └── data_preprocessor.py
│   └── hooks/                      # 冻结前10轮、后40轮微调 hook
├── configs/
│   ├── linear_probe_frozen_50e.py
│   ├── linear_probe_freeze10_ft40_50e.py
│   ├── upernet_head_frozen_50e.py
│   └── upernet_freeze10_ft40_50e.py
├── tools/
└── scripts/
```

不需要 `pip install -e .`。训练脚本会自动把工程根目录加入 `sys.path`。

## 2. 数据格式

支持你给的 PASTIS-R processor 输出：

```text
processed_pastis_r/
├── pastis_r_train/
│   ├── s2_images/0.pt              # shape: T x C x H x W，例如 12 x 13 x 128 x 128
│   ├── s2_images/1.pt
│   ├── months.pt
│   └── targets.pt                  # shape: N x H x W，ignore label = -1
├── pastis_r_valid/
└── pastis_r_test/
```

如果你的验证集目录叫 `pastis_r_val`，把配置里的 `split='pastis_r_valid'` 改成 `split='pastis_r_val'`。

## 3. 先改配置文件顶部

每个 config 顶部都有：

```python
data_root = '/path/to/processed_pastis_r'
pretrained = '/path/to/CopernicusFM_ViT_base_varlang_e100.pth'
arch = 'base'
```

切换 large：

```python
arch = 'large'
pretrained = '/path/to/CopernicusFM_ViT_large_varlang_e100.pth'
```

一般 large 需要把 `batch_size` 调小。

## 4. 通道说明

默认配置：

```python
dict(type='LoadPastisTemporalImageFromFile', scale_factor=10000.0, channel_map='s2_13')
```

你的 processor 已经把 10 个 PASTIS band impute 成 13 通道，并且顺序是：

```text
[B01,B02,B03,B04,B05,B06,B07,B08,B8A,B09,B10,B11,B12]
```

所以用 `channel_map='s2_13'` 是正确的。

如果以后直接使用原始 10 通道，则改为：

```python
channel_map='pastis10_to_s2_13'
```

这会按以下规则补全：`B01 <- B02`, `B09 <- B8A`, `B10 <- B11`。

## 5. 正则化建议

第一版建议只做：

```python
scale_factor=10000.0
mean=None
std=None
```

也就是把反射率缩放到大约 0~1，不做 z-score。
如果你要加 z-score，必须用 train split 统计 **处理后 13 通道** 的 mean/std；复制出来的通道要继承源波段统计量。

## 6. 检查数据

```bash
python tools/check_dataset.py   --data-root /path/to/processed_pastis_r   --split pastis_r_train   --channel-map s2_13
```

期望类似：

```text
dataset length: 1455
inputs shape: (12, 13, 128, 128) torch.float32
gt shape: (1, 128, 128) torch.int64
```

## 7. 单卡训练

```bash
python tools/train.py configs/linear_probe_frozen_50e.py
python tools/train.py configs/linear_probe_freeze10_ft40_50e.py
python tools/train.py configs/upernet_head_frozen_50e.py
python tools/train.py configs/upernet_freeze10_ft40_50e.py
```

## 8. 多卡训练

```bash
bash scripts/train_dist.sh configs/upernet_freeze10_ft40_50e.py 4
```

配置默认使用 `AmpOptimWrapper + AdamW + auto_scale_lr`，适合多卡。实际总 batch size 改变时，`auto_scale_lr` 会按 `base_batch_size=16` 缩放学习率。

## 9. 验证是否真的全量微调

```bash
python tools/check_trainable_params.py configs/upernet_freeze10_ft40_50e.py
```

注意：这个脚本只检查初始化状态。`freeze10_ft40` 配置初始化时 backbone 是 trainable，训练开始前 hook 冻结，epoch 10 再解冻。
训练日志里应出现：

```text
[FreezeBackboneBeforeEpochHook] backbone trainable=False; ... cfm trainable params=0/...
[FreezeBackboneBeforeEpochHook] backbone trainable=True;  ... cfm trainable params=.../...
```

如果第二行没有出现，就没有进入全量微调。

## 10. 这版和之前的关键区别

之前容易不对齐的核心原因是：如果调用 `models_dwv.py`，它返回的是图像级全局特征；
这版调用官方 `models_dwv_seg.py`，返回的是中间层 dense feature map：

```text
B*T x D x h x w
```

再 reshape 成：

```text
B x T x D x h x w
```

最后做时间融合，接分割头。这才是语义分割任务应该使用的接口。
