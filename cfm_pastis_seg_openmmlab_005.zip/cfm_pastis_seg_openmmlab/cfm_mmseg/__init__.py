"""OpenMMLab components for Copernicus-FM + PASTIS semantic segmentation."""

from .datasets import *  # noqa: F401,F403
from .models import *  # noqa: F401,F403
from .hooks import *  # noqa: F401,F403
