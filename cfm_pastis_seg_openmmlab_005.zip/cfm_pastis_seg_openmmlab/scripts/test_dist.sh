#!/usr/bin/env bash
set -e

CONFIG=$1
CHECKPOINT=$2
GPUS=${3:-4}
PORT=${PORT:-29500}

if [ -z "$CONFIG" ] || [ -z "$CHECKPOINT" ]; then
  echo "Usage: bash scripts/test_dist.sh CONFIG CHECKPOINT [GPUS] [extra args...]"
  exit 1
fi

torchrun --nproc_per_node=$GPUS --master_port=$PORT \
  tools/test.py "$CONFIG" "$CHECKPOINT" --launcher pytorch ${@:4}
