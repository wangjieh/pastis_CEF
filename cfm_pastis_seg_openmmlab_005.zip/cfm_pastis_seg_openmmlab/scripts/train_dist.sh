#!/usr/bin/env bash
set -e

CONFIG=$1
GPUS=${2:-4}
PORT=${PORT:-29500}

if [ -z "$CONFIG" ]; then
  echo "Usage: bash scripts/train_dist.sh CONFIG [GPUS] [extra args...]"
  exit 1
fi

torchrun --nproc_per_node=$GPUS --master_port=$PORT \
  tools/train.py "$CONFIG" --launcher pytorch ${@:3}
