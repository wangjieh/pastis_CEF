import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import cfm_mmseg  # noqa: F401
from mmseg.registry import DATASETS


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', required=True)
    parser.add_argument('--split', default='pastis_r_train')
    parser.add_argument('--channel-map', default='s2_13')
    parser.add_argument('--scale-factor', type=float, default=10000.0)
    return parser.parse_args()


def main():
    args = parse_args()
    pipeline = [
        dict(type='LoadPastisTemporalImageFromFile', scale_factor=args.scale_factor, channel_map=args.channel_map),
        dict(type='LoadPastisTemporalAnnotations'),
        dict(type='PackPastisSegInputs'),
    ]
    ds = DATASETS.build(dict(type='PASTISTemporalPtDataset', data_root=args.data_root, split=args.split, pipeline=pipeline))
    print('dataset length:', len(ds))
    sample = ds[0]
    print('inputs shape:', tuple(sample['inputs'].shape), sample['inputs'].dtype)
    gt = sample['data_samples'].gt_sem_seg.data
    print('gt shape:', tuple(gt.shape), gt.dtype)
    print('gt unique preview:', gt.unique()[:30])
    print('metainfo:', sample['data_samples'].metainfo)


if __name__ == '__main__':
    main()
