import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import torch
import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmseg.registry import MODELS


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('config')
    parser.add_argument('--batch-size', type=int, default=1)
    parser.add_argument('--timesteps', type=int, default=12)
    parser.add_argument('--channels', type=int, default=13)
    parser.add_argument('--height', type=int, default=128)
    parser.add_argument('--width', type=int, default=128)
    parser.add_argument('--device', default='cpu')
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = Config.fromfile(args.config)
    model = MODELS.build(cfg.model)
    model.init_weights()
    model.to(args.device)
    model.eval()
    x = torch.randn(args.batch_size, args.timesteps, args.channels, args.height, args.width, device=args.device)
    with torch.no_grad():
        feats = model.backbone(x)
        print('backbone features:')
        for i, f in enumerate(feats):
            print(i, tuple(f.shape), f.dtype)


if __name__ == '__main__':
    main()
