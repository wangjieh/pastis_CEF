import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import torch
import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmseg.registry import MODELS
from cfm_mmseg.models.backbones.copernicus_fm_temporal_seg import _load_checkpoint_state


def find_key(k, model_state):
    candidates = [k, 'backbone.' + k, 'backbone.cfm.' + k]
    for c in candidates:
        if c in model_state:
            return c
    for mk in model_state:
        if mk.endswith('.' + k):
            return mk
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config')
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--keys', nargs='*', default=['cls_token', 'pos_embed', 'blocks.0.attn.qkv.weight'])
    args = parser.parse_args()
    cfg = Config.fromfile(args.config)
    model = MODELS.build(cfg.model)
    model.init_weights()
    model_state = model.state_dict()
    ckpt_state = _load_checkpoint_state(args.checkpoint)
    matched = 0
    matched_params = 0
    for k, v in ckpt_state.items():
        mk = find_key(k, model_state)
        if mk is not None and tuple(v.shape) == tuple(model_state[mk].shape):
            matched += 1
            matched_params += v.numel()
    ckpt_params = sum(v.numel() for v in ckpt_state.values() if torch.is_tensor(v))
    print(f'Matched tensor keys: {matched} / {len(ckpt_state)}')
    print(f'Matched params: {matched_params:,} / {ckpt_params:,}')
    for k in args.keys:
        if k not in ckpt_state:
            print('[CKPT MISSING]', k)
            continue
        mk = find_key(k, model_state)
        if mk is None:
            print('[MODEL MISSING]', k)
            continue
        diff = (ckpt_state[k] - model_state[mk].cpu()).abs()
        print(f'{k} -> {mk}: max_abs_diff={diff.max().item():.8e}, mean_abs_diff={diff.mean().item():.8e}')


if __name__ == '__main__':
    main()
