import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmseg.registry import MODELS


def count(module):
    total = sum(p.numel() for p in module.parameters())
    trainable = sum(p.numel() for p in module.parameters() if p.requires_grad)
    return total, trainable


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config')
    args = parser.parse_args()
    cfg = Config.fromfile(args.config)
    model = MODELS.build(cfg.model)
    model.init_weights()
    for name, module in [('model', model), ('backbone', model.backbone), ('cfm', model.backbone.cfm), ('decode_head', model.decode_head)]:
        total, trainable = count(module)
        print(f'{name}: trainable={trainable:,} / total={total:,}')


if __name__ == '__main__':
    main()
