import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmengine.runner import Runner


def parse_args():
    parser = argparse.ArgumentParser(
        description='Test Copernicus-FM on PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('checkpoint')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default=None,
        help='Use "none" for single-process test, "pytorch" for torchrun.')
    return parser.parse_args()


def _auto_fix_launcher(cfg, launcher_arg=None):
    if launcher_arg is not None:
        cfg.launcher = launcher_arg
        return
    launcher = cfg.get('launcher', 'none')
    if launcher == 'pytorch' and 'RANK' not in os.environ:
        print(
            '[tools/test.py] cfg.launcher="pytorch" but RANK is missing; '
            'falling back to launcher="none".')
        cfg.launcher = 'none'
    elif launcher is None:
        cfg.launcher = 'none'


def main():
    args = parse_args()
    cfg = Config.fromfile(args.config)
    _auto_fix_launcher(cfg, args.launcher)
    cfg.load_from = args.checkpoint
    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    runner = Runner.from_cfg(cfg)
    runner.test()


if __name__ == '__main__':
    main()
