import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import cfm_mmseg  # noqa: F401
from mmengine.config import Config
from mmengine.runner import Runner


def parse_args():
    parser = argparse.ArgumentParser(
        description='Train Copernicus-FM on PASTIS with MMSeg/MMEngine')
    parser.add_argument('config')
    parser.add_argument('--work-dir', default=None)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument(
        '--amp',
        action='store_true',
        help='Force AmpOptimWrapper when not already enabled in config')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default=None,
        help=(
            'Job launcher. Use "none" for normal single-process training. '
            'Use "pytorch" only when launching with torchrun/dist_train.sh.'))
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action='append',
        default=None,
        help='Override config options, e.g. --cfg-options data_root=/data/pastis batch_size=4')
    return parser.parse_args()


def _auto_fix_launcher(cfg, launcher_arg=None):
    """Avoid entering distributed init when launched by plain python.

    MMEngine requires RANK/WORLD_SIZE when launcher='pytorch'.  In the
    original package the configs hard-coded launcher='pytorch', so running
    `python tools/train.py xxx.py` failed with KeyError: RANK.  This helper
    makes single-process training safe while still supporting multi-GPU
    training via `torchrun ... --launcher pytorch`.
    """
    if launcher_arg is not None:
        cfg.launcher = launcher_arg
        return

    launcher = cfg.get('launcher', 'none')
    if launcher == 'pytorch' and 'RANK' not in os.environ:
        print(
            '[tools/train.py] cfg.launcher="pytorch" but environment variable '
            'RANK is missing. Falling back to launcher="none".\n'
            'For multi-GPU training, use: '
            'bash scripts/train_dist.sh CONFIG NUM_GPUS')
        cfg.launcher = 'none'
    elif launcher is None:
        cfg.launcher = 'none'


def main():
    args = parse_args()
    cfg = Config.fromfile(args.config)

    _auto_fix_launcher(cfg, args.launcher)

    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume:
        cfg.resume = True
    if args.amp:
        cfg.optim_wrapper.type = 'AmpOptimWrapper'
        cfg.optim_wrapper.setdefault('loss_scale', 'dynamic')
    if args.cfg_options:
        for opts in args.cfg_options:
            cfg.merge_from_dict(dict(opt.split('=', 1) for opt in opts))

    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
