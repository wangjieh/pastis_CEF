# CopernicusFM-PASTIS

基于 Copernicus Foundation Model 的 PASTIS 农作物语义分割微调项目。

## 项目结构

```
copernicusfm-pastis/
├── copernicusfm/              # Copernicus-FM 模型
│   ├── backbone.py            # 单时相 backbone
│   ├── backbone_temporal.py   # 时序 backbone（支持 mean/max 融合）
│   ├── dynamic_hypernetwork.py
│   ├── aurora/                # Fourier 位置编码
│   ├── flexivit/              # 动态 patch size
│   └── util/
├── mmseg_custom/              # MMSeg 自定义组件
│   ├── models/                # EncoderDecoderMeta（支持 meta_info）
│   ├── pipelines/             # PackPastisInputs（处理 [T,C,H,W]）
│   ├── decode_heads/          # LinearProbeHead
│   ├── hooks/                 # FreezeBackboneHook
│   └── data_preprocessor.py   # TemporalSegDataPreprocessor
├── datasets/
│   └── pastis_dataset.py      # PASTIS 数据集（支持多 fold）
├── configs/
│   ├── _base_/                # 基础配置
│   └── copernicusfm/          # 4 套实验配置
└── tools/
    ├── train.py               # 训练脚本
    ├── test.py                # 测试脚本
    └── quick_verify.py        # 快速验证脚本
```

## 环境配置

```bash
conda create -n mmenv python=3.8
conda activate mmenv
pip install torch==1.13.1 torchvision==0.14.1
pip install mmcv==2.1.0 mmsegmentation==1.2.2
pip install timm einops geopandas
```

## 数据准备

PASTIS 数据集目录结构：
```
F:\PythonProject\PASTIS_evel\
├── metadata_summary.json    # 元数据
├── NORM_S2_patch.json       # 归一化参数
├── DATA_S2_PT/              # 影像 .pt 文件
│   ├── S2_10000.pt          # [T, 13, 128, 128]
│   └── ...
└── label_pt/                # 标签 .pt 文件
    ├── TARGET_10000.pt      # [128, 128], 0-18 类别, -1 忽略
    └── ...
```

## 预训练权重

将 Copernicus-FM 预训练权重放在：
```
C:\Users\23948\Desktop\CEF2mmlab\weights\CopernicusFM_ViT_base_varlang_e100.pth
```

## 4 套实验配置

| 配置文件 | 解码头 | Backbone 策略 |
|---------|--------|--------------|
| `copernicusfm_base_linear_finetune.py` | Linear Probe | 前10轮冻结，之后全量微调 |
| `copernicusfm_base_linear_frozen.py` | Linear Probe | 始终冻结，只训练解码头 |
| `copernicusfm_base_upernet_finetune.py` | UPerNet | 前10轮冻结，之后全量微调 |
| `copernicusfm_base_upernet_frozen.py` | UPerNet | 始终冻结，只训练解码头 |

## 运行训练

```bash
cd C:\Users\23948\Desktop\CEF2mmlab\copernicusfm-pastis
set PYTHONPATH=%cd%
python tools/train.py configs/copernicusfm/copernicusfm_base_linear_finetune.py
```

## 快速验证

```bash
python tools/quick_verify.py
```

## 切换模型大小

在配置文件中修改 backbone：
```python
backbone=dict(
    model_size='large',  # 'small', 'base', 'large'
    pretrained='path/to/CopernicusFM_ViT_large_varlang_e100.pth',
    ...
)
```

## 训练策略

- **Fold 划分**: Fold 1+2+3 训练, Fold 4 验证, Fold 5 测试
- **时序处理**: 每个时间步独立提取特征，然后 mean/max 融合
- **损失函数**: CrossEntropyLoss (ignore_index=255)
- **优化器**: AdamW, lr=1e-4 (微调) / 1e-3 (冻结)
- **训练轮数**: 50 epochs
