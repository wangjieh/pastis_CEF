# PASTIS Dataset Config
dataset_type = 'PASTISSegDataset'
data_root = 'F:/PythonProject/PASTIS_evel'

train_pipeline = [
    dict(type='PackPastisInputs'),
]
val_pipeline = [
    dict(type='PackPastisInputs'),
]
test_pipeline = val_pipeline

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        fold=[1, 2, 3],
        num_timesteps=12,
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        fold=4,
        num_timesteps=12,
        pipeline=val_pipeline,
    ),
)

test_dataloader = val_dataloader

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU', 'mFscore'])
test_evaluator = val_evaluator
