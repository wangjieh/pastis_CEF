# CopernicusFM Temporal + Linear Probe Head
norm_cfg = dict(type='SyncBN', requires_grad=True)
data_preprocessor = dict(
    type='TemporalSegDataPreprocessor',
    size=(128, 128),
    test_cfg=dict(size_divisor=16),
)

model = dict(
    type='EncoderDecoderMeta',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='CopernicusFMTemporal',
        temporal_fusion='mean',
        model_size='base',
        band_wavelengths=[440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190],
        band_bandwidths=[20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180],
        input_mode='spectral',
        kernel_size=16,
        freeze_backbone=False,
        pretrained='C:/Users/23948/Desktop/CEF2mmlab/weights/CopernicusFM_ViT_base_varlang_e100.pth',
    ),
    decode_head=dict(
        type='LinearProbeHead',
        in_channels=768,
        channels=768,
        num_classes=19,
        target_size=(128, 128),
        norm_cfg=norm_cfg,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    auxiliary_head=None,
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)
