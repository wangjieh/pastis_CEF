# CopernicusFM Temporal + UPerNet Head
norm_cfg = dict(type='SyncBN', requires_grad=True)
data_preprocessor = dict(
    type='TemporalSegDataPreprocessor',
    size=(128, 128),
    test_cfg=dict(size_divisor=16),
)

model = dict(
    type='EncoderDecoderMeta',
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type='CopernicusFMTemporal',
        temporal_fusion='mean',
        model_size='base',
        band_wavelengths=[440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190],
        band_bandwidths=[20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180],
        input_mode='spectral',
        kernel_size=16,
        freeze_backbone=False,
        pretrained='C:/Users/23948/Desktop/CEF2mmlab/weights/CopernicusFM_ViT_base_varlang_e100.pth',
    ),
    neck=dict(
        type='Feature2Pyramid',
        embed_dim=768,
        rescales=[4, 2, 1, 0.5],
    ),
    decode_head=dict(
        type='UPerHead',
        in_channels=[768, 768, 768, 768],
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=19,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=768,
        in_index=2,
        channels=256,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=19,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)
