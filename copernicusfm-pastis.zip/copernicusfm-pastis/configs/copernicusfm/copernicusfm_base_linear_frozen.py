"""
Config 2: Copernicus-base + Linear Probe
Only train decoder (backbone always frozen).
"""
_base_ = [
    '../_base_/models/copernicusfm_temporal_linear.py',
    '../_base_/datasets/pastis.py',
    '../_base_/schedules/schedule_50e.py',
]

custom_imports = dict(
    imports=['mmseg_custom'],
    allow_failed_imports=False,
)

# Freeze backbone permanently
model = dict(
    backbone=dict(freeze_backbone=True),
)

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-3, weight_decay=0.01),
)

log_config = dict(interval=50, hooks=[dict(type='TextLoggerHook')])
