"""
Config 3: Copernicus-base + UPerNet
Freeze backbone for first 10 epochs, then full fine-tuning.
"""
_base_ = [
    '../_base_/models/copernicusfm_temporal_upernet.py',
    '../_base_/datasets/pastis.py',
    '../_base_/schedules/schedule_50e.py',
]

custom_imports = dict(
    imports=['mmseg_custom'],
    allow_failed_imports=False,
)

custom_hooks = [
    dict(type='FreezeBackboneHook', freeze_epochs=10),
]

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.01),
)

log_config = dict(interval=50, hooks=[dict(type='TextLoggerHook')])
