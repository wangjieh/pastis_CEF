# ============================================================
# CopernicusFM-base + UPerNet | 前10轮冻结，之后全量微调
# ============================================================

custom_imports = dict(imports=['mmseg_custom'], allow_failed_imports=False)

# ---- 数据 ----
dataset_type = 'PASTISSegDataset'
data_root = 'F:/PythonProject/PASTIS_evel'
train_pipeline = [dict(type='PackPastisInputs')]
val_pipeline = [dict(type='PackPastisInputs')]

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='InfiniteSampler', shuffle=True),
    dataset=dict(type=dataset_type, data_root=data_root,
                 fold=[1, 2, 3], num_timesteps=12, kernel_size=16, pipeline=train_pipeline),  # kernel_size与backbone保持一致
)
val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(type=dataset_type, data_root=data_root,
                 fold=4, num_timesteps=12, kernel_size=16, pipeline=val_pipeline),  # kernel_size与backbone保持一致
)
test_dataloader = val_dataloader

val_evaluator = dict(type='IoUMetric', iou_metrics=['mIoU', 'mFscore'])
test_evaluator = val_evaluator

# ---- 模型 ----
norm_cfg = dict(type='SyncBN', requires_grad=True)
model = dict(
    type='EncoderDecoderMeta',
    data_preprocessor=dict(type='TemporalSegDataPreprocessor', size=(128, 128)),
    backbone=dict(
        type='CopernicusFMTemporal',
        temporal_fusion='mean',
        model_size='base',
        patch_size=16,    # 预训练权重固定为16，不要改
        kernel_size=16,   # 可改（4, 8, 16），运行时动态调整卷积核
        band_wavelengths=[440, 490, 560, 665, 705, 740, 783, 842, 860, 940, 1370, 1610, 2190],
        band_bandwidths=[20, 65, 35, 30, 15, 15, 20, 115, 20, 20, 30, 90, 180],
        input_mode='spectral',
        freeze_backbone=False,
        pretrained='C:/Users/23948/Desktop/CEF2mmlab/weights/CopernicusFM_ViT_base_varlang_e100.pth',
    ),
    neck=dict(type='Feature2Pyramid', embed_dim=768, rescales=[4, 2, 1, 0.5]),
    decode_head=dict(
        type='UPerHead',
        in_channels=[768, 768, 768, 768], in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6), channels=512, dropout_ratio=0.1,
        num_classes=19, norm_cfg=norm_cfg, align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=768, in_index=2, channels=256,
        num_convs=1, concat_input=False, dropout_ratio=0.1,
        num_classes=19, norm_cfg=norm_cfg, align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=0.4),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)

# ---- 训练策略 ----
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.05),
    clip_grad=dict(max_norm=1.0, norm_type=2),
    paramwise_cfg=dict(
        custom_keys={
            'backbone': dict(lr_mult=0.1),
        }
    ),
)
param_scheduler = [
    dict(type='LinearLR', start_factor=1e-6, by_epoch=False, begin=0, end=500),
    dict(type='CosineAnnealingLR', T_max=50, eta_min=1e-6, by_epoch=True, begin=0, end=50),
]

custom_hooks = [dict(type='FreezeBackboneHook', freeze_epochs=10)]
default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(type='CheckpointHook', interval=10, save_best='mIoU', rule='greater'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
)

# ---- 多卡 & 环境 ----
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'),
)

randomness = dict(seed=42, deterministic=False, diff_rank_seed=True)
log_level = 'INFO'
log_processor = dict(type='LogProcessor', window_size=50, by_epoch=True)
