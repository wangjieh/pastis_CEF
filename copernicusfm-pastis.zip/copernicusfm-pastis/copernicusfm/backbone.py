"""
CopernicusFM Backbone for MMSegmentation.

Wraps the Copernicus-FM ViT encoder as a standard MMSeg backbone that returns
multi-scale feature maps. Internalizes sensor configuration (wavelengths,
bandwidths, input mode, etc.) so that forward() only needs (img, meta_info).

Based on:
    https://github.com/zhu-xlab/Copernicus-FM
"""

import math
from functools import partial

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmengine.registry import MODELS as MMENGINE_MODELS
from mmseg.registry import MODELS
from timm.models.vision_transformer import Block

from .dynamic_hypernetwork import Dynamic_MLP_OFA_spectral, Dynamic_MLP_OFA_variable
from .aurora.fourier import FourierExpansion
from .flexivit.utils import resize_abs_pos_embed


class CopernicusFMViT(BaseModule):
    """Copernicus-FM ViT encoder that outputs multi-scale feature maps.

    This is the segmentation variant of the Copernicus-FM encoder. Unlike the
    classification variant which returns a single global feature, this version
    extracts features from multiple transformer blocks and returns them as 2D
    feature maps suitable for dense prediction heads (UPerHead, FCNHead, etc.).

    Args:
        img_size (int): Input image size. Default: 224.
        patch_size (int): Patch size for the ViT. Default: 16.
        embed_dim (int): Transformer embedding dimension. Default: 768.
        depth (int): Number of transformer blocks. Default: 12.
        num_heads (int): Number of attention heads. Default: 12.
        mlp_ratio (float): MLP expansion ratio. Default: 4.0.
        wv_planes (int): Dimension of wavelength/bandwidth embeddings. Default: 128.
        out_indices (list[int]): Indices of blocks from which to extract features.
            Default: [3, 5, 7, 11].
        drop_rate (float): Dropout rate. Default: 0.0.
        drop_path_rate (float): Drop path rate. Default: 0.0.
        norm_layer: Normalization layer. Default: nn.LayerNorm.
        var_option (str): Variable embedding option, 'language' or 'spectrum'.
            Default: 'language'.
        loc_option (str): Location encoding option, 'lonlat' or 'cartesian'.
            Default: 'lonlat'.
        init_cfg (dict or list[dict], optional): Initialization config.
    """

    def __init__(
        self,
        img_size=224,
        patch_size=16,
        embed_dim=768,
        depth=12,
        num_heads=12,
        mlp_ratio=4.0,
        wv_planes=128,
        out_indices=[3, 5, 7, 11],
        drop_rate=0.0,
        drop_path_rate=0.0,
        norm_layer=nn.LayerNorm,
        var_option='language',
        loc_option='lonlat',
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)
        self.wv_planes = wv_planes
        self.embed_dim = embed_dim
        self.out_indices = out_indices
        self.img_size = img_size

        # ---- Patch Embedding (dynamic, sensor-aware) ----
        self.input_mode = None  # set later by CopernicusFM wrapper
        self.patch_embed_spectral = Dynamic_MLP_OFA_spectral(
            wv_planes=128, inter_dim=128, kernel_size=patch_size, embed_dim=embed_dim
        )
        # Defer variable patch embed creation to avoid auto-downloading
        # language embeddings when only spectral mode is needed.
        # Will be created lazily on first use or in CopernicusFM wrapper.
        self._var_option = var_option
        self._patch_size = patch_size
        self.patch_embed_variable = None

        self.num_patches = (img_size // patch_size) ** 2

        # ---- CLS token & positional embedding ----
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(
            torch.zeros(1, self.num_patches + 1, embed_dim), requires_grad=False
        )

        # ---- Geo / Time positional encoding (Fourier-based) ----
        self.loc_option = loc_option
        if loc_option == 'cartesian':
            self.coord_expansion = FourierExpansion(1e-7, 2)
        elif loc_option == 'lonlat':
            self.coord_expansion = FourierExpansion(0.0001, 720)

        self.scale_expansion = FourierExpansion(0.001, 5.1e8)
        self.time_expansion = FourierExpansion(1, 365.25, assert_range=False)
        self.coord_fc = nn.Linear(embed_dim, embed_dim)
        self.scale_fc = nn.Linear(embed_dim, embed_dim)
        self.time_fc = nn.Linear(embed_dim, embed_dim)

        # Learned fallback tokens when meta info is NaN
        self.coord_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.scale_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.time_token = nn.Parameter(torch.zeros(1, 1, embed_dim))

        # ---- Transformer blocks ----
        self.blocks = nn.ModuleList([
            Block(
                embed_dim, num_heads, mlp_ratio,
                qkv_bias=True, norm_layer=norm_layer,
            )
            for _ in range(depth)
        ])

    def get_coord_pos_embed(self, lons, lats, embed_dim):
        if self.loc_option == 'cartesian':
            spherical_x = torch.cos(lons * math.pi / 180) * torch.cos(lats * math.pi / 180) + 1 + 1e-7
            spherical_y = torch.sin(lons * math.pi / 180) * torch.cos(lats * math.pi / 180) + 1 + 1e-7
            spherical_z = torch.sin(lats * math.pi / 180) + 1 + 1e-7
            coord_embed = torch.cat([
                self.coord_expansion(spherical_x, embed_dim // 3),
                self.coord_expansion(spherical_y, embed_dim // 3),
                self.coord_expansion(spherical_z, embed_dim // 3),
            ], dim=-1)
        elif self.loc_option == 'lonlat':
            coord_embed_lon = self.coord_expansion(lons + 180, embed_dim // 2)
            coord_embed_lat = self.coord_expansion(lats + 90, embed_dim // 2)
            coord_embed = torch.cat([coord_embed_lon, coord_embed_lat], dim=-1)

        if coord_embed.shape[-1] < embed_dim:
            coord_embed = torch.cat((
                coord_embed,
                torch.zeros(coord_embed.shape[0], embed_dim - coord_embed.shape[-1],
                            device=coord_embed.device)
            ), dim=-1)
        return coord_embed.unsqueeze(1)  # [B, 1, D]

    def get_area_pos_embed(self, areas, embed_dim):
        return self.scale_expansion(areas, embed_dim).unsqueeze(1)

    def get_time_pos_embed(self, times, embed_dim):
        return self.time_expansion(times, embed_dim).unsqueeze(1)

    def forward(self, x, meta_info, wave_list, bandwidth, language_embed,
                input_mode, kernel_size=None):
        """Forward pass.

        Args:
            x (Tensor): Input images [B, C, H, W].
            meta_info (Tensor): Meta information [B, 4] with
                (lon, lat, time, area). Use NaN for unknown fields.
            wave_list (list[float]): Band center wavelengths in nm.
            bandwidth (list[float]): Band bandwidths in nm.
            language_embed (Tensor or None): Language embedding for variable mode.
            input_mode (str): 'spectral' or 'variable'.
            kernel_size (int, optional): Override patch size. Default: None.

        Returns:
            tuple[Tensor]: Multi-scale feature maps, each [B, embed_dim, H', W'].
        """
        wavelist = torch.tensor(wave_list, device=x.device).float()
        bandwidths = torch.tensor(bandwidth, device=x.device).float()

        # Patch embedding
        if input_mode == 'spectral':
            x, _ = self.patch_embed_spectral(x, wavelist, bandwidths, kernel_size)
        elif input_mode == 'variable':
            # Lazy initialization of variable patch embed
            if self.patch_embed_variable is None:
                self.patch_embed_variable = Dynamic_MLP_OFA_variable(
                    wv_planes=128, inter_dim=128,
                    kernel_size=self._patch_size,
                    embed_dim=self.embed_dim,
                    option=self._var_option
                ).to(x.device)
            x, waves = self.patch_embed_variable(
                None, x, wavelist, bandwidths, language_embed, kernel_size
            )

        # Resize positional embedding to match actual patch count
        num_patches = x.size(1)
        num_patches_sqrt = int(math.sqrt(num_patches))
        num_patches_sqrt_origin = int(math.sqrt(self.num_patches))
        pos_embed = resize_abs_pos_embed(
            self.pos_embed, num_patches_sqrt,
            (num_patches_sqrt_origin, num_patches_sqrt_origin),
            num_prefix_tokens=1
        )

        # Geo / time positional encoding from meta_info
        lons, lats, times, areas = (
            meta_info[:, 0], meta_info[:, 1],
            meta_info[:, 2], meta_info[:, 3]
        )
        embed_dim = pos_embed.shape[-1]

        if torch.isnan(lons).any() or torch.isnan(lats).any():
            coord_embed = self.coord_token
        else:
            coord_embed = self.get_coord_pos_embed(lons, lats, embed_dim)
        coord_embed = self.coord_fc(coord_embed)

        if torch.isnan(areas).any():
            area_embed = self.scale_token
        else:
            area_embed = self.get_area_pos_embed(areas, embed_dim)
        area_embed = self.scale_fc(area_embed)

        if torch.isnan(times).any():
            time_embed = self.time_token
        else:
            time_embed = self.get_time_pos_embed(times, embed_dim)
        time_embed = self.time_fc(time_embed)

        pos_embed = pos_embed + coord_embed + area_embed + time_embed

        # Add positional embedding (excluding cls token position)
        x = x + pos_embed[:, 1:, :]

        # Prepend cls token
        cls_token = self.cls_token + pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        # Apply transformer blocks, collect multi-scale features
        hw = num_patches_sqrt
        hw_shape = (hw, hw)
        out_features = []

        for i, blk in enumerate(self.blocks):
            x = blk(x)
            if i in self.out_indices:
                out = x[:, 1:]  # remove cls token
                B, _, C = out.shape
                out = (
                    out.reshape(B, hw_shape[0], hw_shape[1], C)
                    .permute(0, 3, 1, 2)
                    .contiguous()
                )
                out_features.append(out)

        return tuple(out_features)


# ---- MMSeg registered backbone ----

@MODELS.register_module()
@MMENGINE_MODELS.register_module()
class CopernicusFM(BaseModule):
    """Copernicus-FM backbone for MMSegmentation.

    This wrapper loads pretrained Copernicus-FM weights and provides a standard
    MMSeg backbone interface. Sensor-specific parameters (wavelengths, bandwidths,
    etc.) are configured at init time and applied automatically during forward.

    Args:
        model_size (str): Model size, one of 'small', 'base', 'large'.
            Default: 'base'.
        embed_dim (int): Transformer embedding dimension. Default: 768.
        depth (int): Number of transformer blocks. Default: 12.
        num_heads (int): Number of attention heads. Default: 12.
        mlp_ratio (float): MLP expansion ratio. Default: 4.0.
        patch_size (int): Patch size. Default: 16.
        img_size (int): Expected input image size. Default: 224.
        out_indices (list[int]): Block indices for multi-scale feature extraction.
            Default: [3, 5, 7, 11].
        band_wavelengths (list[float]): Center wavelengths (nm) for each band.
        band_bandwidths (list[float]): Bandwidths (nm) for each band.
        input_mode (str): 'spectral' or 'variable'. Default: 'spectral'.
        kernel_size (int): Patch size for dynamic embedding. Default: 16.
        key (str or None): Sensor key for variable mode. Default: None.
        language_embed_path (str or None): Path to language embedding .pt file.
            Required when input_mode='variable'. Default: None.
        language_embed_key (str or None): Key in the language embedding dict.
            Default: None.
        loc_option (str): Location encoding, 'lonlat' or 'cartesian'.
            Default: 'lonlat'.
        var_option (str): Variable embedding, 'language' or 'spectrum'.
            Default: 'language'.
        freeze_backbone (bool): Whether to freeze backbone parameters.
            Default: False.
        pretrained (str or None): Path to pretrained weights. Default: None.
        init_cfg (dict or list[dict], optional): Initialization config.
    """

    # Predefined model sizes
    SIZE_CONFIGS = {
        'small':  dict(embed_dim=384, depth=12, num_heads=6,  out_indices=[3, 5, 7, 11]),
        'base':   dict(embed_dim=768, depth=12, num_heads=12, out_indices=[3, 5, 7, 11]),
        'large':  dict(embed_dim=1024, depth=24, num_heads=16, out_indices=[7, 11, 15, 23]),
    }

    def __init__(
        self,
        model_size='base',
        embed_dim=768,
        depth=12,
        num_heads=12,
        mlp_ratio=4.0,
        patch_size=16,
        img_size=224,
        out_indices=[3, 5, 7, 11],
        # Sensor config
        band_wavelengths=None,
        band_bandwidths=None,
        input_mode='spectral',
        kernel_size=16,
        key=None,
        language_embed_path=None,
        language_embed_key=None,
        # Encoding options
        loc_option='lonlat',
        var_option='language',
        # Training
        freeze_backbone=False,
        pretrained=None,
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)

        # Apply size presets if available
        if model_size in self.SIZE_CONFIGS:
            cfg = self.SIZE_CONFIGS[model_size]
            embed_dim = cfg['embed_dim']
            depth = cfg['depth']
            num_heads = cfg['num_heads']
            out_indices = cfg['out_indices']

        self.embed_dim = embed_dim
        self.freeze_backbone = freeze_backbone
        self.pretrained = pretrained

        # Store sensor config as forward-time constants
        self.band_wavelengths = band_wavelengths
        self.band_bandwidths = band_bandwidths
        self.input_mode = input_mode
        self.kernel_size = kernel_size
        self.key = key

        # Build the core encoder
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        self.encoder = CopernicusFMViT(
            img_size=img_size,
            patch_size=patch_size,
            embed_dim=embed_dim,
            depth=depth,
            num_heads=num_heads,
            mlp_ratio=mlp_ratio,
            out_indices=out_indices,
            norm_layer=norm_layer,
            var_option=var_option,
            loc_option=loc_option,
        )

        # Load language embedding for variable mode
        self.language_embed = None
        if input_mode == 'variable' and language_embed_path is not None:
            embed_data = torch.load(language_embed_path, map_location='cpu')
            if language_embed_key is not None:
                self.language_embed = embed_data[language_embed_key]

        # Load pretrained weights
        if pretrained is not None:
            self._load_pretrained(pretrained)

        # Freeze if requested
        if freeze_backbone:
            self._freeze_backbone()

    def _load_pretrained(self, path):
        """Load pretrained Copernicus-FM weights."""
        checkpoint = torch.load(path, map_location='cpu')
        state_dict = checkpoint.get('model', checkpoint)
        msg = self.encoder.load_state_dict(state_dict, strict=False)
        print(f'[CopernicusFM] Loaded pretrained weights from {path}')
        print(f'  missing_keys: {msg.missing_keys}')
        print(f'  unexpected_keys: {msg.unexpected_keys}')

    def _freeze_backbone(self):
        """Freeze all backbone parameters."""
        for param in self.encoder.parameters():
            param.requires_grad = False
        print('[CopernicusFM] Backbone frozen.')

    def forward(self, x, meta_info=None):
        """Forward pass.

        Args:
            x (Tensor): Input images [B, C, H, W].
            meta_info (Tensor, optional): Meta information [B, 4] with
                (lon, lat, time, area). If None, NaN is used (learned tokens
                will be applied). Default: None.

        Returns:
            tuple[Tensor]: Multi-scale feature maps from selected blocks.
                For base model with out_indices=[3,5,7,11], returns 4 tensors
                each of shape [B, 768, H/16, W/16].
        """
        if meta_info is None:
            meta_info = torch.full(
                (x.shape[0], 4), float('nan'),
                device=x.device, dtype=x.dtype
            )

        # Handle language_embed device
        lang_embed = self.language_embed
        if lang_embed is not None:
            lang_embed = lang_embed.to(x.device)

        feats = self.encoder(
            x, meta_info,
            self.band_wavelengths, self.band_bandwidths,
            lang_embed, self.input_mode, self.kernel_size
        )
        return feats
