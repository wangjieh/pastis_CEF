"""
CopernicusFM Temporal Backbone for MMSegmentation.

Wraps the single-frame CopernicusFM backbone to handle time series input.
Each time step is processed independently, then multi-scale features are
fused across time using max or mean pooling.

Input:  [B, T, C, H, W]  (time series)
Output: tuple[Tensor]     (fused multi-scale feature maps)
"""

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmengine.registry import MODELS as MMENGINE_MODELS
from mmseg.registry import MODELS

from .backbone import CopernicusFM


@MODELS.register_module()
@MMENGINE_MODELS.register_module()
class CopernicusFMTemporal(BaseModule):
    """Copernicus-FM backbone with temporal fusion for time series segmentation.

    Processes each time step independently through a shared CopernicusFM encoder,
    then fuses the multi-scale features across the temporal dimension.

    Args:
        temporal_fusion (str): Temporal fusion strategy, 'max' or 'mean'.
            Default: 'mean'.
        All other args are passed to CopernicusFM backbone.
    """

    def __init__(
        self,
        temporal_fusion='mean',
        # ---- CopernicusFM args (forwarded) ----
        model_size='base',
        embed_dim=768,
        depth=12,
        num_heads=12,
        mlp_ratio=4.0,
        patch_size=16,
        img_size=224,
        out_indices=[3, 5, 7, 11],
        band_wavelengths=None,
        band_bandwidths=None,
        input_mode='spectral',
        kernel_size=16,
        key=None,
        language_embed_path=None,
        language_embed_key=None,
        loc_option='lonlat',
        var_option='language',
        freeze_backbone=False,
        pretrained=None,
        init_cfg=None,
    ):
        super().__init__(init_cfg=init_cfg)

        assert temporal_fusion in ('max', 'mean'), \
            f"temporal_fusion must be 'max' or 'mean', got '{temporal_fusion}'"
        self.temporal_fusion = temporal_fusion

        # Build the single-frame backbone
        self.backbone = CopernicusFM(
            model_size=model_size,
            embed_dim=embed_dim,
            depth=depth,
            num_heads=num_heads,
            mlp_ratio=mlp_ratio,
            patch_size=patch_size,
            img_size=img_size,
            out_indices=out_indices,
            band_wavelengths=band_wavelengths,
            band_bandwidths=band_bandwidths,
            input_mode=input_mode,
            kernel_size=kernel_size,
            key=key,
            language_embed_path=language_embed_path,
            language_embed_key=language_embed_key,
            loc_option=loc_option,
            var_option=var_option,
            freeze_backbone=freeze_backbone,
            pretrained=pretrained,
        )

    def forward(self, x, meta_info=None):
        """Forward pass with temporal fusion.

        Args:
            x (Tensor): Time series input [B, T, C, H, W].
            meta_info (Tensor, optional): Meta information [B, 4] or [B, T, 4].
                If [B, 4], the same meta_info is shared across all time steps.
                If [B, T, 4], each time step has its own meta_info.
                If None, NaN is used. Default: None.

        Returns:
            tuple[Tensor]: Fused multi-scale feature maps.
        """
        B, T, C, H, W = x.shape

        # Process each time step independently
        all_feats = []  # list of tuples, one per time step
        for t in range(T):
            xt = x[:, t]  # [B, C, H, W]

            # Handle meta_info per time step
            if meta_info is not None:
                if meta_info.dim() == 3:
                    # [B, T, 4] -> [B, 4] for this time step
                    mt = meta_info[:, t]
                else:
                    # [B, 4] shared across all time steps
                    mt = meta_info
            else:
                mt = None

            feats_t = self.backbone(xt, mt)  # tuple of [B, D, h, w]
            all_feats.append(feats_t)

        # Fuse across time: all_feats[i] is a tuple of T feature maps at scale i
        num_scales = len(all_feats[0])
        fused = []
        for s in range(num_scales):
            # Stack across time: [B, T, D, h, w]
            scale_feats = torch.stack([all_feats[t][s] for t in range(T)], dim=1)
            if self.temporal_fusion == 'max':
                fused.append(scale_feats.max(dim=1).values)  # [B, D, h, w]
            else:
                fused.append(scale_feats.mean(dim=1))  # [B, D, h, w]

        return tuple(fused)
