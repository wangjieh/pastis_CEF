"""
PASTIS Dataset for MMSegmentation with CopernicusFM.

Loads preprocessed PASTIS .pt files for semantic segmentation.

Data layout:
    DATA_S2_PT/S2_{id}.pt   -> [T, 13, 128, 128] float32
    label_pt/S2_{id}.pt     -> [128, 128] int8, 0-18 = classes, -1 = ignore
    metadata_summary.json   -> list of {ID_PATCH, Fold, lat, lon, avg_dates_S2}
    NORM_S2_patch.json      -> per-fold mean/std (10 original S2 bands)
"""

import json
import os
import tempfile
from datetime import datetime

import numpy as np
import torch
from mmseg.registry import DATASETS
from mmseg.datasets import BaseSegDataset


@DATASETS.register_module()
class PASTISSegDataset(BaseSegDataset):
    """PASTIS semantic segmentation dataset.

    Args:
        data_root (str): Root path containing DATA_S2_PT/, label_pt/, etc.
        fold (int): Fold number for train/val/test split. Use folds=[1,2,3]
            for training, [4] for validation, [5] for testing.
        num_timesteps (int): Number of time steps to use. Default: 12.
        reference_date (str): Reference date for day-of-year calculation.
            Default: '2018-09-01'.
        **kwargs: Additional args for BaseSegDataset.
    """

    METAINFO = dict(
        classes=(
            'Background', 'Meadow', 'Soft winter wheat', 'Corn',
            'Winter barley', 'Winter rapeseed', 'Spring barley',
            'Sunflower', 'Grapevine', 'Beet',
            'Winter triticale', 'Winter durum wheat',
            'Fruits vegetables flowers', 'Potatoes',
            'Leguminous fodder', 'Soybeans',
            'Orchard', 'Mixed cereal', 'Bare soil',
        ),
        palette=[
            [0, 0, 0], [255, 255, 0], [0, 191, 255], [255, 62, 0],
            [0, 255, 127], [255, 127, 0], [0, 0, 255], [255, 0, 127],
            [255, 255, 127], [0, 127, 255], [127, 0, 255], [255, 0, 0],
            [0, 255, 255], [127, 255, 0], [255, 0, 255], [191, 127, 255],
            [127, 63, 0], [255, 127, 255], [200, 200, 200],
        ],
    )

    def __init__(
        self,
        data_root='',
        fold=1,
        num_timesteps=12,
        reference_date='2018-09-01',
        **kwargs,
    ):
        self.num_timesteps = num_timesteps
        self.reference_date = datetime(*map(int, reference_date.split('-')))

        # Support single fold (int) or multiple folds (list)
        if isinstance(fold, int):
            self.folds = [fold]
        else:
            self.folds = list(fold)

        # Load metadata
        meta_path = os.path.join(data_root, 'metadata_summary.json')
        with open(meta_path, 'r') as f:
            self.meta_all = json.load(f)

        # Filter by folds
        self.meta_fold = [m for m in self.meta_all if m['Fold'] in self.folds]

        # Load normalization stats (10 original S2 bands)
        # Average across selected folds
        norm_path = os.path.join(data_root, 'NORM_S2_patch.json')
        with open(norm_path, 'r') as f:
            norm_data = json.load(f)
        means_list = [norm_data[f'Fold_{f}']['mean'] for f in self.folds]
        stds_list = [norm_data[f'Fold_{f}']['std'] for f in self.folds]
        mean_10 = np.stack(means_list).mean(axis=0).astype(np.float32)  # [10]
        std_10 = np.stack(stds_list).mean(axis=0).astype(np.float32)    # [10]

        # Expand from 10 to 13 bands:
        # Original: B02,B03,B04,B05,B06,B07,B08,B8A,B11,B12 (indices 0-9)
        # Expanded: B01,B02,B03,B04,B05,B06,B07,B08,B8A,B09,B10,B11,B12
        #   B01 <- B02 (idx 0), B09 <- B8A (idx 7), B10 <- B11 (idx 8)
        self.norm_mean = np.array([
            mean_10[0], mean_10[0], mean_10[1], mean_10[2],
            mean_10[3], mean_10[4], mean_10[5], mean_10[6],
            mean_10[7], mean_10[7], mean_10[8], mean_10[8],
            mean_10[9],
        ], dtype=np.float32)  # [13]

        self.norm_std = np.array([
            std_10[0], std_10[0], std_10[1], std_10[2],
            std_10[3], std_10[4], std_10[5], std_10[6],
            std_10[7], std_10[7], std_10[8], std_10[8],
            std_10[9],
        ], dtype=np.float32)  # [13]

        # Paths
        self.img_dir = os.path.join(data_root, 'DATA_S2_PT')
        self.seg_dir = os.path.join(data_root, 'label_pt')

        # Generate a temporary annotation file listing valid samples
        # BaseSegDataset reads ann_file to build data_list
        valid_ids = []
        for m in self.meta_fold:
            pid = m['ID_PATCH']
            img_path = os.path.join(self.img_dir, f'S2_{pid}.pt')
            seg_path = os.path.join(self.seg_dir, f'TARGET_{pid}.pt')
            if os.path.exists(img_path) and os.path.exists(seg_path):
                valid_ids.append(str(pid))

        tmp_ann = tempfile.NamedTemporaryFile(
            mode='w', suffix='.txt', delete=False, dir=data_root
        )
        for pid in valid_ids:
            tmp_ann.write(f'S2_{pid}\n')
        tmp_ann.close()
        self._tmp_ann_file = tmp_ann.name

        super().__init__(
            ann_file=self._tmp_ann_file,
            metainfo=self.METAINFO,
            data_root=data_root,
            img_suffix='.pt',
            seg_map_suffix='.pt',
            **kwargs,
        )

        # Override data_list with our custom entries (including meta_info)
        self.data_list = self._build_data_list()

    def _build_data_list(self):
        """Build data list from PASTIS metadata with custom fields."""
        data_list = []
        for m in self.meta_fold:
            pid = m['ID_PATCH']
            img_path = os.path.join(self.img_dir, f'S2_{pid}.pt')
            seg_path = os.path.join(self.seg_dir, f'TARGET_{pid}.pt')
            if not os.path.exists(img_path) or not os.path.exists(seg_path):
                continue

            # Compute day-of-year for each time step from avg_dates_S2
            dates = m.get('avg_dates_S2', [])
            doys = []
            for d in dates[:self.num_timesteps]:
                dt = datetime(int(str(d)[:4]), int(str(d)[4:6]), int(str(d)[6:]))
                doys.append((dt - self.reference_date).days)

            data_list.append(dict(
                img_path=img_path,
                seg_map_path=seg_path,
                patch_id=pid,
                lat=m['lat'],
                lon=m['lon'],
                doys=doys,
                seg_fields=['gt_sem_seg'],
                label_map=None,
                reduce_zero_label=False,
            ))
        return data_list

    def prepare_data(self, idx):
        """Load and return a single sample."""
        info = self.data_list[idx]

        # Load image [T, 13, 128, 128]
        img = torch.load(info['img_path']).float().numpy()
        # Take first num_timesteps
        img = img[:self.num_timesteps]  # [T, 13, 128, 128]

        # Normalize per-channel
        for c in range(13):
            img[:, c] = (img[:, c] - self.norm_mean[c]) / (self.norm_std[c] + 1e-6)

        # Load label [128, 128]
        seg = torch.load(info['seg_map_path']).numpy().astype(np.int64)
        # Convert -1 (ignore) to 255 (mmseg's default ignore_index)
        seg[seg == -1] = 255

        # Build meta_info: [lon, lat, day_of_year, area_km2]
        # area = 10m * 10m * 128 * 128 = 1,638,400 m^2 = 1.6384 km^2
        area_km2 = 1.6384
        # Use middle time step's day-of-year
        doys = info['doys']
        mid_doy = doys[len(doys) // 2] if doys else 0

        meta_info = np.array(
            [info['lon'], info['lat'], mid_doy, area_km2],
            dtype=np.float32,
        )

        results = dict(
            img=img,              # [T, 13, 128, 128]
            gt_sem_seg=seg,       # [128, 128]
            seg_fields=['gt_sem_seg'],
            img_path=info['img_path'],
            seg_map_path=info['seg_map_path'],
            meta_info=meta_info,  # [4]
        )

        results = self.pipeline(results)
        return results
