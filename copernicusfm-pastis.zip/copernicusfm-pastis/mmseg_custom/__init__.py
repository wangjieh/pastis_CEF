from .pipelines import *
from .hooks import *
from .decode_heads import *
from .models import *
from .data_preprocessor import *

# Import copernicusfm backbone to trigger MODELS registration
from copernicusfm.backbone import CopernicusFM
from copernicusfm.backbone_temporal import CopernicusFMTemporal

# Import datasets to trigger DATASETS registration
from datasets.pastis_dataset import PASTISSegDataset

# Sync ALL mmseg registries into mmengine registries
# This ensures mmengine can find mmseg-registered classes (losses, heads, etc.)
import mmseg.models  # noqa - trigger registration of all mmseg models
import mmseg.evaluation  # noqa - trigger registration of metrics (IoUMetric etc.)

import mmengine.registry as _mm_reg
import mmseg.registry as _mmseg_reg


def _sync_registry(src, dst):
    """Copy all entries from src registry into dst registry."""
    for name, cls in src.module_dict.items():
        if name not in dst.module_dict:
            dst._module_dict[name] = cls


# Sync all known registries
for reg_name in ['MODELS', 'DATASETS', 'TRANSFORMS', 'HOOKS',
                  'VISUALIZERS', 'LOG_PROCESSORS', 'METRICS',
                  'LOOPS', 'RUNNERS', 'OPTIM_WRAPPERS',
                  'PARAM_SCHEDULERS', 'EVALUATORS']:
    src = getattr(_mmseg_reg, reg_name, None)
    dst = getattr(_mm_reg, reg_name, None)
    if src is not None and dst is not None:
        _sync_registry(src, dst)
