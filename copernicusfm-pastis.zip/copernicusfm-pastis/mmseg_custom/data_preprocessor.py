"""
Temporal data preprocessor for PASTIS + CopernicusFM.

Handles [B, T, C, H, W] inputs without re-normalization
(normalization is done in the dataset).
"""

import torch
from mmengine.registry import MODELS as MMENGINE_MODELS
from mmseg.registry import MODELS
from mmseg.models.data_preprocessor import SegDataPreProcessor


@MODELS.register_module()
@MMENGINE_MODELS.register_module()
class TemporalSegDataPreprocessor(SegDataPreProcessor):
    """Data preprocessor for temporal segmentation data.

    Extends SegDataPreprocessor to handle [B, T, C, H, W] inputs.
    Normalization is expected to be done in the dataset, so this
    preprocessor only handles device transfer and label padding.

    Args:
        batch_augments (list[dict], optional): Batch-level augmentations.
        **kwargs: Additional args for SegDataPreprocessor.
    """

    def __init__(self, **kwargs):
        # Force no normalization in preprocessor (done in dataset)
        kwargs.setdefault('mean', None)
        kwargs.setdefault('std', None)
        super().__init__(**kwargs)

    def forward(self, data, training=False):
        """Process temporal data.

        Args:
            data (dict): Contains 'inputs' [B, T, C, H, W] and
                'data_samples' list of SegDataSample.
            training (bool): Whether in training mode.

        Returns:
            tuple: (inputs, data_samples) on the correct device.
        """
        inputs = data['inputs']
        data_samples = data.get('data_samples', None)

        # Move inputs to device (no normalization, already done in dataset)
        if isinstance(inputs, torch.Tensor):
            inputs = inputs.to(self.device, non_blocking=True)

        # Handle data samples (move gt_sem_seg to device)
        if data_samples is not None:
            data_samples = self.cast_data(data_samples)

        return inputs, data_samples
