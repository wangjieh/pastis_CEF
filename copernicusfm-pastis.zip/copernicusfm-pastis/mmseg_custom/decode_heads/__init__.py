from .linear_head import LinearProbeHead

__all__ = ['LinearProbeHead']
