"""
Linear Probe decode head for MMSegmentation.

A simple 1x1 convolution head that maps backbone features to class logits.
Used for linear probing / simple fine-tuning experiments.
"""

import torch
import torch.nn as nn
from mmengine.registry import MODELS as MMENGINE_MODELS
from mmseg.registry import MODELS
from mmseg.models.decode_heads.decode_head import BaseDecodeHead


@MODELS.register_module()
@MMENGINE_MODELS.register_module()
class LinearProbeHead(BaseDecodeHead):
    """Linear Probe decode head.

    A single 1x1 convolution layer that maps multi-scale backbone features
    to class logits at the target resolution.

    Args:
        in_channels (int): Number of input channels (backbone embed_dim).
        channels (int): Intermediate channels. Default: 256.
        **kwargs: Additional args for BaseDecodeHead.
    """

    def __init__(self, in_channels, channels=256, target_size=None, **kwargs):
        super().__init__(
            in_channels=in_channels,
            channels=channels,
            **kwargs,
        )
        # 1x1 conv to map from backbone dim to num_classes
        self.cls_seg = nn.Conv2d(
            self.in_channels, self.num_classes, kernel_size=1
        )
        # Target spatial size for upsampling (H, W)
        # If None, uses inputs[0] shape (may not work for ViT where all
        # features have the same resolution)
        self.target_size = target_size

    def forward(self, inputs):
        """Forward pass.

        Args:
            inputs (tuple[Tensor]): Multi-scale features from backbone.
                Uses the last (highest-level) feature.

        Returns:
            Tensor: Segmentation logits [B, num_classes, H, W] at the
                target resolution (upsampled to input spatial size).
        """
        # Use the last feature map (highest semantic level)
        x = inputs[-1]
        x = self.cls_seg(x)
        # Upsample to target resolution
        if self.target_size is not None:
            target_size = self.target_size
        else:
            target_size = inputs[0].shape[2:]
        if x.shape[2:] != target_size:
            x = torch.nn.functional.interpolate(
                x, size=target_size, mode='bilinear', align_corners=False
            )
        return x
