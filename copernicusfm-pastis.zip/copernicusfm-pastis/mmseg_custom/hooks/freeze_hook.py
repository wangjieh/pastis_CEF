"""
Freeze backbone hook for staged fine-tuning.

Freezes the backbone for the first N epochs, then unfreezes it.
"""

from mmengine.hooks import Hook
from mmengine.registry import HOOKS as MMENGINE_HOOKS
from mmseg.registry import HOOKS


@HOOKS.register_module()
@MMENGINE_HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze backbone for first N epochs, then unfreeze.

    Args:
        freeze_epochs (int): Number of epochs to keep backbone frozen.
            After this many epochs, the backbone is unfrozen. Default: 10.
    """

    def __init__(self, freeze_epochs=10):
        self.freeze_epochs = freeze_epochs

    def before_train_epoch(self, runner):
        """Freeze/unfreeze backbone based on current epoch."""
        epoch = runner.epoch
        model = runner.model

        # Access the underlying model (handle DDP wrapper)
        if hasattr(model, 'module'):
            model = model.module

        backbone = None
        if hasattr(model, 'backbone'):
            backbone = model.backbone
        # For CopernicusFMTemporal, backbone is nested
        if hasattr(backbone, 'backbone'):
            backbone = backbone.backbone

        if backbone is None:
            return

        if epoch < self.freeze_epochs:
            # Freeze
            for param in backbone.parameters():
                param.requires_grad = False
        else:
            # Unfreeze
            for param in backbone.parameters():
                param.requires_grad = True
