"""
EncoderDecoder model with meta_info support for CopernicusFM.

Extends MMSeg's EncoderDecoder to extract meta_info from DataSample
objects and pass it to the backbone.
"""

import torch
from mmengine.registry import MODELS as MMENGINE_MODELS
from mmseg.registry import MODELS
from mmseg.models.segmentors import EncoderDecoder
from mmseg.structures import SegDataSample


@MODELS.register_module()
@MMENGINE_MODELS.register_module()
class EncoderDecoderMeta(EncoderDecoder):
    """EncoderDecoder with meta_info extraction for CopernicusFM.

    Extracts meta_info (lon, lat, doy, area) from DataSample objects
    and passes it to the backbone during forward pass.

    All other behavior (decode_head, auxiliary_head, loss, predict)
    is inherited from EncoderDecoder.
    """

    def extract_meta_info(self, data_samples):
        """Extract meta_info from a batch of DataSample objects.

        Args:
            data_samples (list[SegDataSample]): Batch of data samples.

        Returns:
            Tensor or None: Meta info [B, 4] or None if not available.
        """
        meta_infos = []
        for ds in data_samples:
            if hasattr(ds, 'metainfo') and 'meta_info' in ds.metainfo:
                mi = ds.metainfo['meta_info']
                if isinstance(mi, torch.Tensor):
                    meta_infos.append(mi)
                else:
                    meta_infos.append(torch.tensor(mi, dtype=torch.float32))

        if not meta_infos:
            return None

        return torch.stack(meta_infos, dim=0).to(
            next(self.backbone.parameters()).device
        )

    def extract_feat(self, inputs, data_samples=None):
        """Extract features with meta_info.

        Args:
            inputs (Tensor or list[Tensor]): Input images.
            data_samples (list[SegDataSample], optional): Data samples.

        Returns:
            tuple[Tensor]: Multi-scale features.
        """
        # Handle list inputs (from data preprocessor)
        if isinstance(inputs, list):
            inputs = torch.stack(inputs, dim=0)
        # Ensure inputs are on the same device as the model
        device = next(self.backbone.parameters()).device
        inputs = inputs.to(device)
        meta_info = self.extract_meta_info(data_samples) if data_samples else None
        return self.backbone(inputs, meta_info)

    def encode_decode(self, inputs, data_samples):
        """Encode images with backbone and decode into a semantic segmentation
        map of the same spatial size.

        Args:
            inputs (Tensor): Input images.
            data_samples (SegDataSample): Data samples.

        Returns:
            Tensor: Segmentation logits.
        """
        x = self.extract_feat(inputs, data_samples)
        seg_logits = self.decode_head.predict(x, data_samples, self.test_cfg)
        return seg_logits

    def loss(self, inputs, data_samples):
        """Calculate losses from a batch of inputs and data samples.

        Args:
            inputs (Tensor): Input images.
            data_samples (list[SegDataSample]): Data samples.

        Returns:
            dict: Dictionary of losses.
        """
        x = self.extract_feat(inputs, data_samples)
        losses = dict()
        loss_decode = self.decode_head.loss(x, data_samples, self.train_cfg)
        losses.update(loss_decode)

        if self.with_auxiliary_head:
            loss_aux = self.auxiliary_head.loss(
                x, data_samples, self.train_cfg
            )
            losses.update(loss_aux)

        return losses

    def predict(self, inputs, data_samples):
        """Predict segmentation results.

        Args:
            inputs (Tensor): Input images.
            data_samples (list[SegDataSample]): Data samples.

        Returns:
            list[SegDataSample]: Prediction results.
        """
        if data_samples is not None:
            batch_img_metas = [
                ds.metainfo for ds in data_samples
            ]
        else:
            batch_img_metas = [
                dict() for _ in range(inputs.shape[0])
            ]

        x = self.extract_feat(inputs, data_samples)
        seg_logits = self.decode_head.predict(
            x, batch_img_metas, self.test_cfg
        )

        return self.postprocess_result(seg_logits, data_samples)
