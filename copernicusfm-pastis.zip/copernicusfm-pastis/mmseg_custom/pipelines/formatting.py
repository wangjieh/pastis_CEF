"""
Custom formatting pipeline for PASTIS dataset.

Converts numpy arrays from the dataset into the format expected by
MMSeg's data preprocessor, while preserving meta_info as a tensor.
"""

import numpy as np
import torch
from mmengine.registry import TRANSFORMS as MMENGINE_TRANSFORMS
from mmseg.registry import TRANSFORMS
from mmseg.structures import SegDataSample
from mmengine.structures import PixelData


@TRANSFORMS.register_module()
@MMENGINE_TRANSFORMS.register_module()
class PackPastisInputs:
    """Pack PASTIS inputs for CopernicusFM.

    Converts numpy arrays to tensors and builds SegDataSample.
    Handles [T, C, H, W] temporal inputs (not [H, W, C]).

    Args:
        meta_key (str): Key in results dict for meta_info. Default: 'meta_info'.
    """

    def __init__(self, meta_key='meta_info'):
        self.meta_key = meta_key

    def __call__(self, results):
        return self.transform(results)

    def transform(self, results):
        """Pack inputs including meta_info.

        Args:
            results (dict): Must contain 'img' [T, C, H, W] or [C, H, W],
                'gt_sem_seg' [H, W], and optionally 'meta_info' [4].

        Returns:
            dict: {'inputs': Tensor, 'data_samples': SegDataSample}
        """
        # Image: [T, C, H, W] or [C, H, W] -> keep as is, convert to tensor
        img = results['img']
        if isinstance(img, np.ndarray):
            img = torch.from_numpy(img.copy())
        elif isinstance(img, torch.Tensor):
            img = img.clone()

        # Build SegDataSample
        data_sample = SegDataSample()

        # Ground truth segmentation - must be 2D [H, W]
        if 'gt_sem_seg' in results:
            gt_seg = results['gt_sem_seg']
            if isinstance(gt_seg, np.ndarray):
                gt_seg = torch.from_numpy(gt_seg.copy())
            gt_seg = gt_seg.long().squeeze()  # ensure [H, W], not [1, H, W]
            data_sample.gt_sem_seg = PixelData(data=gt_seg)

        # Set required metainfo for mmseg decode_head.predict
        H, W = img.shape[-2], img.shape[-1]
        data_sample.set_metainfo(dict(
            img_shape=(H, W),
            ori_shape=(H, W),
        ))

        # Meta info (lon, lat, doy, area)
        if self.meta_key in results:
            meta_info = results[self.meta_key]
            if isinstance(meta_info, np.ndarray):
                meta_info = torch.from_numpy(meta_info.copy())
            data_sample.set_metainfo(dict(meta_info=meta_info))

        return dict(inputs=img, data_samples=data_sample)
