import json, os

data_root = '/mnt/ht2-nas2/wj/PASTIS_evel'  # 改成你的 Linux 路径

print(f"data_root: {data_root}")
print(f"exists: {os.path.exists(data_root)}")

meta_path = os.path.join(data_root, 'metadata_summary.json')
print(f"metadata exists: {os.path.exists(meta_path)}")

with open(meta_path, 'r') as f:
    meta = json.load(f)

folds = set(m['Fold'] for m in meta)
print(f"all folds: {folds}")

fold123 = [m for m in meta if m['Fold'] in [1, 2, 3]]
print(f"fold 1+2+3 count: {len(fold123)}")

img_dir = os.path.join(data_root, 'DATA_S2_PT')
seg_dir = os.path.join(data_root, 'label_pt')
print(f"DATA_S2_PT exists: {os.path.exists(img_dir)}")
print(f"label_pt exists: {os.path.exists(seg_dir)}")

# Check first 3 samples
for m in fold123[:3]:
    pid = m['ID_PATCH']
    img_path = os.path.join(img_dir, f'S2_{pid}.pt')
    seg_path = os.path.join(seg_dir, f'TARGET_{pid}.pt')
    print(f"  {pid}: img={os.path.exists(img_path)}, seg={os.path.exists(seg_path)}")
