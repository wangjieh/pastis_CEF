"""
Quick verification of all components (CPU only, no Runner).
"""
import sys, os, time
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(project_root)
sys.path.insert(0, project_root)

import torch
import mmseg_custom  # register all custom modules
from mmengine.config import Config

print("=" * 60)
print("  Quick Verify: CopernicusFM + PASTIS")
print("=" * 60)

# 1. Config
print("\n[1/5] Loading config...")
cfg = Config.fromfile('configs/copernicusfm/copernicusfm_base_linear_frozen.py')
print(f"  model: {cfg.model.type}")
print(f"  backbone: {cfg.model.backbone.type} ({cfg.model.backbone.model_size})")
print(f"  head: {cfg.model.decode_head.type}")
print(f"  OK")

# 2. Model
print("\n[2/5] Building model + loading pretrained weights...")
from mmseg.registry import MODELS
model = MODELS.build(cfg.model)
total = sum(p.numel() for p in model.parameters())
trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"  total params: {total:,}")
print(f"  trainable:    {trainable:,}")
print(f"  OK")

# 3. Dataset
print("\n[3/5] Loading dataset (1 sample)...")
from mmseg.registry import DATASETS
ds_cfg = cfg.train_dataloader.dataset
ds_cfg.num_timesteps = 3  # reduce for speed
dataset = DATASETS.build(ds_cfg)
sample = dataset[0]
print(f"  dataset size: {len(dataset)}")
print(f"  sample keys:  {list(sample.keys())}")
if 'inputs' in sample:
    print(f"  inputs shape: {list(sample['inputs'].shape)}")
print(f"  OK")

# 4. Forward pass
print("\n[4/5] Forward pass (1 sample)...")
model.eval()
# Build a mini batch
from mmengine.structures import PixelData
from mmseg.structures import SegDataSample

inputs = sample['inputs'].unsqueeze(0)  # [1, T, C, H, W]
ds = SegDataSample()
ds.gt_sem_seg = sample['data_samples'].gt_sem_seg
ds.set_metainfo(sample['data_samples'].metainfo)

with torch.no_grad():
    t0 = time.time()
    out = model.predict(inputs, [ds])
    t_fwd = time.time() - t0

print(f"  input:   {list(inputs.shape)}")
print(f"  output:  {type(out)}, time: {t_fwd:.2f}s")
print(f"  OK")

# 5. Loss computation (train mode)
print("\n[5/5] Loss computation (1 sample)...")
model.train()
inputs_t = sample['inputs'].unsqueeze(0).requires_grad_(True)
ds_t = SegDataSample()
ds_t.gt_sem_seg = sample['data_samples'].gt_sem_seg
ds_t.set_metainfo(sample['data_samples'].metainfo)

t0 = time.time()
losses = model.loss(inputs_t, [ds_t])
t_loss = time.time() - t0
print(f"  losses: { {k: f'{v.item():.4f}' for k, v in losses.items()} }")
print(f"  time:   {t_loss:.2f}s")
print(f"  OK")

print("\n" + "=" * 60)
print("  All components verified!")
print("=" * 60)
