custom_imports = dict(
    allow_failed_imports=False, imports=[
        'mmseg_custom',
    ])
data_root = 'F:/PythonProject/PASTIS_evel'
dataset_type = 'PASTISSegDataset'
default_hooks = dict(
    checkpoint=dict(
        interval=10, rule='greater', save_best='mIoU', type='CheckpointHook'),
    logger=dict(interval=50, log_metric_by_epoch=True, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'))
env_cfg = dict(
    cudnn_benchmark=True,
    dist_cfg=dict(backend='nccl'),
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0))
launcher = 'none'
log_level = 'INFO'
log_processor = dict(by_epoch=True, type='LogProcessor', window_size=50)
model = dict(
    auxiliary_head=None,
    backbone=dict(
        band_bandwidths=[
            20,
            65,
            35,
            30,
            15,
            15,
            20,
            115,
            20,
            20,
            30,
            90,
            180,
        ],
        band_wavelengths=[
            440,
            490,
            560,
            665,
            705,
            740,
            783,
            842,
            860,
            940,
            1370,
            1610,
            2190,
        ],
        freeze_backbone=True,
        input_mode='spectral',
        kernel_size=16,
        model_size='base',
        patch_size=16,
        pretrained=
        'C:/Users/23948/Desktop/CEF2mmlab/weights/CopernicusFM_ViT_base_varlang_e100.pth',
        temporal_fusion='mean',
        type='CopernicusFMTemporal'),
    data_preprocessor=dict(
        size=(
            128,
            128,
        ), type='TemporalSegDataPreprocessor'),
    decode_head=dict(
        channels=768,
        in_channels=768,
        loss_decode=dict(
            loss_weight=1.0, type='CrossEntropyLoss', use_sigmoid=False),
        norm_cfg=dict(requires_grad=True, type='SyncBN'),
        num_classes=19,
        target_size=(
            128,
            128,
        ),
        type='LinearProbeHead'),
    test_cfg=dict(mode='whole'),
    train_cfg=dict(),
    type='EncoderDecoderMeta')
norm_cfg = dict(requires_grad=True, type='SyncBN')
optim_wrapper = dict(
    clip_grad=dict(max_norm=1.0, norm_type=2),
    optimizer=dict(lr=0.001, type='AdamW', weight_decay=0.05),
    type='OptimWrapper')
param_scheduler = [
    dict(
        begin=0, by_epoch=False, end=500, start_factor=1e-06, type='LinearLR'),
    dict(
        T_max=50,
        begin=0,
        by_epoch=True,
        end=50,
        eta_min=1e-06,
        type='CosineAnnealingLR'),
]
randomness = dict(deterministic=False, diff_rank_seed=True, seed=42)
resume = False
test_cfg = dict(type='TestLoop')
test_dataloader = dict(
    batch_size=1,
    dataset=dict(
        data_root='F:/PythonProject/PASTIS_evel',
        fold=4,
        num_timesteps=12,
        pipeline=[
            dict(type='PackPastisInputs'),
        ],
        type='PASTISSegDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
test_evaluator = dict(
    iou_metrics=[
        'mIoU',
        'mFscore',
    ], type='IoUMetric')
train_cfg = dict(max_epochs=50, type='EpochBasedTrainLoop', val_interval=1)
train_dataloader = dict(
    batch_size=4,
    dataset=dict(
        data_root='F:/PythonProject/PASTIS_evel',
        fold=[
            1,
            2,
            3,
        ],
        num_timesteps=12,
        pipeline=[
            dict(type='PackPastisInputs'),
        ],
        type='PASTISSegDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=True, type='InfiniteSampler'))
train_pipeline = [
    dict(type='PackPastisInputs'),
]
val_cfg = dict(type='ValLoop')
val_dataloader = dict(
    batch_size=1,
    dataset=dict(
        data_root='F:/PythonProject/PASTIS_evel',
        fold=4,
        num_timesteps=12,
        pipeline=[
            dict(type='PackPastisInputs'),
        ],
        type='PASTISSegDataset'),
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
val_evaluator = dict(
    iou_metrics=[
        'mIoU',
        'mFscore',
    ], type='IoUMetric')
val_pipeline = [
    dict(type='PackPastisInputs'),
]
work_dir = './work_dirs\\copernicusfm_linear_frozen'
